package com.alfy.downloader

import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger

/**
 * Tool Tier 3 "xGetter" (cadangan, mirip xGetter): ekstrak URL streaming dari situs/embed sulit
 * HANYA lewat request HTTP/HTML biasa (tanpa WebView, tanpa HLS2MP4):
 *  1) unduh halaman, 2) buka sandi eval(P.A.C.K.E.R), atob(), JSON sources/file,
 *  3) ikuti iframe/embed (kedalaman 2), 4) coba API gaya Fembed (/api/source/ID).
 * Mengembalikan null bila ada link yang masuk daftar, selain itu alasan gagal.
 */
object XGetterTool {
    const val NAME = "xGetter"
    private val ic = RegexOption.IGNORE_CASE
    private val mediaRe = Regex("https?://[^\\s\"'<>\\\\)]+?\\.(?:m3u8|mp4|webm|mpd|mkv|m4v|mov|mp3|m4a)(?:\\?[^\\s\"'<>\\\\)]*)?", ic)
    private val keyRe = Regex("[\"']?(?:file|src|source|video_url|videoUrl|hls|hlsUrl|stream|streamUrl|playbackUrl|contentUrl|url)[\"']?\\s*[:=]\\s*[\"'](https?:(?:\\\\?/){2}[^\"'\\s<>]+|(?:\\\\?/){2}[^\"'\\s<>]+)[\"']", ic)
    private val iframeRe = Regex("<iframe\\b[^>]*?\\b(?:src|data-src)\\s*=\\s*[\"']([^\"']+)[\"']", ic)
    private val embedRe = Regex("[\"'](https?://[^\"'\\s<>]+/(?:e|embed|embed-[^/\"']+|v|f|player|watch)/[^\"'\\s<>]+)[\"']", ic)
    private val packRe = Regex("eval\\(function\\(p,a,c,k,e,[dr]\\)\\{.*?\\}\\('(.*?)',(\\d+),(\\d+),'(.*?)'\\.split\\('\\|'\\)", RegexOption.DOT_MATCHES_ALL)
    private val atobRe = Regex("atob\\(\\s*[\"']([A-Za-z0-9+/=]{16,})[\"']\\s*\\)")
    private val adRe = Regex("doubleclick|googlesyndication|googleads|imasdk|adservice|/vast|adsystem|pubads|adnxs|popads|histats", ic)
    private val titleRe = Regex("<title[^>]*>([^<]{1,200})</title>", ic)

    private fun norm(s: String) = s.replace("\\/", "/").replace("\\u002F", "/", true).replace("\\u0026", "&", true).replace("&amp;", "&")

    private fun http(u: String, ref: String?, post: String? = null): String? = try {
        val k = URL(u).openConnection() as HttpURLConnection
        k.connectTimeout = 5000; k.readTimeout = 5000; k.instanceFollowRedirects = true
        k.setRequestProperty("User-Agent", Resolver.UA)
        k.setRequestProperty("Accept", "text/html,application/json;q=0.9,*/*;q=0.8")
        ref?.let { k.setRequestProperty("Referer", it) }
        if (post != null) {
            k.requestMethod = "POST"; k.doOutput = true
            k.setRequestProperty("X-Requested-With", "XMLHttpRequest")
            k.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            k.outputStream.use { it.write(post.toByteArray()) }
        }
        val st = if (k.responseCode >= 400) k.errorStream else k.inputStream
        if (st == null) null else st.bufferedReader().use { r -> val b = CharArray(1_200_000); val n = r.read(b); if (n <= 0) "" else String(b, 0, n) }
    } catch (e: Throwable) { null }

    private fun abs(base: String, u: String): String? = try {
        val x = norm(u.trim()); if (x.startsWith("//")) "https:$x" else if (x.startsWith("http")) x else URL(URL(base), x).toString()
    } catch (e: Throwable) { null }

    /** Buka sandi P.A.C.K.E.R (eval(function(p,a,c,k,e,d)...)). */
    private fun unpack(src: String): List<String> {
        val out = ArrayList<String>()
        for (m in packRe.findAll(src)) {
            try {
                var p = m.groupValues[1].replace("\\'", "'").replace("\\\\", "\\")
                val a = m.groupValues[2].toInt(); val c = m.groupValues[3].toInt()
                val k = m.groupValues[4].split("|")
                fun enc(n: Int): String { val r = if (n < a) "" else enc(n / a); val d = n % a; return r + (if (d > 35) (d + 29).toChar() else Character.forDigit(d, 36)).toString() }
                val map = HashMap<String, String>()
                for (i in c - 1 downTo 0) { val key = enc(i); map[key] = if (i < k.size && k[i].isNotEmpty()) k[i] else key }
                p = Regex("\\b\\w+\\b").replace(p) { map[it.value] ?: it.value }
                out.add(p)
            } catch (e: Throwable) { }
        }
        return out
    }

    private fun harvest(base: String, html: String): LinkedHashSet<String> {
        val texts = arrayListOf(html)
        texts.addAll(unpack(html))
        for (m in atobRe.findAll(html)) try { texts.add(String(android.util.Base64.decode(m.groupValues[1], android.util.Base64.DEFAULT), Charsets.UTF_8)) } catch (e: Throwable) { }
        val out = LinkedHashSet<String>()
        for (t0 in texts) {
            val t = norm(t0)
            for (m in mediaRe.findAll(t)) out.add(m.value.trimEnd(',', ';', '.'))
            for (m in keyRe.findAll(t0)) { val x = abs(base, m.groupValues[1]) ?: continue; if (mediaRe.containsMatchIn(x)) out.add(x) }
        }
        out.removeAll { adRe.containsMatchIn(it) }
        out.remove(base)
        return out
    }

    fun run(page: String): String? {
        val html0 = http(page, null) ?: return "halaman tidak terbuka"
        val title = titleRe.find(html0)?.groupValues?.get(1)?.trim()?.take(120) ?: ""
        val found = LinkedHashSet<String>(); var ref = page
        val seen = HashSet<String>().apply { add(page) }
        val q = ArrayDeque<Pair<String, Pair<String, Int>>>()
        fun scan(u: String, html: String, d: Int) {
            val h = harvest(u, html)
            if (h.isNotEmpty() && found.isEmpty()) ref = u
            found.addAll(h)
            if (d < 2) {
                for (m in iframeRe.findAll(html)) { val x = abs(u, m.groupValues[1]) ?: continue; if (!adRe.containsMatchIn(x) && seen.add(x) && q.size < 8) q.add(x to (u to d + 1)) }
                for (m in embedRe.findAll(norm(html))) { val x = m.groupValues[1]; if (!adRe.containsMatchIn(x) && seen.add(x) && q.size < 8) q.add(x to (u to d + 1)) }
            }
        }
        scan(page, html0, 0)
        var n = 0
        val deadline = System.currentTimeMillis() + 4_000
        while (q.isNotEmpty() && found.size < 8 && n < 8 && System.currentTimeMillis() < deadline && !ScanLimit.stopped()) {
            val (u, rd) = q.removeFirst()
            val html = http(u, rd.first) ?: continue
            n++
            scan(u, html, rd.second)
            // API gaya Fembed/XCDN: /v/ID atau /f/ID -> POST /api/source/ID
            val id = Regex("^https?://([^/]+)/(?:v|f)/([A-Za-z0-9_-]{4,})", ic).find(u)
            if (id != null && found.isEmpty()) {
                val js = http("https://${id.groupValues[1]}/api/source/${id.groupValues[2]}", u, "r=&d=${id.groupValues[1]}")
                if (js != null) { val hh = harvest(u, js); if (hh.isNotEmpty()) { ref = u; found.addAll(hh) } }
            }
        }
        if (found.isEmpty()) return "tanpa link stream di halaman + $n embed"
        val ok = AtomicInteger(0)
        for (x in found.take(10)) {
            if (ScanLimit.stopped()) break
            try { if (Resolver.addMediaChecked(x, ref, title, true)) ok.incrementAndGet() } catch (e: Throwable) { }
        }
        return if (ok.get() > 0) null else "${found.size} kandidat ditolak"
    }
}
