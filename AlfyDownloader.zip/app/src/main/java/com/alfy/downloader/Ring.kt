package com.alfy.downloader

import android.content.Context
import android.graphics.*
import android.view.Choreographer
import android.view.View
import androidx.core.graphics.ColorUtils

/**
 * Cincin warna-warni berputar + api realistis + percikan api.
 *
 * Api  : ribuan lapis sprite gradien lembut (HD 96px) dengan blending ADDITIF, jadi inti api memutih-panas
 *        lalu menguning/mengoranye/memerah ke ujung (atau memutih->warna pilihan->gelap utk warna lain).
 *        Gerak: daya apung (makin ke atas makin cepat), turbulensi noise, angin pelan, api menyempit ke
 *        sumbu, lidah api memanjang searah gerak, nyala "bernapas" + halo cahaya di sekeliling.
 *        Mode putar: api terlempar menyinggung putaran cincin lalu melengkung tertinggal (seperti api anime).
 * Percikan: dipisah dari api. Opsi sendiri: hidup/mati + jumlah (sparkAmount) + ikut warna api.
 *        Dua jenis: percikan terlempar saat cincin berputar, dan bara melayang naik (tetap ada walau cincin diam).
 */
class RingView(ctx: Context, inner0: Int) : View(ctx) {
    var inner = inner0
        set(v) { field = v; if (width > 0) onSizeChanged(width, height, width, height); invalidate() }
    var flame = true
        set(v) { field = v; refresh() }
    var flameSize = 1f
    var flameColor = 0xFF1E88FF.toInt()
        set(v) { if (field != v) { field = v; sprites.clear(); buildHalo() } }
    var rainbow = false
    var swirl = false
    /** Percikan: dimatikan/dihidupkan sendiri, jumlahnya 0..3 (1 = normal), warna bisa ikut api. */
    var sparkOn = true
        set(v) { field = v; refresh() }
    var sparkAmount = 1f
        set(v) { field = v; refresh() }
    var sparkFollow = true
    var speed = 0.5f
        set(v) { field = v; refresh() }

    private class F {
        var x = 0f; var y = 0f; var sx = 0f; var sy = 0f
        var vx = 0f; var vy = 0f; var vu = 0f; var vr = 0f
        var life = 0f; var max = 1f; var r = 0f; var seed = 0f
        var b = -1
        var ang = 0f; var rad = 0f; var w = 0f; var dec = 2f; var lift = 0f; var tx = 0f
    }
    private class P {
        var x = 0f; var y = 0f; var vx = 0f; var vy = 0f
        var life = 0f; var max = 1f; var kind = 0; var big = 1f; var seed = 0f
        var burst = false; var b = -1
    }

    private val fl = ArrayList<F>()
    private val fpool = ArrayList<F>()
    private val ps = ArrayList<P>()
    private val ppool = ArrayList<P>()
    private val rnd = java.util.Random()
    private val dens = ctx.resources.displayMetrics.density
    private val add = PorterDuffXfermode(PorterDuff.Mode.ADD)

    private val fp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { xfermode = add }
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; xfermode = add }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; xfermode = add }
    private var shader: SweepGradient? = null
    private val m = Matrix()
    private val rectF = RectF()
    private var angle = 0f
    private var last = 0L
    private var acc = 0f      // percikan terlempar
    private var acc2 = 0f     // api
    private var acc3 = 0f     // bara melayang
    private var clock = 0f
    private var looping = false
    private var ema = 0f      // rata-rata waktu frame -> kualitas adaptif di HP lemah
    private var q = 1f

    private val STAGES = 10
    private val sprites = HashMap<Int, Array<Bitmap?>>()
    private val hueCols = IntArray(24) { Color.HSVToColor(floatArrayOf(it * 15f, 0.9f, 1f)) }

    private fun rps(): Float = if (speed <= 0.01f) 0f else 0.25f + 19.75f * speed * speed
    private fun sparkActive() = sparkOn && sparkAmount > 0.02f

    private val cb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            step(t)
            if (running()) Choreographer.getInstance().postFrameCallback(this) else looping = false
        }
    }
    private fun running() = isAttachedToWindow && visibility == VISIBLE &&
        (speed > 0.01f || ps.isNotEmpty() || flame || fl.isNotEmpty() || sparkActive())

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        ring.strokeWidth = inner * 0.09f
        shader = SweepGradient(w / 2f, h / 2f, intArrayOf(0xFFFF1744.toInt(), 0xFFFFEA00.toInt(), 0xFF00E676.toInt(), 0xFF00E5FF.toInt(), 0xFF2979FF.toInt(), 0xFFD500F9.toInt(), 0xFFFF1744.toInt()), null)
        ring.shader = shader
        buildHalo()
    }

    // ---------- util ----------
    private fun sinf(x: Float) = Math.sin(x.toDouble()).toFloat()
    private fun cosf(x: Float) = Math.cos(x.toDouble()).toFloat()
    private fun expf(x: Float) = Math.exp(x.toDouble()).toFloat()
    private fun powf(x: Float, y: Float) = Math.pow(x.toDouble(), y.toDouble()).toFloat()

    private fun hash(n: Int): Float {
        var h = n * 374761393
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return (h and 0xFFFF) / 65535f
    }
    /** Value-noise 2D halus, hasil 0..1. */
    private fun noise(x: Float, t: Float): Float {
        val xi = Math.floor(x.toDouble()).toInt(); val ti = Math.floor(t.toDouble()).toInt()
        val xf = x - xi; val tf = t - ti
        val u = xf * xf * (3f - 2f * xf); val v = tf * tf * (3f - 2f * tf)
        val a = hash(xi * 57 + ti * 131); val b = hash(xi * 57 + 57 + ti * 131)
        val c = hash(xi * 57 + ti * 131 + 131); val d = hash(xi * 57 + 57 + ti * 131 + 131)
        val ab = a + (b - a) * u; val cd = c + (d - c) * u
        return ab + (cd - ab) * v
    }
    private fun edgeF(x: Float, y: Float, pd: Float): Float {
        val d = Math.min(Math.min(x, width - x), Math.min(y, height - y))
        return (d / (0.4f * pd + 1f)).coerceIn(0f, 1f)
    }

    // ---------- sprite api (gradien lembut per tahap suhu) ----------
    /** t=0 inti paling panas ... t=1 ujung dingin. Warna hangat: putih->kuning->warna->merah tua. */
    private fun rampColor(base: Int, st: Int): Int {
        val hsv = FloatArray(3); Color.colorToHSV(base, hsv)
        val t = st / (STAGES - 1f)
        var h = if (hsv[0] > 180f) hsv[0] - 360f else hsv[0]
        val warm = h > -20f && h < 50f
        if (t < 0.5f) {
            val u = 1f - 2f * t
            if (warm) h = Math.min(h + 42f * u, 60f)
            hsv[1] = hsv[1] * (1f - 0.88f * u * u)
            hsv[2] = 1f
        } else {
            val w = 2f * t - 1f
            if (warm) h -= 14f * w
            hsv[1] = Math.min(1f, hsv[1] + 0.1f * w)
            hsv[2] = hsv[2] * (1f - 0.8f * w)
        }
        hsv[0] = (h + 360f) % 360f
        return Color.HSVToColor(hsv)
    }
    private fun makeSprite(base: Int, st: Int): Bitmap {
        val n = 96
        val bm = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val col = rampColor(base, st)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(n / 2f, n / 2f, n / 2f,
            intArrayOf(ColorUtils.setAlphaComponent(col, 255), ColorUtils.setAlphaComponent(col, 170),
                ColorUtils.setAlphaComponent(col, 70), ColorUtils.setAlphaComponent(col, 0)),
            floatArrayOf(0f, 0.3f, 0.62f, 1f), Shader.TileMode.CLAMP)
        Canvas(bm).drawCircle(n / 2f, n / 2f, n / 2f, p)
        return bm
    }
    private fun sprite(b: Int, st: Int): Bitmap {
        val key = if (b < 0) flameColor else hueCols[b]
        val arr = sprites.getOrPut(key) { arrayOfNulls<Bitmap>(STAGES) }
        return arr[st] ?: makeSprite(key, st).also { arr[st] = it }
    }
    private fun buildHalo() {
        val pd = (width - inner) / 2f
        if (width <= 0 || pd <= 1f) { halo.shader = null; return }
        val r0 = inner / 2f
        val rad = r0 + pd * 0.95f
        val col = flameColor
        halo.shader = RadialGradient(width / 2f, height / 2f, rad,
            intArrayOf(ColorUtils.setAlphaComponent(col, 0), ColorUtils.setAlphaComponent(col, 0),
                ColorUtils.setAlphaComponent(col, 120), ColorUtils.setAlphaComponent(col, 42), ColorUtils.setAlphaComponent(col, 0)),
            floatArrayOf(0f, (r0 * 0.82f) / rad, r0 / rad, (r0 + pd * 0.45f) / rad, 1f), Shader.TileMode.CLAMP)
    }

    // ---------- pool ----------
    private fun obtainF(): F { val f = if (fpool.isEmpty()) F() else fpool.removeAt(fpool.size - 1); f.vx = 0f; f.vy = 0f; f.sx = 0f; f.sy = 0f; f.lift = 0f; f.tx = 0f; return f }
    private fun obtainP(): P { val p = if (ppool.isEmpty()) P() else ppool.removeAt(ppool.size - 1); p.burst = false; p.b = -1; p.kind = 0; p.big = 1f; return p }

    // ---------- simulasi ----------
    private fun step(t: Long) {
        val raw = if (last == 0L) 0.016f else ((t - last) / 1e9f)
        val dt = raw.coerceIn(0.001f, 0.05f)
        last = t
        ema = if (ema == 0f) raw else ema * 0.92f + raw * 0.08f
        if (ema > 0.026f) q = Math.max(0.4f, q - 0.015f) else if (ema < 0.019f) q = Math.min(1f, q + 0.008f)
        angle = (angle + rps() * 360f * dt) % 360f
        clock += dt
        if (width > 0) {
            val cx = width / 2f; val cy = height / 2f
            val R = inner / 2f
            val pd = Math.max(1f, (width - inner) / 2f)
            if (flame) emitFlame(dt, cx, cy, R, pd)
            updateFlame(dt, cx)
            if (sparkActive()) emitSparks(dt, cx, cy, R)
            updateSparks(dt)
        }
        invalidate()
    }

    private fun emitFlame(dt: Float, cx: Float, cy: Float, R: Float, pd: Float) {
        val fs = flameSize
        val breath = 0.75f + 0.5f * noise(clock * 1.3f, 7.7f)           // nyala "bernapas"
        acc2 += dt * 190f * powf(fs, 0.9f) * q * breath
        val tall = Math.min(inner * 0.55f * powf(fs, 0.85f), pd * 0.92f)  // tinggi api (px)
        val sizeK = 0.8f + 0.25f * Math.sqrt(fs.toDouble()).toFloat()
        val wr = Math.min(Math.max(rps(), 0.3f), 6f) * 6.2831855f
        while (acc2 >= 1f) {
            acc2 -= 1f
            if (fl.size > 560) { acc2 = 0f; break }
            var th: Float
            var up: Float
            var tries = 0
            do {
                th = rnd.nextFloat() * 6.2831855f
                up = (1f - sinf(th)) * 0.5f                       // 1 = puncak cincin
                tries++
            } while (!swirl && tries < 4 && rnd.nextFloat() > 0.3f + 0.7f * up)
            val f = obtainF()
            val life = (0.55f + 0.5f * rnd.nextFloat()) * (0.8f + 0.2f * Math.min(fs, 1.5f))
            f.life = life; f.max = life
            f.seed = rnd.nextFloat() * 100f
            f.r = inner * (0.065f + 0.07f * rnd.nextFloat()) * sizeK
            f.b = if (rainbow) (((th * 57.29578f + clock * 60f) % 360f) / 15f).toInt().coerceIn(0, 23) else -1
            val vy0 = tall / life * (0.75f + 0.5f * rnd.nextFloat())
            val c = cosf(th); val s = sinf(th)
            val rr = R * (0.9f + 0.1f * rnd.nextFloat())
            f.x = cx + c * rr; f.y = cy + s * rr
            if (swirl) {
                f.ang = th; f.rad = rr
                f.w = wr * (0.85f + 0.3f * rnd.nextFloat())
                f.dec = Math.max(2f, f.w / 2.2f)                  // sapuan sudut terbatas -> lengkung ekor stabil
                f.vr = vy0 * (0.25f + 0.2f * rnd.nextFloat())
                f.vu = vy0 * (0.4f + 0.25f * rnd.nextFloat())
            } else {
                val side = 1f - up                                // bagian bawah: dorong keluar dulu, lalu naik menyusuri sisi
                val push = vy0 * 0.9f * side
                f.vx = c * push + (rnd.nextFloat() - 0.5f) * inner * 0.25f
                f.vy = s * push
                f.vu = vy0
            }
            fl.add(f)
        }
    }

    private fun updateFlame(dt: Float, cx: Float) {
        val wind = (noise(clock * 0.5f, 3.3f) * 2f - 1f) * inner * 0.6f
        val damp = expf(-3f * dt)
        var i = 0
        while (i < fl.size) {
            val f = fl[i]
            f.life -= dt
            if (f.life <= 0f) { fl[i] = fl[fl.size - 1]; fl.removeAt(fl.size - 1); fpool.add(f); continue }
            val age = 1f - f.life / f.max
            val ox = f.x; val oy = f.y
            val turb = (noise(f.seed + f.y / inner * 3.2f, clock * 2.1f) * 2f - 1f) * inner * 1.5f * (0.15f + age)
            val lean = (cx - f.x) * 0.45f * age                    // api menyempit ke arah sumbu
            val windV = wind * age * age
            val rise = 0.55f + 0.9f * age                          // makin tinggi makin cepat (daya apung)
            if (swirl) {
                f.ang += f.w * dt
                f.w *= expf(-f.dec * dt)
                f.rad += f.vr * (0.5f + 0.9f * age) * dt
                f.lift += f.vu * rise * dt
                f.tx += (turb + windV + lean) * dt
                f.x = cx + cosf(f.ang) * f.rad + f.tx
                f.y = height / 2f + sinf(f.ang) * f.rad - f.lift
            } else {
                f.x += (f.vx + turb + windV + lean) * dt
                f.y += (f.vy - f.vu * rise) * dt
                f.vx *= damp; f.vy *= damp
            }
            f.sx = (f.x - ox) / dt; f.sy = (f.y - oy) / dt
            i++
        }
    }

    private fun hueNow(th: Float) = (((th * 57.29578f + clock * 60f) % 360f) / 15f).toInt().coerceIn(0, 23)

    private fun emitSparks(dt: Float, cx: Float, cy: Float, R: Float) {
        val a = sparkAmount
        if (speed > 0.01f) {
            acc += dt * (40f + 480f * speed) * a * q
            while (acc >= 1f) { acc -= 1f; if (ps.size > 1100) { acc = 0f; break }; spawnFling(cx, cy, R) }
        } else acc = 0f
        acc3 += dt * 60f * a * q
        while (acc3 >= 1f) { acc3 -= 1f; if (ps.size > 1100) { acc3 = 0f; break }; spawnEmber(cx, cy, R) }
    }
    private fun spawnFling(cx: Float, cy: Float, R: Float) {
        val th = rnd.nextFloat() * 6.2831855f
        val c = cosf(th); val s = sinf(th)
        val v = inner * (1.1f + 2.2f * speed) * (0.5f + 0.9f * rnd.nextFloat())
        val p = obtainP()
        p.x = cx + c * R; p.y = cy + s * R
        p.vx = -s * v + c * v * 0.25f + (rnd.nextFloat() - 0.5f) * 0.4f * v
        p.vy = c * v + s * v * 0.25f + (rnd.nextFloat() - 0.5f) * 0.4f * v
        p.life = 0.3f + 0.5f * rnd.nextFloat(); p.max = p.life
        p.kind = 0; p.burst = rnd.nextFloat() < 0.3f; p.big = 0.7f + 0.6f * rnd.nextFloat()
        p.seed = rnd.nextFloat() * 100f
        if (rainbow) p.b = hueNow(th)
        ps.add(p)
    }
    private fun spawnEmber(cx: Float, cy: Float, R: Float) {
        var th: Float; var tries = 0
        do { th = rnd.nextFloat() * 6.2831855f; tries++ } while (tries < 4 && rnd.nextFloat() > 0.25f + 0.75f * (1f - sinf(th)) * 0.5f)
        val p = obtainP()
        val rr = R * (0.85f + 0.2f * rnd.nextFloat())
        p.x = cx + cosf(th) * rr; p.y = cy + sinf(th) * rr
        p.vx = (rnd.nextFloat() - 0.5f) * inner * 0.5f
        p.vy = -inner * (0.5f + 1.0f * rnd.nextFloat())
        p.life = 0.9f + 1.1f * rnd.nextFloat(); p.max = p.life
        p.kind = 1; p.big = 0.5f + 0.6f * rnd.nextFloat(); p.seed = rnd.nextFloat() * 100f
        if (rainbow) p.b = hueNow(th)
        ps.add(p)
    }
    private fun updateSparks(dt: Float) {
        val drag = 1f - 1.4f * dt
        var i = 0
        while (i < ps.size) {
            val p = ps[i]
            p.life -= dt
            if (p.life <= 0f) {
                if (p.burst) {
                    for (k in 0 until 4) {
                        if (ps.size > 1100) break
                        val a = rnd.nextFloat() * 6.2831855f; val v = inner * (0.3f + 0.7f * rnd.nextFloat())
                        val ch = obtainP()
                        ch.x = p.x; ch.y = p.y
                        ch.vx = p.vx * 0.3f + cosf(a) * v; ch.vy = p.vy * 0.3f + sinf(a) * v
                        ch.life = 0.15f + 0.25f * rnd.nextFloat(); ch.max = ch.life
                        ch.kind = 2; ch.big = 0.55f; ch.seed = rnd.nextFloat() * 100f; ch.b = p.b
                        ps.add(ch)
                    }
                }
                ps[i] = ps[ps.size - 1]; ps.removeAt(ps.size - 1); ppool.add(p); continue
            }
            if (p.kind == 1) {
                val n = noise(p.seed + p.x / inner * 2.5f, clock * 1.5f) * 2f - 1f
                p.vx += n * inner * 3f * dt
                p.vx *= (1f - 1.2f * dt)
                p.vy = p.vy * (1f - 1.0f * dt) - inner * 0.4f * dt
            } else {
                p.vy += inner * 3f * dt
                p.vx *= drag; p.vy *= (1f - 0.9f * dt)
            }
            p.x += p.vx * dt; p.y += p.vy * dt
            i++
        }
    }

    // ---------- gambar ----------
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2f; val cy = h / 2f
        val pd = Math.max(1f, (w - inner) / 2f)
        m.setRotate(angle, cx, cy); shader?.setLocalMatrix(m)

        if (flame && !rainbow && halo.shader != null) {
            halo.alpha = ((0.45f + 0.35f * noise(clock * 7f, 1.1f)) * 255f * Math.min(flameSize, 1.5f) / 1.5f).toInt().coerceIn(0, 255)
            c.drawCircle(cx, cy, inner / 2f + pd * 0.95f, halo)
        }
        for (f in fl) {
            val age = 1f - f.life / f.max
            val al = (age / 0.12f).coerceAtMost(1f) * powf(1f - age, 1.15f) * edgeF(f.x, f.y, pd) * 150f
            if (al < 3f) continue
            val bmp = sprite(f.b, (age * (STAGES - 0.01f)).toInt().coerceIn(0, STAGES - 1))
            fp.alpha = al.toInt().coerceIn(0, 255)
            val rr = f.r * (1f - 0.5f * age)
            val spd = Math.sqrt((f.sx * f.sx + f.sy * f.sy).toDouble()).toFloat()
            val hh = rr * (1.5f + spd / (inner * 2.2f)).coerceIn(1.5f, 3.4f) * 0.8f
            val deg = if (spd < 1f) 0f else Math.atan2(f.sy.toDouble(), f.sx.toDouble()).toFloat() * 57.29578f + 90f
            c.save(); c.translate(f.x, f.y); c.rotate(deg)
            rectF.set(-rr, -hh, rr, hh)
            c.drawBitmap(bmp, null, rectF, fp)
            c.restore()
        }

        c.drawCircle(cx, cy, inner / 2f - ring.strokeWidth / 2f, ring)

        val tail = 0.03f * (1f + speed * 1.8f)
        for (p in ps) {
            val f = (p.life / p.max).coerceIn(0f, 1f)
            val tw = if (p.kind == 1) 0.6f + 0.4f * sinf(clock * 35f + p.seed) else 1f
            val al = 255f * powf(f, 0.7f) * tw * edgeF(p.x, p.y, pd)
            if (al < 6f) continue
            val base = if (!sparkFollow) 0 else if (p.b >= 0) hueCols[p.b] else flameColor
            val core: Int; val mid: Int; val dim: Int
            if (sparkFollow) {
                core = ColorUtils.blendARGB(base, Color.WHITE, 0.85f); mid = base; dim = ColorUtils.blendARGB(base, Color.BLACK, 0.45f)
            } else { core = 0xFFFFF8E1.toInt(); mid = 0xFFFFB300.toInt(); dim = 0xFFFF5722.toInt() }
            val x2 = p.x - p.vx * tail; val y2 = p.y - p.vy * tail
            val body = if (f > 0.6f) mid else if (f > 0.3f) mid else dim
            val a = al.toInt().coerceIn(0, 255)
            sp.strokeWidth = 4.2f * dens * p.big; sp.color = body; sp.alpha = a / 4
            c.drawLine(p.x, p.y, x2, y2, sp)
            sp.strokeWidth = 2f * dens * p.big; sp.color = body; sp.alpha = (a * 0.8f).toInt()
            c.drawLine(p.x, p.y, x2, y2, sp)
            sp.strokeWidth = 1f * dens * p.big; sp.color = if (f > 0.3f) core else mid; sp.alpha = a
            c.drawLine(p.x, p.y, x2, y2, sp)
        }
    }

    fun refresh() {
        if (!looping && running()) { looping = true; last = 0L; Choreographer.getInstance().postFrameCallback(cb) }
        invalidate()
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); refresh() }
    override fun onDetachedFromWindow() { Choreographer.getInstance().removeFrameCallback(cb); looping = false; super.onDetachedFromWindow() }
    override fun onVisibilityChanged(v: View, vis: Int) { super.onVisibilityChanged(v, vis); refresh() }
}
