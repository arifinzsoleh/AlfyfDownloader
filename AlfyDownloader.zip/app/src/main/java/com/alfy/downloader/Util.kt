package com.alfy.downloader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Environment
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import android.app.Application
import java.io.File

fun fmtSize(b: Long): String = when {
    b <= 0 -> "?"
    b < 1024 -> "${b}B"
    b < 1048576 -> String.format("%.1fKB", b / 1024.0)
    b < 1073741824 -> String.format("%.1fMB", b / 1048576.0)
    else -> String.format("%.2fGB", b / 1073741824.0)
}

fun fmtDur(s: Long): String {
    if (s <= 0) return "-"
    val h = s / 3600; val m = (s % 3600) / 60; val x = s % 60
    return if (h > 0) String.format("%d:%02d:%02d", h, m, x) else String.format("%d:%02d", m, x)
}

private val BAD_NAME_RE = Regex("[\\\\/:*?\"<>|]")

fun hasBadChars(s: String): Boolean = BAD_NAME_RE.containsMatchIn(s)

private fun cutBytes(s: String, max: Int): String {
    var n = 0; val sb = StringBuilder(); var i = 0
    while (i < s.length) {
        val cp = s.codePointAt(i); val cc = Character.charCount(cp)
        val b = String(Character.toChars(cp)).toByteArray(Charsets.UTF_8).size
        if (n + b > max) break
        sb.append(s, i, i + cc); n += b; i += cc
    }
    return sb.toString()
}

fun safeName(s: String): String =
    cutBytes(s.replace(Regex("[\\\\/:*?\"<>|%\\n\\r]"), "_").trim(), 200).trim().ifBlank { "file" }

fun uniqueFile(dir: File, name: String): File {
    var f = File(dir, name)
    if (!f.exists()) return f
    val b = name.substringBeforeLast('.')
    val e = name.substringAfterLast('.', "")
    var i = 1
    while (f.exists()) {
        f = File(dir, "$b ($i)" + (if (e.isEmpty()) "" else ".$e")); i++
    }
    return f
}

fun makeNotif(c: Context, text: String, title: String = "AlfyDownloader+", progress: Int = -1, ongoing: Boolean = true, alert: Boolean = false, icon: Int = 0, channel: String? = null): Notification {
    val chId = channel ?: if (alert) "alfy_alert" else "alfy"
    if (Build.VERSION.SDK_INT >= 26) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("alfy", "AlfyDownloader+", NotificationManager.IMPORTANCE_LOW))
        // v1.41: saluran penting -> muncul sebagai pop-up dari atas saat unduhan selesai/gagal
        nm.createNotificationChannel(NotificationChannel("alfy_alert", "Unduhan selesai/gagal", NotificationManager.IMPORTANCE_HIGH))
        // saluran khusus layanan aksesibilitas: terpisah & dimatikan paksa (notif lain tidak terpengaruh)
        if (channel == "alfy_access") nm.createNotificationChannel(NotificationChannel("alfy_access", "Layanan aksesibilitas", NotificationManager.IMPORTANCE_NONE))
    }
    val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, chId) else Notification.Builder(c)
    val pi = android.app.PendingIntent.getActivity(c, 0, android.content.Intent(c, MainActivity::class.java),
        android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
    b.setContentTitle(title).setContentText(text).setContentIntent(pi)
        .setSmallIcon(if (icon != 0) icon else if (ongoing) android.R.drawable.stat_sys_download else android.R.drawable.stat_sys_download_done)   // panah turun beranimasi saat mengunduh
        .setOngoing(ongoing).setOnlyAlertOnce(true).setAutoCancel(!ongoing)
    if (progress in 0..100) b.setProgress(100, progress, false)
    if (alert && Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL)
    return b.build()
}

fun postNotif(c: Context, id: Int, n: Notification) {
    try { c.getSystemService(NotificationManager::class.java).notify(id, n) } catch (e: Exception) { }
}

fun parseSpeed(s: String): Long {
    val m = Regex("([\\d.]+)\\s*([KMG]?i?B)/s").find(s) ?: return 0L
    val v = m.groupValues[1].toDoubleOrNull() ?: return 0L
    val mul = when (m.groupValues[2].uppercase().first()) { 'K' -> 1024.0; 'M' -> 1048576.0; 'G' -> 1073741824.0; else -> 1.0 }
    return (v * mul).toLong()
}

object Paths {
    fun root(): File {
        val def = File(Environment.getExternalStorageDirectory(), "DownloadAlfy47")
        var d = File(Repo.prefs().getString("root", def.path) ?: def.path)
        d.mkdirs()
        if (!d.canWrite()) {
            d = File(Repo.app.getExternalFilesDir(null), "DownloadAlfy47"); d.mkdirs()
        }
        return d
    }

    fun dirFor(isAudio: Boolean): File =
        File(root(), if (isAudio) "music" else "video").also { it.mkdirs() }
}

object Repo {
    lateinit var app: Application
    val detected = MutableStateFlow<List<Candidate>>(emptyList())
    private val seqGen = java.util.concurrent.atomic.AtomicLong(0L)
    val downloads = MutableStateFlow<List<DlItem>>(emptyList())
    private val file get() = File(app.filesDir, "downloads.json")

    fun prefs() = app.getSharedPreferences("s", 0)

    fun init(a: Application) {
        app = a
        try {
            if (file.exists()) {
                val arr = JSONArray(file.readText())
                downloads.value = (0 until arr.length()).map { DlItem.fromJson(arr.getJSONObject(it)) }
                    .map { if (it.status == Status.DOWNLOADING || it.status == Status.QUEUED) it.copy(status = Status.PAUSED) else it }
            }
        } catch (e: Exception) { }
    }

    @Synchronized
    fun save() {
        try {
            val arr = JSONArray()
            downloads.value.forEach { arr.put(it.toJson()) }
            file.writeText(arr.toString())
        } catch (e: Exception) { }
    }

    fun get(id: String) = downloads.value.firstOrNull { it.id == id }
    fun add(i: DlItem) { downloads.update { listOf(i) + it }; save() }
    fun update(id: String, f: (DlItem) -> DlItem) {
        downloads.update { l -> l.map { if (it.id == id) f(it) else it } }
    }
    fun remove(id: String) {
        try { get(id)?.let { Resolver.forget(it.url, it.page, it.referer) } } catch (e: Throwable) { }
        downloads.update { l -> l.filter { it.id != id } }; save()
    }
    fun addCandidates(l0: List<Candidate>) {
        if (Resolver.stale()) return   // v1.61: hasil terlambat dari situs/aplikasi sebelumnya
        // v1.11: SETIAP link wajib punya label sumber (alat yang menemukannya); tanpa label = "Tidak diketahui"
        val tag = (ToolLog.tl.get() ?: "").ifEmpty { "Tidak diketahui" }
        val cv = ToolLog.vid
        val l = l0.map { c0 ->
            var c = if (c0.source.isEmpty()) c0.copy(source = tag) else c0
            if (c.vid.isEmpty() && c.isAudio && cv.length == 11 && Resolver.isGv(c.url)) c = c.copy(vid = cv)
            if (c.img.isEmpty() && c.isAudio) CoverHint.m[cv]?.let { c = c.copy(img = it) }
            if (c.isAudio && !c.toMp3 && MusicMap.wants(cv)) c = c.copy(toMp3 = true)
            if (c.seq == 0L) c = c.copy(seq = seqGen.incrementAndGet())
            c
        }
        detected.update { cur ->
            val keys = cur.map { it.key }.toHashSet()
            val sig = cur.map { "${it.title}|${it.quality}|${it.isAudio}" }.toHashSet()
            (cur + l.filter { keys.add(it.key) && sig.add("${it.title}|${it.quality}|${it.isAudio}") }).sortedBy { it.seq }.takeLast(80)
        }
    }
}

/** v1.11: pengaturan scan (tombol ⚙ di panel mengambang). */
object Scan {
    /** Semua tools scan aktif di semua aplikasi & web (bawaan: aktif). */
    fun enabled() = AppPreferences.isAutoScanEnabled
    /** Mode sangat agresif: semua metode tiap tool (bawaan: mati = normal). */
    /** v1.21: tombol "Scan maksimal" menyalakan mode agresif sementara. */
    @Volatile var maxUntil = 0L
    fun maxActive() = System.currentTimeMillis() < maxUntil
    fun aggr() = enabled() && (maxActive() || Repo.prefs().getBoolean("scanAggr", false))
    /** Aksi manual pengguna (tombol 🔍/📋, Share, tambah tautan) tetap jalan walau scan otomatis dimatikan. */
    fun manual(src: String) = src.startsWith("Manual") || src.startsWith("Share") || src.contains("🔍") || src.contains("📋")
    fun modeText() = if (!enabled()) "MATI" else if (aggr()) "AKTIF • AGRESIF" else "AKTIF • normal"
    /** v1.12: mode normal + aplikasi YouTube di depan = HANYA deteksi layar (thumbnail/judul terlihat, klik, putar); logcat/tcpdump tidak ikut. */
    fun ytLock() = enabled() && !aggr() && AlfyAccessibilityService.fgPkg.contains("youtube", true)
}

/** v1.12: pilihan aktif/mati untuk tiap tool (27 tool, tombol ⚙). Bawaan semua aktif. */
object Tool {
    private val cache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    val all: List<String> get() = ToolLog.chainAll + ToolLog.monAll
    /** Tool khusus root: otomatis nonaktif bila perangkat tidak root. */
    val rootOnly = setOf("Hook pemutar", "Dexterceptor", "Logcat root", "tcpdump", "Clipboard root")
    @Volatile private var profCache: Pair<String, Set<String>>? = null
    fun invalidateProfile() { profCache = null }
    /** Profil khusus aktif -> himpunan tool-nya; null = profil Default (pakai centang manual). */
    private fun profileSet(): Set<String>? {
        val a = AppPreferences.activeProfile
        if (a == AppPreferences.DEFAULT_PROFILE) return null
        val c = profCache
        if (c != null && c.first == a) return c.second
        val s = AppPreferences.profileTools(a) ?: return null
        profCache = a to s
        return s
    }
    /** Centang manual pengguna (dipakai profil Default & tampilan centang di panel). */
    fun manualOn(n: String): Boolean {
        if (n in rootOnly && !AppPreferences.isRooted) return false
        return cache.getOrPut(n) { Repo.prefs().getBoolean("tool_$n", true) }
    }
    /** Efektif: profil khusus = hanya tool di profil (centang manual diabaikan); Default = centang manual. */
    fun on(n: String): Boolean {
        if (n in rootOnly && !AppPreferences.isRooted) return false
        val ps = profileSet()
        if (ps != null) return n in ps
        return manualOn(n)
    }
    /** true bila profil khusus aktif DAN tool ini tidak termasuk di dalamnya (dilewati scanner). */
    fun excludedByProfile(n: String): Boolean { val ps = profileSet() ?: return false; return n !in ps }
    /** Status centang yang ditampilkan: profil khusus = isi profil; Default = centang manual. */
    fun shown(n: String): Boolean {
        if (n in rootOnly && !AppPreferences.isRooted) return false
        return profileSet()?.contains(n) ?: manualOn(n)
    }
    private fun editActive(change: (MutableSet<String>) -> Unit): Boolean {
        val a = AppPreferences.activeProfile
        if (a == AppPreferences.DEFAULT_PROFILE) return false
        val cur = (AppPreferences.profileTools(a) ?: emptySet()).toMutableSet()
        change(cur)
        AppPreferences.saveProfile(a, all.filter { it in cur })
        return true
    }
    fun set(n: String, v: Boolean) { if (editActive { if (v) it.add(n) else it.remove(n) }) return; cache[n] = v; Repo.prefs().edit().putBoolean("tool_$n", v).apply(); syncAll() }
    fun allOn(): Boolean = all.filter { AppPreferences.isRooted || it !in rootOnly }.all { shown(it) }
    private fun allOnOld(): Boolean = all.filter { AppPreferences.isRooted || it !in rootOnly }.all { manualOn(it) }
    /** Saklar "Aktifkan semua tools": ON = semua aktif (+ scan otomatis), OFF = semua mati total & scan berjalan dibatalkan. */
    fun setAll(v: Boolean) {
        if (editActive { s -> if (v) s.addAll(all.filter { AppPreferences.isRooted || it !in rootOnly }) else s.clear() }) { if (!v) ScanLimit.cancelAll(); return }
        val e = Repo.prefs().edit()
        for (n in all) { cache[n] = v; e.putBoolean("tool_$n", v) }
        if (v) e.putBoolean("scanAll", true)
        e.apply()
        if (!v) ScanLimit.cancelAll()
        syncAll()
    }
    /** Hentikan/nyalakan semua pemantau sesuai status Scan + tool (OFF = thread/proses/listener benar-benar berhenti). */
    fun syncAll() {
        try { NetSniffer.sync() } catch (e: Exception) { }
        try { AlfyAccessibilityService.inst?.applyState() } catch (e: Exception) { }
        try { AlfyNotifService.inst?.sync() } catch (e: Exception) { }
    }
}

/** v1.12: daftar situs yang TIDAK discan (tombol 🚫). Ada di daftar = diblokir; tidak ada = discan seperti biasa. */
object Block {
    @Volatile private var cache: List<String>? = null
    private val alias = mapOf(
        "youtube.com" to listOf("youtu.be", "googlevideo.com", "ytimg.com", "youtube-nocookie.com"),
        "x.com" to listOf("twitter.com", "twimg.com", "t.co"),
        "twitter.com" to listOf("x.com", "twimg.com", "t.co")
    )

    fun norm(s: String): String {
        var x = s.trim().lowercase().substringBefore('#').substringBefore('?')
        x = x.removePrefix("https://").removePrefix("http://").removePrefix("www.").trimEnd('/')
        return x.filter { !it.isWhitespace() }
    }

    fun list(): List<String> = cache ?: (Repo.prefs().getString("blockList", "") ?: "").lines().map { norm(it) }.filter { it.isNotEmpty() }.distinct().also { cache = it }

    private fun save(l: List<String>) { cache = l; Repo.prefs().edit().putString("blockList", l.joinToString("\n")).apply() }
    fun add(s: String): Boolean { val n = norm(s); if (n.length < 3 || !n.contains('.')) return false; val l = list(); if (n in l) return true; save(l + n); return true }
    fun remove(s: String) { save(list().filter { it != s }) }

    fun isBlocked(url: String): Boolean {
        val l = list()
        if (l.isEmpty()) return false
        val u = try { android.net.Uri.parse(url.trim()) } catch (e: Exception) { return false }
        val host = (u.host ?: return false).lowercase().removePrefix("www.")
        val path = (u.path ?: "").trim('/').lowercase()
        for (e in l) {
            val eh = e.substringBefore('/'); val ep = e.substringAfter('/', "")
            if (host == eh || host.endsWith(".$eh")) { if (ep.isEmpty() || path.startsWith(ep)) return true }
            else if (ep.isEmpty() && (alias[eh]?.any { host == it || host.endsWith(".$it") } == true)) return true
        }
        return false
    }
    /** YouTube diblokir? (dipakai pemantau judul/notifikasi yang tidak punya URL) */
    fun youtube(): Boolean = isBlocked("https://www.youtube.com/")
}

object Palette {
    val names = listOf("Pelangi", "Merah", "Oranye", "Kuning", "Hijau", "Biru", "Ungu", "Pink", "Putih", "Hitam")
    val colors = intArrayOf(0, 0xFFF44336.toInt(), 0xFFFF9800.toInt(), 0xFFFFEB3B.toInt(), 0xFF4CAF50.toInt(),
        0xFF2196F3.toInt(), 0xFF9C27B0.toInt(), 0xFFFF4081.toInt(), 0xFFFFFFFF.toInt(), 0xFF000000.toInt())
    val rainbow = intArrayOf(0xFFFF0000.toInt(), 0xFFFF9800.toInt(), 0xFFFFEB3B.toInt(), 0xFF4CAF50.toInt(),
        0xFF00BCD4.toInt(), 0xFF2196F3.toInt(), 0xFF9C27B0.toInt(), 0xFFFF0000.toInt())
}

fun uaOf(sel: String?): String? = sel?.lines()?.firstOrNull { it.startsWith("UA:") }?.substring(3)
