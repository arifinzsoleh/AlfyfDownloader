package com.alfy.downloader

import java.net.HttpURLConnection
import java.net.URL

/** Tool Tier 3 "Cobalt API": fallback universal (YouTube, TikTok, Instagram, Twitter/X, Reddit, Vimeo, SoundCloud, dll) lewat server publik Cobalt. */
object CobaltApiTool {
    private val API: String get() = AppPreferences.cobaltApiUrl

    private fun hostOf(page: String): String = try { android.net.Uri.parse(page).host?.lowercase() ?: "" } catch (e: Exception) { "" }

    private val supported = setOf(
        "youtube.com", "youtu.be", "tiktok.com", "instagram.com", "twitter.com", "x.com",
        "reddit.com", "vimeo.com", "soundcloud.com", "facebook.com", "fb.watch", "pinterest.com",
        "twitch.tv", "streamable.com", "tumblr.com", "vk.com", "ok.ru", "bilibili.com", "dailymotion.com"
    )

    fun matches(page: String): Boolean {
        val h = hostOf(page)
        return supported.any { h == it || h.endsWith(".$it") }
    }

    private fun post(url: String, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.connectTimeout = 8000; c.readTimeout = 10000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Accept", "application/json")
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code >= 400) c.errorStream else c.inputStream
            return stream?.bufferedReader()?.readText() ?: ""
        } finally { try { c.disconnect() } catch (e: Throwable) { } }
    }

    /** null = berhasil, selain itu alasan gagal yang jelas. */
    fun fetch(page: String): String? {
        val raw = try { post(API, org.json.JSONObject().put("url", page).toString()) } catch (e: Exception) { return "Cobalt: " + (e.message ?: "gagal").take(50) }
        val r = try { org.json.JSONObject(raw) } catch (e: Exception) { return "Cobalt: respons bukan JSON" }
        val status = r.optString("status", "")
        if (status == "error") {
            val em = r.optJSONObject("error")?.optString("code", "").orEmpty().ifBlank { r.optString("text", "") }
            return "Cobalt: " + em.ifBlank { "ditolak" }.take(60)
        }
        val out = ArrayList<Candidate>()
        val title = "Cobalt " + hostOf(page)
        when (status) {
            "picker" -> {
                val picker = r.optJSONArray("picker") ?: org.json.JSONArray()
                for (i in 0 until minOf(picker.length(), 10)) {
                    val o = picker.optJSONObject(i) ?: continue
                    val u = o.optString("url", ""); if (u.isEmpty()) continue
                    val type = o.optString("type", "video")
                    val isImg = type == "photo" || type == "gif"
                    out.add(Candidate(key = "COBALT" + u.take(150), url = u, title = title,
                        kind = Kind.DIRECT, isAudio = false, ext = Resolver.extOf(u).ifEmpty { if (isImg) "jpg" else "mp4" },
                        size = -1, quality = type, duration = 0, formatSel = null, previewUrl = u, referer = page))
                }
                r.optString("audio", "").takeIf { it.startsWith("http") }?.let { au ->
                    out.add(Candidate(key = "COBALT" + au.take(150), url = au, title = title, kind = Kind.DIRECT, isAudio = true,
                        ext = Resolver.extOf(au).ifEmpty { "mp3" }, size = -1, quality = "audio", duration = 0, formatSel = null,
                        previewUrl = au, referer = page, audioUrl = au))
                }
            }
            "stream", "redirect", "tunnel" -> {
                val u = r.optString("url", ""); if (u.isEmpty()) return "Cobalt: tanpa link"
                out.add(Candidate(key = "COBALT" + u.take(150), url = u, title = title,
                    kind = if (Resolver.extOf(u) == "m3u8") Kind.HLS else Kind.DIRECT, isAudio = false,
                    ext = if (Resolver.extOf(u) == "m3u8") "mp4" else Resolver.extOf(u).ifEmpty { "mp4" },
                    size = -1, quality = "-", duration = 0, formatSel = null, previewUrl = u, referer = page))
            }
            else -> return "Cobalt: status tidak dikenal (${status.ifBlank { "-" }})"
        }
        if (out.isEmpty()) return "Cobalt: tanpa link media"
        Repo.addCandidates(out)
        return null
    }
}
