package com.alfy.downloader.extras

import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Pembungkus tipis libsu untuk pemantau root (logcat, dumpsys media_session, clipboard). Belum dipanggil kode lama. */
object RootShell {
    fun granted(): Boolean = try { Shell.getShell().isRoot } catch (e: Throwable) { false }
    fun run(vararg cmd: String): List<String> = try { Shell.cmd(*cmd).exec().out } catch (e: Throwable) { emptyList() }
    fun ok(vararg cmd: String): Boolean = try { Shell.cmd(*cmd).exec().isSuccess } catch (e: Throwable) { false }

    @Volatile private var granting = false
    private const val PKG = "com.alfy.downloader"
    private const val SVC = "com.alfy.downloader/com.alfy.downloader.AlfyAccessibilityService"

    /** Auto-grant via root (background, aman): izin runtime + aktifkan layanan Aksesibilitas. Tidak pernah melempar exception. */
    fun autoGrant() {
        if (granting) return
        granting = true
        try {
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    if (!com.alfy.downloader.RootGate.ensure()) return@launch
                    for (p in listOf("WRITE_EXTERNAL_STORAGE", "READ_EXTERNAL_STORAGE", "POST_NOTIFICATIONS"))
                        ok("pm grant $PKG android.permission.$p")
                    val cur = run("settings get secure enabled_accessibility_services").firstOrNull()?.trim().orEmpty()
                    val list = if (cur.isEmpty() || cur == "null") emptyList() else cur.split(":").filter { it.isNotBlank() }
                    if (list.none { it.equals(SVC, true) || it.endsWith("AlfyAccessibilityService") }) {
                        ok("settings put secure enabled_accessibility_services '${(list + SVC).joinToString(":")}'")
                    }
                    ok("settings put secure accessibility_enabled 1")
                } catch (e: Throwable) {
                } finally { granting = false }
            }
        } catch (e: Throwable) { granting = false }
    }
}
