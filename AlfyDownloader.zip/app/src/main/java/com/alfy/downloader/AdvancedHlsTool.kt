package com.alfy.downloader

import com.alfy.downloader.extras.AlfyHttp
import okhttp3.Request
import java.io.ByteArrayInputStream
import java.net.URI
import java.util.concurrent.ConcurrentHashMap
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Element

/**
 * Tool "Advanced HLS" (konsep libvsd): baca playlist HLS (.m3u8) dan DASH (.mpd) yang rumit, pilih kualitas
 * dengan bitrate tertinggi, dan bila ada #EXT-X-KEY (AES-128) ambil Key URI-nya lalu simpan untuk FFmpeg
 * ([ffmpegArgs] / [infoFor]). Tidak menjalankan FFmpeg sendiri dan tidak mengubah tool lain.
 */
object AdvancedHlsTool {
    const val NAME = "Advanced HLS"

    class Variant(val url: String, val bandwidth: Long, val width: Int, val height: Int, val audioGroup: String?)

    class Info(
        val sourceUrl: String,        // playlist yang dibaca (master / mpd)
        val kind: String,             // "m3u8" | "mpd"
        val bestUrl: String,          // alamat yang dikirim ke daftar download
        val bandwidth: Long,          // bps tertinggi
        val width: Int, val height: Int,
        val variants: Int,
        val keyMethod: String,        // "" | AES-128 | SAMPLE-AES | DRM
        val keyUri: String,           // Key URI absolut (AES-128)
        val keyIv: String,
        val keyHex: String,           // isi kunci 16 byte (hex) bila berhasil diambil
        val externalAudio: Boolean,
        val live: Boolean
    ) {
        fun label(): String {
            val p = StringBuilder()
            p.append(if (height > 0) "${height}p" else if (kind == "mpd") "DASH" else "HLS")
            if (bandwidth > 0) p.append(" • ").append(String.format(java.util.Locale.US, "%.1f Mbps", bandwidth / 1_000_000.0))
            if (keyMethod.isNotEmpty()) p.append(" • ").append(keyMethod)
            if (live) p.append(" • LIVE")
            return p.toString()
        }
        val encrypted get() = keyMethod.isNotEmpty()
    }

    private val infos = ConcurrentHashMap<String, Info>()
    @Volatile var hits = 0
    @Volatile var last = ""

    fun status(): String = if (hits > 0) "✓ $hits playlist • $last" else "⏳ siaga membaca .m3u8/.mpd"
    fun infoFor(url: String): Info? = infos[url]

    /** Argumen FFmpeg untuk stream terenkripsi (kunci diambil ffmpeg lewat Key URI dengan header yang sama). Kosong bila url tidak dikenal. */
    fun ffmpegArgs(url: String): List<String> {
        infos[url] ?: return emptyList()
        val a = ArrayList<String>()
        a.addAll(listOf("-allowed_extensions", "ALL", "-protocol_whitelist", "file,http,https,tcp,tls,crypto"))
        return a
    }

    fun kindOf(u: String): String {
        val p = u.substringBefore('#').substringBefore('?').lowercase()
        return when { p.endsWith(".m3u8") -> "m3u8"; p.endsWith(".mpd") -> "mpd"; else -> "" }
    }

    // ---------- jaringan ----------
    private fun get(url: String, referer: String?, maxBytes: Int = 2_000_000): String? = try {
        val rb = Request.Builder().url(url).header("User-Agent", Resolver.UA).header("Accept", "*/*")
        if (!referer.isNullOrBlank() && referer.startsWith("http")) {
            rb.header("Referer", referer)
            try { val u = URI(referer); rb.header("Origin", "${u.scheme}://${u.host}") } catch (e: Throwable) { }
        }
        try { Resolver.webCookie(url, referer)?.takeIf { it.isNotBlank() }?.let { rb.header("Cookie", it) } } catch (e: Throwable) { }
        AlfyHttp.client.newCall(rb.build()).execute().use { r ->
            if (!r.isSuccessful) null else r.body?.string()?.take(maxBytes)
        }
    } catch (e: Throwable) { null }

    private fun getBytes(url: String, referer: String?): ByteArray? = try {
        val rb = Request.Builder().url(url).header("User-Agent", Resolver.UA)
        if (!referer.isNullOrBlank() && referer.startsWith("http")) {
            rb.header("Referer", referer)
            try { val u = URI(referer); rb.header("Origin", "${u.scheme}://${u.host}") } catch (e: Throwable) { }
        }
        try { Resolver.webCookie(url, referer)?.takeIf { it.isNotBlank() }?.let { rb.header("Cookie", it) } } catch (e: Throwable) { }
        AlfyHttp.client.newCall(rb.build()).execute().use { r ->
            if (!r.isSuccessful) null else r.body?.bytes()?.takeIf { it.size in 1..64 }
        }
    } catch (e: Throwable) { null }

    private fun abs(base: String, ref: String): String = try { URI(base).resolve(ref.trim()).toString() } catch (e: Throwable) { ref }

    private val attrRe = Regex("([A-Z0-9-]+)=(\"[^\"]*\"|[^,]*)")
    private fun attrs(line: String): Map<String, String> {
        val m = HashMap<String, String>()
        for (x in attrRe.findAll(line.substringAfter(':'))) m[x.groupValues[1]] = x.groupValues[2].trim().removeSurrounding("\"")
        return m
    }

    // ---------- HLS ----------
    private class Key(val method: String, val uri: String, val iv: String)

    private fun findKey(text: String, base: String): Key? {
        for (l in text.lineSequence()) {
            val t = l.trim()
            if (!(t.startsWith("#EXT-X-KEY:") || t.startsWith("#EXT-X-SESSION-KEY:"))) continue
            val a = attrs(t)
            val m = (a["METHOD"] ?: "").uppercase()
            if (m.isEmpty() || m == "NONE") continue
            val u = a["URI"]?.takeIf { it.isNotBlank() }?.let { abs(base, it) } ?: ""
            return Key(m, u, a["IV"] ?: "")
        }
        return null
    }

    private fun parseHls(url: String, ref: String?): Info? {
        val text = get(url, ref) ?: return null
        if (!text.contains("#EXTM3U")) return null
        val lines = text.lines().map { it.trim() }
        var key = findKey(text, url)
        if (!text.contains("#EXT-X-STREAM-INF")) {
            val k = key
            val hex = if (k != null && k.method == "AES-128" && k.uri.isNotEmpty()) getBytes(k.uri, ref)?.joinToString("") { "%02x".format(it) } ?: "" else ""
            return Info(url, "m3u8", url, 0, 0, 0, 1, k?.method ?: "", k?.uri ?: "", k?.iv ?: "", hex, false, !text.contains("#EXT-X-ENDLIST"))
        }
        val vs = ArrayList<Variant>()
        var i = 0
        while (i < lines.size) {
            val l = lines[i]
            if (l.startsWith("#EXT-X-STREAM-INF:")) {
                val a = attrs(l)
                var j = i + 1
                while (j < lines.size && (lines[j].isEmpty() || lines[j].startsWith("#"))) j++
                if (j < lines.size) {
                    val bw = (a["BANDWIDTH"] ?: a["AVERAGE-BANDWIDTH"])?.toLongOrNull() ?: 0L
                    val res = (a["RESOLUTION"] ?: "").split('x')
                    vs.add(Variant(abs(url, lines[j]), bw, res.getOrNull(0)?.toIntOrNull() ?: 0, res.getOrNull(1)?.toIntOrNull() ?: 0, a["AUDIO"]))
                    i = j
                }
            }
            i++
        }
        if (vs.isEmpty()) return null
        val best = vs.maxWith(compareBy<Variant>({ it.bandwidth }, { it.width.toLong() * it.height }))
        // audio terpisah (EXT-X-MEDIA TYPE=AUDIO dengan URI): pakai master agar ffmpeg memasangkan video + suara
        val extAudio = best.audioGroup != null && lines.any { it.startsWith("#EXT-X-MEDIA:") && attrs(it).let { a -> a["TYPE"] == "AUDIO" && a["GROUP-ID"] == best.audioGroup && !a["URI"].isNullOrBlank() } }
        val mediaText = if (key == null) get(best.url, ref) else null
        if (key == null && mediaText != null) key = findKey(mediaText, best.url)
        val live = mediaText?.let { !it.contains("#EXT-X-ENDLIST") } ?: false
        val k = key
        val hex = if (k != null && k.method == "AES-128" && k.uri.isNotEmpty()) getBytes(k.uri, ref)?.joinToString("") { "%02x".format(it) } ?: "" else ""
        return Info(url, "m3u8", if (extAudio) url else best.url, best.bandwidth, best.width, best.height, vs.size,
            k?.method ?: "", k?.uri ?: "", k?.iv ?: "", hex, extAudio, live)
    }

    // ---------- DASH ----------
    private fun parseMpd(url: String, ref: String?): Info? {
        val text = get(url, ref) ?: return null
        if (!text.contains("<MPD")) return null
        return try {
            val f = DocumentBuilderFactory.newInstance()
            try { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) } catch (e: Throwable) { }
            val doc = f.newDocumentBuilder().parse(ByteArrayInputStream(text.toByteArray(Charsets.UTF_8)))
            val reps = doc.getElementsByTagName("Representation")
            var bw = 0L; var w = 0; var h = 0; var n = 0
            for (idx in 0 until reps.length) {
                val r = reps.item(idx) as Element
                val p = r.parentNode as? Element
                val mime = (r.getAttribute("mimeType").ifEmpty { p?.getAttribute("mimeType") ?: "" } + (p?.getAttribute("contentType") ?: "")).lowercase()
                if (!mime.contains("video") && (r.getAttribute("width").isEmpty() && p?.getAttribute("width").isNullOrEmpty())) continue
                n++
                val b = r.getAttribute("bandwidth").toLongOrNull() ?: 0L
                if (b >= bw) {
                    bw = b
                    w = r.getAttribute("width").toIntOrNull() ?: p?.getAttribute("width")?.toIntOrNull() ?: 0
                    h = r.getAttribute("height").toIntOrNull() ?: p?.getAttribute("height")?.toIntOrNull() ?: 0
                }
            }
            if (n == 0) return null
            val cp = doc.getElementsByTagName("ContentProtection")
            var drm = false
            for (idx in 0 until cp.length) {
                val s = (cp.item(idx) as Element).getAttribute("schemeIdUri").lowercase()
                if (!s.contains("mp4protection")) drm = true
            }
            val live = (doc.documentElement.getAttribute("type") ?: "").equals("dynamic", true)
            Info(url, "mpd", url, bw, w, h, n, if (drm) "DRM" else "", "", "", "", false, live)
        } catch (e: Throwable) { null }
    }

    fun parse(url: String, ref: String?): Info? {
        val info = when (kindOf(url)) { "m3u8" -> parseHls(url, ref); "mpd" -> parseMpd(url, ref); else -> parseHls(url, ref) ?: parseMpd(url, ref) } ?: return null
        infos[info.sourceUrl] = info; infos[info.bestUrl] = info
        return info
    }

    // ---------- tool rantai ----------
    private val linkRe = Regex("https?:(?:\\\\?/){2}[^\"'\\s<>\\\\]+(?:\\\\/[^\"'\\s<>\\\\]*)*?\\.(?:m3u8|mpd)(?:\\?[^\"'\\s<>]*)?", RegexOption.IGNORE_CASE)

    /** Tool rantai: halaman / alamat playlist -> parse -> kualitas terbaik masuk daftar download. null = berhasil. */
    fun run(page: String): String? {
        val urls = LinkedHashSet<String>()
        if (kindOf(page).isNotEmpty()) urls.add(page)
        else {
            val html = get(page, page, 1_500_000) ?: return "halaman tidak terbaca"
            for (m in linkRe.findAll(html.replace("&amp;", "&"))) {
                urls.add(m.value.replace("\\/", "/"))
                if (urls.size >= 6) break
            }
        }
        if (urls.isEmpty()) return "tidak ada playlist .m3u8/.mpd"
        var ok = 0; var drm = 0
        for (u in urls) {
            if (Thread.currentThread().isInterrupted) break
            val i = parse(u, page) ?: continue
            if (i.keyMethod == "DRM") { drm++; continue }
            ok++; hits++
            last = i.kind + " • " + i.label()
            ToolLog.side(NAME, "✓ $hits playlist ($last)")
            Repo.addCandidates(listOf(Candidate(
                key = "AHLS" + i.sourceUrl.take(150), url = i.bestUrl,
                title = Resolver.nameOf(i.sourceUrl).ifBlank { if (i.kind == "mpd") "Stream DASH" else "Stream HLS" },
                kind = if (i.kind == "m3u8") Kind.HLS else Kind.YTDLP, isAudio = false, ext = "mp4", size = -1,
                quality = i.label(), duration = 0, formatSel = null, previewUrl = i.bestUrl, referer = page, source = NAME)))
        }
        return if (ok > 0) null else if (drm > 0) "stream DASH berDRM (tidak bisa diunduh)" else "playlist tidak terbaca"
    }
}
