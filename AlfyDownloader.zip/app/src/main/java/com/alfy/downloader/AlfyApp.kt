package com.alfy.downloader

import android.app.Application
import android.os.StrictMode
import android.util.Log
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLException
import kotlinx.coroutines.launch

object Engine {
    @Volatile var ready = false
    @Volatile var initDone = false
    @Volatile var error: String? = null
    @Volatile var ffmpeg = "• memuat…"
    @Volatile var ffBusy = 0
    /** v1.65: FFmpeg hanya "hidup" saat download/convert; idle = dilepas (status siaga + GC). */
    fun ffBegin() { synchronized(this) { ffBusy++ }; if (!ffmpeg.startsWith("✗")) ffmpeg = "✓ berjalan" }
    fun ffEnd() {
        var idle = false
        synchronized(this) { if (--ffBusy <= 0) { ffBusy = 0; idle = true } }
        if (idle) { if (!ffmpeg.startsWith("✗")) ffmpeg = "✓ siaga (idle, dilepas)"; try { System.gc() } catch (e: Throwable) { } }
    }
    fun await() {
        var n = 0
        while (!ready && n < 400) { Thread.sleep(300); n++ }
        if (!ready) throw Exception("Mesin unduh belum siap: $error")
    }
}

class AlfyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val prevHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = java.io.StringWriter(); e.printStackTrace(java.io.PrintWriter(sw))
                val ts = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())
                java.io.File(filesDir, "crash_log.txt").appendText("=== $ts thread=${t.name} ===\n$sw\n")
            } catch (x: Throwable) { }
            if (prevHandler != null) prevHandler.uncaughtException(t, e)
            else { android.os.Process.killProcess(android.os.Process.myPid()); System.exit(10) }
        }
        Repo.init(this)
        NetAdblock.init(this)   // adblock host-based
        // v1.8: izin root diminta SEKALI di awal (mencakup logcat, tcpdump, media_session, clipboard, dll)
        Thread { if (!RootGate.ensure()) RootGate.watch() }.apply { isDaemon = true }.start()
        try { com.alfy.downloader.extras.RootShell.autoGrant() } catch (e: Throwable) { }
        try { VpnTool.reapply() } catch (e: Throwable) { }
        StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder().build())
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            var ok = false
            var firstErr = ""
            try {
                YoutubeDL.getInstance().init(this@AlfyApp)
                try { FFmpeg.getInstance().init(this@AlfyApp); Engine.ffmpeg = "✓ siap" }
                catch (e: Throwable) { Engine.ffmpeg = "✗ " + (e.message ?: "gagal").take(60); throw e }
                ok = true
            } catch (e: Throwable) {
                firstErr = e.message ?: e.javaClass.simpleName
                Engine.error = firstErr
                Log.e("Alfy", "init bawaan gagal, coba paksa via root", e)
            }
            if (!ok) {
                try {
                    RootInit.force(this@AlfyApp)
                    Engine.ffmpeg = "✓ siap (root)"; Engine.error = null; ok = true
                } catch (e: Throwable) {
                    Engine.ffmpeg = "✗ root gagal"
                    Engine.error = "init bawaan: $firstErr | root: ${e.message ?: e.javaClass.simpleName}"
                    Log.e("Alfy", "init root gagal", e)
                }
            }
            Engine.ready = ok
            Engine.initDone = true
            if (ok) {
                // v1.9: update yt-dlp ke versi terbaru dicoba ulang (jaringan/VPN sering belum siap saat aplikasi dibuka)
                var n = 0
                while (n < 8 && !updateEngine()) { try { kotlinx.coroutines.delay(30_000) } catch (e: Exception) { }; n++ }
            }
        }
    }
}

/** Perbarui yt-dlp ke versi terbaru (YouTube sering berubah; versi lama memunculkan "Please sign in"). */
fun Application.updateEngine(): Boolean {
    try {
        val yd = YoutubeDL.getInstance()
        for (chan in listOf("NIGHTLY", "STABLE")) {
            for (m in yd.javaClass.methods.filter { it.name == "updateYoutubeDL" }) {
                try {
                    val pt = m.parameterTypes
                    val args = arrayOfNulls<Any>(pt.size)
                    for (k in pt.indices) {
                        args[k] = when {
                            android.content.Context::class.java.isAssignableFrom(pt[k]) -> this
                            else -> {
                                val cls = pt[k]
                                val f = cls.fields.firstOrNull { it.name.equals(chan, true) || it.name.equals("_$chan", true) }
                                f?.get(null) ?: cls.enumConstants?.firstOrNull { it.toString().equals(chan, true) }
                                    ?: cls.declaredClasses.firstOrNull { it.simpleName.equals(chan, true) || it.simpleName.equals("_$chan", true) }
                                        ?.getField("INSTANCE")?.get(null)
                            }
                        }
                    }
                    if (args.any { it == null }) continue
                    m.invoke(yd, *args)
                    Resolver.diag = "yt-dlp diperbarui ($chan)"
                    return true
                } catch (e: Throwable) { }
            }
        }
    } catch (e: Throwable) { }
    return false
}

/** Paksa init youtubedl-android/FFmpeg lewat root (ROM kustom Android 12 dengan batasan W^X): binary diekstrak ke /data/local/tmp/alfy lalu chmod 755. */
object RootInit {
    private const val DIR = "/data/local/tmp/alfy"
    private fun su(cmd: String): Pair<Int, String> {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText().trim()
        return p.waitFor() to out
    }
    private fun unzipTo(ins: java.io.InputStream, dest: java.io.File) {
        java.util.zip.ZipInputStream(ins).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val f = java.io.File(dest, e.name)
                if (!f.canonicalPath.startsWith(dest.canonicalPath)) throw SecurityException("zip-slip: ${e.name}")
                if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); f.outputStream().use { o -> z.copyTo(o) } }
                e = z.nextEntry
            }
        }
    }
    private fun setField(o: Any, name: String, v: java.io.File) {
        var c: Class<*>? = o.javaClass
        while (c != null) {
            try {
                val f = c.getDeclaredField(name); f.isAccessible = true
                f.set(o, if (f.type == String::class.java) v.absolutePath else v); return
            } catch (e: NoSuchFieldException) { c = c.superclass }
        }
    }
    private fun setFlag(o: Any, name: String) {
        try { val f = o.javaClass.getDeclaredField(name); f.isAccessible = true; f.setBoolean(o, true) } catch (e: Throwable) { }
    }
    fun force(app: Application) {
        val (rc, who) = su("id -u")
        if (rc != 0 || who.lines().last().trim() != "0") throw Exception("akses root tidak tersedia (rc=$rc): $who")
        val abi = android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"
        val stage = java.io.File(app.cacheDir, "alfy_stage"); stage.deleteRecursively()
        val lib = java.io.File(stage, "lib").apply { mkdirs() }
        val pk = java.io.File(stage, "packages").apply { mkdirs() }
        java.util.zip.ZipFile(app.applicationInfo.sourceDir).use { z ->
            var py = false; var ff = false
            for (e in z.entries()) {
                if (e.isDirectory || !e.name.startsWith("lib/$abi/") || !e.name.endsWith(".so")) continue
                val n = e.name.substringAfterLast('/')
                z.getInputStream(e).use { i -> java.io.File(lib, n).outputStream().use { o -> i.copyTo(o) } }
                when (n) {
                    "libpython.zip.so" -> { unzipTo(java.io.File(lib, n).inputStream(), java.io.File(pk, "python")); py = true }
                    "libffmpeg.zip.so" -> { unzipTo(java.io.File(lib, n).inputStream(), java.io.File(pk, "ffmpeg")); ff = true }
                }
            }
            if (!py || !ff) throw Exception("libpython.zip.so/libffmpeg.zip.so tidak ada di APK (abi=$abi)")
        }
        val (r2, o2) = su("rm -rf $DIR && mkdir -p $DIR && cp -r ${stage.absolutePath}/. $DIR/ && chmod -R 755 $DIR")
        stage.deleteRecursively()
        if (r2 != 0) throw Exception("salin/chmod via root gagal (rc=$r2): $o2")
        val bin = java.io.File("$DIR/lib"); val root = java.io.File("$DIR/packages")
        for (o in listOf<Any>(YoutubeDL.getInstance(), FFmpeg.getInstance())) {
            setField(o, "binDir", bin); setField(o, "packagesRoot", root)
            setField(o, "pythonPath", java.io.File(bin, "libpython.so"))
            setField(o, "ffmpegPath", java.io.File(root, "ffmpeg/usr/lib/libffmpeg.so"))
            setField(o, "ENV_LD_LIBRARY_PATH", java.io.File(root, "python/usr/lib").absolutePath.let { java.io.File("$it:${root.absolutePath}/ffmpeg/usr/lib") })
            setField(o, "ENV_PYTHONHOME", java.io.File(root, "python/usr"))
            setField(o, "ENV_SSL_CERT_FILE", java.io.File(root, "python/usr/etc/tls/cert.pem"))
        }
        if (!java.io.File(bin, "libpython.so").exists()) throw Exception("libpython.so tidak ditemukan di $DIR/lib")
        for (o in listOf<Any>(YoutubeDL.getInstance(), FFmpeg.getInstance())) setFlag(o, "initialized")
    }
}
