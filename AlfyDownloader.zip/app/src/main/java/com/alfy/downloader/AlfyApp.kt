package com.alfy.downloader

import android.app.Application
import android.os.StrictMode
import android.util.Log
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL

object Engine {
    @Volatile var ready = false
    @Volatile var error: String? = null
    @Volatile var ffmpeg = "• memuat…"
    fun await() {
        var n = 0
        while (!ready && n < 400) { Thread.sleep(300); n++ }
        if (!ready) throw Exception("Mesin unduh belum siap: $error")
    }
}

class AlfyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val prevHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = java.io.StringWriter(); e.printStackTrace(java.io.PrintWriter(sw))
                val ts = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())
                java.io.File(filesDir, "crash_log.txt").appendText("=== $ts thread=${t.name} ===\n$sw\n")
            } catch (x: Throwable) { }
            if (prevHandler != null) prevHandler.uncaughtException(t, e)
            else { android.os.Process.killProcess(android.os.Process.myPid()); System.exit(10) }
        }
        Repo.init(this)
        NetAdblock.init(this)   // adblock host-based
        // v1.8: izin root diminta SEKALI di awal (mencakup logcat, tcpdump, media_session, clipboard, dll)
        Thread { if (!RootGate.ensure()) RootGate.watch() }.apply { isDaemon = true }.start()
        try { com.alfy.downloader.extras.RootShell.autoGrant() } catch (e: Throwable) { }
        try { VpnTool.reapply() } catch (e: Throwable) { }
        StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder().build())
        Thread {
            try {
                YoutubeDL.getInstance().init(this)
                try { FFmpeg.getInstance().init(this); Engine.ffmpeg = "✓ siap" } catch (e: Throwable) { Engine.ffmpeg = "✗ " + (e.message ?: "gagal").take(60) }
                Engine.ready = true
                // v1.9: update yt-dlp ke versi terbaru dicoba ulang (jaringan/VPN sering belum siap saat aplikasi dibuka)
                var n = 0
                while (n < 8 && !updateEngine()) { try { Thread.sleep(30_000) } catch (e: Exception) { }; n++ }
            } catch (e: Throwable) {
                Engine.error = e.message
                Log.e("Alfy", "init gagal", e)
            }
        }.start()
    }
}

/** Perbarui yt-dlp ke versi terbaru (YouTube sering berubah; versi lama memunculkan "Please sign in"). */
fun Application.updateEngine(): Boolean {
    try {
        val yd = YoutubeDL.getInstance()
        for (chan in listOf("NIGHTLY", "STABLE")) {
            for (m in yd.javaClass.methods.filter { it.name == "updateYoutubeDL" }) {
                try {
                    val pt = m.parameterTypes
                    val args = arrayOfNulls<Any>(pt.size)
                    for (k in pt.indices) {
                        args[k] = when {
                            android.content.Context::class.java.isAssignableFrom(pt[k]) -> this
                            else -> {
                                val cls = pt[k]
                                val f = cls.fields.firstOrNull { it.name.equals(chan, true) || it.name.equals("_$chan", true) }
                                f?.get(null) ?: cls.enumConstants?.firstOrNull { it.toString().equals(chan, true) }
                                    ?: cls.declaredClasses.firstOrNull { it.simpleName.equals(chan, true) || it.simpleName.equals("_$chan", true) }
                                        ?.getField("INSTANCE")?.get(null)
                            }
                        }
                    }
                    if (args.any { it == null }) continue
                    m.invoke(yd, *args)
                    Resolver.diag = "yt-dlp diperbarui ($chan)"
                    return true
                } catch (e: Throwable) { }
            }
        }
    } catch (e: Throwable) { }
    return false
}
