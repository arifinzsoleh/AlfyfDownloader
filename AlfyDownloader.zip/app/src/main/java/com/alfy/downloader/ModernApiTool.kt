package com.alfy.downloader

/** Tool Tier 3 "Modern API": Threads, CapCut, Xiaohongshu (RedNote) lewat btch-downloader API. Parser JSON dipakai bersama BtchApiTool. */
object ModernApiTool {
    private fun hostOf(page: String): String = try { android.net.Uri.parse(page).host?.lowercase() ?: "" } catch (e: Exception) { "" }

    /** Daftar endpoint (dicoba berurutan) untuk alamat ini, atau null bila tidak didukung. */
    private fun endpoints(page: String): List<String>? {
        val h = hostOf(page)
        return when {
            h.endsWith("threads.net") || h.endsWith("threads.com") -> listOf("threads")
            h.endsWith("capcut.com") -> listOf("capcut")
            h.endsWith("xiaohongshu.com") || h.endsWith("xhslink.com") || h.endsWith("rednote.com") -> listOf("rednote", "xiaohongshu")
            else -> null
        }
    }

    fun matches(page: String): Boolean = endpoints(page) != null

    /** null = berhasil, selain itu alasan gagal yang jelas. */
    fun fetch(page: String): String? {
        val eps = endpoints(page) ?: return "situs tidak didukung (Threads/CapCut/RedNote)"
        return BtchApiTool.fetchEp(page, eps, "MAPI")
    }
}
