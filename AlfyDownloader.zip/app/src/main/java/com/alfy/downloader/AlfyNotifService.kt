package com.alfy.downloader

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.service.notification.NotificationListenerService

/** Pendeteksi tanpa root: membaca judul + channel video YouTube/ReVanced yang sedang diputar lewat MediaSession (butuh izin Akses Notifikasi). */
class AlfyNotifService : NotificationListenerService() {
    companion object {
        @Volatile var inst: AlfyNotifService? = null
        @Volatile var status = "Notifikasi: belum diizinkan (tekan tombol di 📖)"
        fun enabled(c: android.content.Context): Boolean =
            (android.provider.Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners") ?: "").contains(c.packageName)
    }

    private var msm: MediaSessionManager? = null
    private val ctrls = HashMap<String, Pair<MediaController, MediaController.Callback>>()
    private var lastQ = ""
    private val listener = MediaSessionManager.OnActiveSessionsChangedListener { l -> attach(l) }

    private var attached = false
    private val cn by lazy { ComponentName(this, AlfyNotifService::class.java) }

    override fun onListenerConnected() {
        super.onListenerConnected()
        inst = this
        try { msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager } catch (e: Exception) { }
        sync()
    }

    /** Scan/tool Notifikasi OFF => lepas listener + semua callback MediaController. */
    fun sync() {
        val m = msm ?: return
        val on = Scan.enabled() && Tool.on("Notifikasi")
        if (on && !attached) {
            try {
                m.addOnActiveSessionsChangedListener(listener, cn)
                attached = true
                attach(m.getActiveSessions(cn))
                status = "Notifikasi: aktif ✓ (menunggu video diputar)"
            } catch (e: Exception) { status = "Notifikasi: gagal ${(e.message ?: "").take(60)}" }
        } else if (!on && attached) {
            attached = false
            try { m.removeOnActiveSessionsChangedListener(listener) } catch (e: Exception) { }
            ctrls.values.forEach { try { it.first.unregisterCallback(it.second) } catch (e: Exception) { } }
            ctrls.clear()
            status = "Notifikasi: – dimatikan"
            try { if (android.os.Build.VERSION.SDK_INT >= 24) requestUnbind() } catch (e: Exception) { }   // Fase 6: lepas dari sistem
        }
    }

    private fun attach(list: List<MediaController>?) {
        if (list == null) return
        for (c in list) {
            val pkg = c.packageName ?: continue
            val yt = pkg.contains("youtube", true)
            ctrls.remove(pkg)?.let { try { it.first.unregisterCallback(it.second) } catch (e: Exception) { } }
            val cb = object : MediaController.Callback() {
                override fun onMetadataChanged(metadata: MediaMetadata?) { if (yt) handle(metadata) }
                // v1.7: aplikasi non-YouTube mulai memutar media -> pemindaian otomatis semua alat
                override fun onPlaybackStateChanged(state: android.media.session.PlaybackState?) {
                    if (!yt && Tool.on("Notifikasi") && state?.state == android.media.session.PlaybackState.STATE_PLAYING) AutoScan.onPlay(pkg)
                }
            }
            try {
                c.registerCallback(cb); ctrls[pkg] = Pair(c, cb)
                if (yt) handle(c.metadata)
                else if (Tool.on("Notifikasi") && c.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING) AutoScan.onPlay(pkg)
            } catch (e: Exception) { }
        }
    }

    private fun handle(m: MediaMetadata?) {
        if (m == null || !Tool.on("Notifikasi")) return
        val t = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return
        val a = m.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val q = (a + " " + t).trim()
        if (t.length < 3 || q == lastQ) return
        lastQ = q
        status = "Notifikasi: ✓ ${q.take(40)}"
        Resolver.latestYt = q
        Resolver.searchYoutube(q, false)
    }

    override fun onListenerDisconnected() {
        status = "Notifikasi: terputus"
        inst = null; attached = false
        ctrls.values.forEach { try { it.first.unregisterCallback(it.second) } catch (e: Exception) { } }; ctrls.clear()
        try { msm?.removeOnActiveSessionsChangedListener(listener) } catch (e: Exception) { }
        super.onListenerDisconnected()
    }
}
