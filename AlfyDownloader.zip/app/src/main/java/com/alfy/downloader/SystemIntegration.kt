package com.alfy.downloader

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import java.net.URL

/** Penangan link http/https dari aplikasi lain: pilih browser aplikasi ini atau browser lain. */
class LinkHandlerActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val uri = intent?.data
        val scheme = uri?.scheme?.lowercase()
        if (uri == null || (scheme != "http" && scheme != "https")) { finish(); return }
        val url = uri.toString()
        val d = AlertDialog.Builder(this)
            .setTitle("Buka link")
            .setMessage(url)
            .setPositiveButton("Browser aplikasi ini") { _, _ ->
                try { startActivity(Intent(this, BrowserActivity::class.java).putExtra("url", url)) }
                catch (e: Exception) { Toast.makeText(this, "Gagal membuka browser aplikasi", Toast.LENGTH_SHORT).show() }
                finish()
            }
            .setNegativeButton("Browser lain") { _, _ -> openOther(uri); finish() }
            .setNeutralButton("Batal") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .create()
        d.show()
    }

    private fun openOther(uri: Uri) {
        try {
            val target = Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)
            val ch = Intent.createChooser(target, "Buka dengan browser")
            ch.putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS, arrayOf(ComponentName(this, LinkHandlerActivity::class.java)))
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(ch)
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak ada browser lain yang terpasang", Toast.LENGTH_LONG).show()
        }
    }
}

object SiteShortcut {
    /** Buat pinned shortcut ke situs [url]; aman bila launcher tidak mendukung. */
    fun pin(ctx: Context, url: String?, title: String?, favicon: Bitmap?) {
        try {
            if (url.isNullOrBlank() || !(url.startsWith("http://") || url.startsWith("https://"))) {
                Toast.makeText(ctx, "Buka halaman web dulu", Toast.LENGTH_SHORT).show(); return
            }
            if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) {
                Toast.makeText(ctx, "Launcher kamu tidak mendukung shortcut di layar utama", Toast.LENGTH_LONG).show(); return
            }
            val host = try { Uri.parse(url).host ?: "" } catch (e: Exception) { "" }
            val label = (title?.takeIf { it.isNotBlank() } ?: host.ifEmpty { "Situs" }).take(24)
            val open = Intent(ctx, BrowserActivity::class.java).setAction(Intent.ACTION_VIEW).putExtra("url", url)
            val icon = if (favicon != null && favicon.width > 0) IconCompat.createWithBitmap(square(favicon))
                       else IconCompat.createWithResource(ctx, R.mipmap.ic_launcher)
            val info = ShortcutInfoCompat.Builder(ctx, "site_" + (if (host.isEmpty()) url.hashCode().toString() else host))
                .setShortLabel(label).setLongLabel(label).setIcon(icon).setIntent(open).build()
            val ok = ShortcutManagerCompat.requestPinShortcut(ctx, info, null)
            Toast.makeText(ctx, if (ok) "Konfirmasi penambahan shortcut di layar utama" else "Launcher menolak membuat shortcut", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, "Gagal membuat shortcut: " + (e.message ?: "tidak didukung"), Toast.LENGTH_LONG).show()
        }
    }

    /** Pakai favicon dari WebView; bila kosong, coba unduh /favicon.ico di thread terpisah. */
    fun pinWithFavicon(ctx: Context, url: String?, title: String?, wvFavicon: Bitmap?) {
        if (wvFavicon != null || url.isNullOrBlank()) { pin(ctx, url, title, wvFavicon); return }
        Thread {
            var bmp: Bitmap? = null
            try {
                val u = Uri.parse(url)
                val c = URL(u.scheme + "://" + u.host + "/favicon.ico").openConnection()
                c.connectTimeout = 4000; c.readTimeout = 4000
                bmp = c.getInputStream().use { BitmapFactory.decodeStream(it) }
            } catch (e: Throwable) { }
            val b = bmp
            android.os.Handler(android.os.Looper.getMainLooper()).post { pin(ctx, url, title, b) }
        }.start()
    }

    private fun square(src: Bitmap): Bitmap {
        val s = 192
        val out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(out); c.drawColor(0xFFFFFFFF.toInt())
        val p = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)
        val m = 24
        c.drawBitmap(src, null, android.graphics.Rect(m, m, s - m, s - m), p)
        return out
    }
}
