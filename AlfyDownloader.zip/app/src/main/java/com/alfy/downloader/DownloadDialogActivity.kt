package com.alfy.downloader

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.UUID

class DownloadDialogActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val key = intent.getStringExtra("key") ?: ""
        val c = Repo.detected.value.firstOrNull { it.key == key }
        if (c == null) { finish(); return }
        setContent { AlfyTheme { DialogUI(c) { finish() } } }
    }
}

/** v1.63: URL halaman asli (YouTube/Instagram) agar mode non-root bisa memakai yt-dlp + ffmpeg (video+suara tergabung). */
fun pageOf(c: Candidate): String {
    val k = c.key
    val yid = Regex("^(?:YF|PP|IV|G)([\\w-]{11})\\|").find(k)?.groupValues?.get(1)
    if (yid != null) return "https://www.youtube.com/watch?v=$yid"
    if (k.startsWith("Y") && !k.startsWith("YF")) { val u = k.substring(1).substringBeforeLast('|'); if (u.startsWith("http")) return u }
    if (Regex("^https?://(?:[\\w-]+\\.)*(?:youtube\\.com|youtu\\.be)/", RegexOption.IGNORE_CASE).containsMatchIn(c.url) && !c.url.contains("googlevideo", true)) return c.url
    val r = c.referer ?: ""
    if (Regex("instagram\\.com/(?:[^/]+/)?(?:reels?|p|tv|stories)/", RegexOption.IGNORE_CASE).containsMatchIn(r)) return r
    return ""
}

fun enqueue(ctx: Context, c: Candidate, name: String, dir: String, wifi: Boolean, retry: Boolean, start: Boolean, audioExt: String = "") {
    val aud = c.isAudio || audioExt.isNotEmpty()
    val id = UUID.randomUUID().toString()
    Repo.add(DlItem(
        id = id, name = name, url = c.url, kind = c.kind, isAudio = aud, toMp3 = c.toMp3 || audioExt == "mp3", source = c.source, audioExt = audioExt, page = pageOf(c),
        formatSel = c.formatSel, referer = c.referer, dir = dir,
        status = if (start) Status.QUEUED else Status.PAUSED,
        total = c.size.coerceAtLeast(0), wifiOnly = wifi, retry = retry,
        img = if (aud) c.img else "",
        thumb = if (aud) (YtCover.idOf(c.vid, c.key.takeIf { it.startsWith("Y") && !it.startsWith("YF") }?.let { Regex("^Y(?:F)?([\\w-]{11})\\|").find(it)?.groupValues?.get(1) }, c.key.takeIf { it.startsWith("YF") }?.let { Regex("^YF([\\w-]{11})\\|").find(it)?.groupValues?.get(1) }, c.key.takeIf { it.startsWith("PP") || it.startsWith("IV") }?.substring(2)?.substringBefore('|'), c.referer, c.url) ?: "") else ""
    ))
    if (start) {
        android.os.Handler(android.os.Looper.getMainLooper()).post { try { android.widget.Toast.makeText(ctx.applicationContext, "Memulai unduhan...", android.widget.Toast.LENGTH_SHORT).show() } catch (e: Throwable) { } }
        DownloadService.cmd(ctx, "start", id)
    }
}

private val TRACK_RE = Regex("^(utm_.*|fbclid|gclid|dclid|msclkid|igshid|igsh|si|feature|pp|mc_cid|mc_eid|ref_src|_ga|yclid)$", RegexOption.IGNORE_CASE)

fun normUrl(raw: String): String {
    var u = raw.trim().substringBefore('#').trim()
    val q = u.indexOf('?')
    var base = if (q >= 0) u.substring(0, q) else u
    val query = if (q >= 0) u.substring(q + 1) else ""
    val m = Regex("^(https?)://([^/]+)(.*)$", RegexOption.IGNORE_CASE).find(base)
    if (m != null) base = m.groupValues[1].lowercase() + "://" + m.groupValues[2].lowercase() + m.groupValues[3]
    base = base.trimEnd('/')
    val params = query.split('&').filter { it.isNotEmpty() && !TRACK_RE.matches(it.substringBefore('=')) }.sorted()
    return if (params.isEmpty()) base else base + "?" + params.joinToString("&")
}

fun isDuplicateUrl(url: String): Boolean {
    val n = normUrl(url)
    return Repo.downloads.value.any { normUrl(it.url) == n }
}

@Composable
fun DialogUI(c: Candidate, close: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val baseExt = when { c.kind == Kind.HLS -> "mp4"; c.toMp3 -> "mp3"; else -> c.ext }
    var ext by remember { mutableStateOf(baseExt) }
    var extMenu by remember { mutableStateOf(false) }
    val extOpts = listOf(baseExt, "mp3", "m4a").filter { it == baseExt || it == "mp3" || (it == "m4a" && c.kind == Kind.YTDLP) }.distinct()
    val audioExt = if (ext != baseExt && ext in AUDIO_EXT) ext else ""
    var name by remember { mutableStateOf(safeName(c.title)) }
    var warn by remember { mutableStateOf(hasBadChars(c.title)) }
    var auto by remember { mutableStateOf(true) }
    var path by remember { mutableStateOf(Paths.dirFor(c.isAudio).path) }
    var wifi by remember { mutableStateOf(false) }
    var retry by remember { mutableStateOf(true) }
    val autoPath = Paths.dirFor(c.isAudio || audioExt.isNotEmpty()).path

    var dupStart by remember { mutableStateOf<Boolean?>(null) }

    var clash by remember { mutableStateOf<Boolean?>(null) }
    var renaming by remember { mutableStateOf(false) }
    var renameText by remember { mutableStateOf("") }
    var renameErr by remember { mutableStateOf("") }

    fun targetDir(): java.io.File = java.io.File(if (auto) autoPath else path)
    fun fileExists(base: String): Boolean = try { java.io.File(targetDir(), base + "." + ext).exists() } catch (e: Exception) { false }

    fun go(start: Boolean, confirmed: Boolean = false, nameOverride: String? = null, skipFile: Boolean = false) {
        if (!confirmed && isDuplicateUrl(c.url)) { dupStart = start; return }
        val base = nameOverride ?: safeName(name)
        if (!skipFile && fileExists(base)) { clash = start; return }
        if (warn) try { android.widget.Toast.makeText(ctx.applicationContext, "Karakter terlarang diganti \"_\"", android.widget.Toast.LENGTH_SHORT).show() } catch (e: Exception) { }
        enqueue(ctx, c, base + "." + ext, if (auto) autoPath else path, wifi, retry, start, audioExt)
        try { android.widget.Toast.makeText(ctx.applicationContext, (if (start) "Sedang diunduh: " else "Ditambahkan ke antrean: ") + base + "." + ext, android.widget.Toast.LENGTH_LONG).show() } catch (e: Exception) { }
        close()
    }

    dupStart?.let { st ->
        AlertDialog(
            onDismissRequest = { dupStart = null },
            title = { Text("Link sudah pernah diunduh") },
            text = { Text("Link ini sudah ada di daftar/riwayat unduhan. Unduh lagi?") },
            confirmButton = { TextButton(onClick = { dupStart = null; go(st, true) }) { Text("Download lagi") } },
            dismissButton = { TextButton(onClick = { dupStart = null; close() }) { Text("Batal") } }
        )
    }

    clash?.let { st ->
        if (!renaming) AlertDialog(
            onDismissRequest = { clash = null },
            title = { Text("Berkas sudah ada") },
            text = {
                Column {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
                    TextButton(onClick = {
                        clash = null
                        val nm = try { uniqueFile(targetDir(), safeName(name) + "." + ext).name.removeSuffix("." + ext) } catch (e: Exception) { safeName(name) }
                        go(st, true, nm, true)
                    }) { Text("Simpan dengan nomor") }
                    TextButton(onClick = {
                        clash = null
                        try { java.io.File(targetDir(), safeName(name) + "." + ext).delete() } catch (e: Exception) { }
                        go(st, true, null, true)
                    }) { Text("Timpa berkas") }
                    TextButton(onClick = { renameText = safeName(name); renameErr = ""; renaming = true }) { Text("Ubah nama") }
                    TextButton(onClick = { clash = null; close() }) { Text("Batal") }
                }
                    Text("Berkas \"" + safeName(name) + "." + ext + "\" sudah ada di folder tujuan. Pilih tindakan:")
                }
            },
            confirmButton = { }
        )
        if (renaming) AlertDialog(
            onDismissRequest = { renaming = false; clash = null },
            title = { Text("Ubah nama berkas") },
            text = {
                Column {
                    OutlinedTextField(
                        value = renameText, onValueChange = { renameText = it; renameErr = "" }, singleLine = true,
                        suffix = { Text("." + ext) }, modifier = Modifier.fillMaxWidth()
                    )
                    if (renameErr.isNotEmpty()) Text(renameErr, fontSize = 12.sp, color = Color(0xFFFF7043))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val t = renameText.trim()
                    when {
                        t.isEmpty() -> renameErr = "Nama tidak boleh kosong"
                        hasBadChars(t) -> renameErr = "Karakter terlarang ( \\ / : * ? \" < > | % ) tidak boleh dipakai"
                        else -> {
                            val fin = safeName(t)
                            if (fileExists(fin)) renameErr = "Nama itu juga sudah ada"
                            else { renaming = false; clash = null; name = fin; go(st, true, fin, true) }
                        }
                    }
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { renaming = false }) { Text("Kembali") } }
        )
    }

    Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
        Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFF424242), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState())) {
                Text("Unduh berkas!", fontSize = 22.sp, color = Color.White)
                Spacer(Modifier.height(8.dp))
                Text(c.url, fontSize = 12.sp, color = Color(0xFFBDBDBD), maxLines = 3, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                Text("Simpan sebagai:", color = Color(0xFFBDBDBD))
                OutlinedTextField(
                    value = name, onValueChange = { name = it; warn = hasBadChars(it) }, singleLine = true,
                    suffix = { Text(".$ext", color = Color(0xFFFF7043)) }, modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Ekstensi:", color = Color(0xFFBDBDBD))
                    Spacer(Modifier.width(8.dp))
                    Box {
                        TextButton(onClick = { extMenu = true }) { Text(".$ext ▾", color = Color(0xFFFF7043)) }
                        DropdownMenu(expanded = extMenu, onDismissRequest = { extMenu = false }) {
                            extOpts.forEach { o -> DropdownMenuItem(text = { Text(".$o") }, onClick = { ext = o; extMenu = false }) }
                        }
                    }
                }
                if (warn) Text("Peringatan: karakter terlarang ( \\ / : * ? \" < > | ) akan diganti \"_\"", fontSize = 12.sp, color = Color(0xFFFFB300))
                Text("${c.quality} • ~${fmtSize(c.size)} • durasi ${fmtDur(c.duration)}", color = Color(0xFFBDBDBD), fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = auto, onCheckedChange = { auto = it })
                    Text("Simpan otomatis sesuai kategori (video / music)")
                }
                if (auto) Text("Folder: $autoPath", fontSize = 12.sp, color = Color(0xFFFF7043))
                else OutlinedTextField(value = path, onValueChange = { path = it }, label = { Text("Folder tujuan") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = wifi, onCheckedChange = { wifi = it }); Text("Hanya wifi")
                    Spacer(Modifier.width(12.dp))
                    Checkbox(checked = retry, onCheckedChange = { retry = it }); Text("Coba lagi")
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = { go(false) }) { Text("TAMBAH") }
                    Row {
                        TextButton(onClick = close) { Text("BATAL") }
                        TextButton(onClick = { go(true) }) { Text("MULAI") }
                    }
                }
            }
        }
    }
}
