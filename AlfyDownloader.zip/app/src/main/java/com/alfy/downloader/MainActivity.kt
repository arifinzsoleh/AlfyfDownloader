@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.alfy.downloader

import android.Manifest
import androidx.compose.foundation.ExperimentalFoundationApi
import android.app.Activity
import android.content.Context
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.alfy.downloader.extras.RootShell
import java.io.File

class MainActivity : ComponentActivity() {
    private val tick = mutableStateOf(0)
    private var askedOverlay = false

    // Izin diminta SATU PER SATU: tiap langkah menunggu pengguna selesai sebelum lanjut ke izin berikutnya.
    private var step = 0
    private var waiting = false
    private var leftApp = false
    private var gen = 0
    private val ui = android.os.Handler(android.os.Looper.getMainLooper())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        try { AppPreferences.isRooted = suExists() } catch (e: Throwable) { }
        setContent { AlfyTheme { App(tick.value) } }
        ui.postDelayed({ rootFirst() }, 300)
    }

    /** Cek apakah file `su` tersedia di perangkat (lokasi umum + PATH). */
    private fun suExists(): Boolean {
        val dirs = ArrayList<String>(listOf("/system/bin", "/system/xbin", "/sbin", "/su/bin", "/system/sbin", "/vendor/bin",
            "/data/local/xbin", "/data/local/bin", "/system/bin/failsafe", "/data/local", "/apex/com.android.runtime/bin",
            "/data/adb/ksu/bin", "/data/adb/magisk", "/debug_ramdisk"))
        System.getenv("PATH")?.split(":")?.filter { it.isNotBlank() }?.let { dirs.addAll(it) }
        return dirs.distinct().any { try { java.io.File(it, "su").exists() } catch (e: Throwable) { false } }
    }

    /** v1.9: izin ROOT diminta PERTAMA (sekali, mencakup semua alat), baru izin lain; izin lain otomatis ikut diberikan lewat root. */
    private fun rootFirst() {
        Thread {
            val was = RootGate.granted
            val ok = RootGate.ensure(true)
            if (ok) AppPreferences.isRooted = true
            if (ok && !was) NetSniffer.enableSync(packageName, false) else if (!ok) RootGate.watch()
            ui.post { next() }
        }.apply { isDaemon = true }.start()
    }

    private fun startFloat() {
        try {
            if (Settings.canDrawOverlays(this) && !FloatingService.running)
                ContextCompat.startForegroundService(this, Intent(this, FloatingService::class.java))
        } catch (e: Exception) { }
    }

    private fun later(ms: Long) { val g = ++gen; ui.postDelayed({ if (g == gen) next() }, ms) }

    /** Jalankan langkah berikutnya yang masih kurang. Hanya satu permintaan pada satu waktu. */
    private fun next() {
        waiting = false; leftApp = false
        startFloat()
        while (true) {
            val s = step++
            when (s) {
                0 -> {  // penyimpanan
                    val miss = listOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
                    if (miss.isNotEmpty()) { waiting = true; ActivityCompat.requestPermissions(this, miss.toTypedArray(), 1); return }
                }
                1 -> {  // notifikasi
                    if (Build.VERSION.SDK_INT >= 33 &&
                        ContextCompat.checkSelfPermission(this, "android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                        waiting = true; ActivityCompat.requestPermissions(this, arrayOf("android.permission.POST_NOTIFICATIONS"), 2); return
                    }
                }
                2 -> {  // tampil di atas aplikasi lain
                    if (!Settings.canDrawOverlays(this)) {
                        waiting = true
                        Toast.makeText(this, "Izinkan 'Tampil di atas aplikasi lain' untuk AlfyDownloader+", Toast.LENGTH_LONG).show()
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
                    }
                }
                3 -> {  // aksesibilitas: tanya SEKALI saja
                    if (!AppPreferences.hasAskedAccessibility) {
                        AppPreferences.hasAskedAccessibility = true
                        if (!accEnabled(this)) {
                            waiting = true
                            android.app.AlertDialog.Builder(this)
                                .setTitle("Izin Aksesibilitas")
                                .setMessage("Aktifkan 'AlfyDownloader+' di Aksesibilitas agar scan URL browser berjalan.")
                                .setPositiveButton("BUKA PENGATURAN") { _, _ -> try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (e: Exception) { waiting = false; later(200) } }
                                .setNegativeButton("NANTI") { _, _ -> waiting = false; later(200) }
                                .setOnCancelListener { waiting = false; later(200) }
                                .show()
                            return
                        }
                    }
                }
                4 -> {  // baterai
                    val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
                    if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                        waiting = true
                        try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) } catch (e: Exception) { waiting = false }
                        if (waiting) return
                    }
                }
                5 -> { NetSniffer.enable(packageName); return }  // terakhir: akses root (jika ada)
                else -> { tick.value++; return }
            }
        }
    }

    override fun onPause() { super.onPause(); if (waiting) leftApp = true }

    override fun onResume() {
        super.onResume()
        tick.value++
        startFloat()
        if (!RootGate.granted) RootGate.watch()   // v1.9: baru diizinkan di Magisk -> aktif otomatis
        // kembali dari layar pengaturan -> lanjut ke izin berikutnya (setelah jeda singkat)
        if (waiting && leftApp) later(500)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
            Regex("https?://[^\\s]+").findAll(t).forEach { Resolver.submit(it.value, null, true, "Manual (clipboard saat buka aplikasi)") }
        } catch (e: Exception) { }
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r); tick.value++
        waiting = false; later(400)
    }
}

@Composable
fun App(tick: Int) {
    var screen by remember { mutableStateOf("home") }
    Home(tick) { screen = it }
}

private fun playInternal(ctx: Context, d: DlItem) {
    try {
        ctx.startActivity(Intent(ctx, PreviewActivity::class.java)
            .putExtra("url", Uri.fromFile(File(d.path)).toString())
            .putExtra("mode", if (d.isAudio) "audio" else "video")
            .putExtra("title", d.name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) { Toast.makeText(ctx, "Gagal memutar", Toast.LENGTH_SHORT).show() }
}

private fun openFile(ctx: Context, d: DlItem) {
    try {
        val mime = if (d.isAudio) "audio/*" else "video/*"
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.fromFile(File(d.path)), mime)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) { Toast.makeText(ctx, "Tidak ada pemutar", Toast.LENGTH_SHORT).show() }
}

private fun deleteItems(ctx: Context, items: List<DlItem>, withFile: Boolean) {
    for (d in items) {
        if (d.status != Status.DONE) DownloadService.cmd(ctx, "cancel", d.id)
        if (withFile) try { if (d.path.isNotEmpty()) File(d.path).delete(); File(d.dir, d.name + ".part").delete() } catch (e: Exception) { }
        Repo.remove(d.id)
    }
    Toast.makeText(ctx, "${items.size} item dihapus", Toast.LENGTH_SHORT).show()
}

private fun openUrl(ctx: Context, d: DlItem) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(d.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: Exception) { Toast.makeText(ctx, "Tidak ada peramban", Toast.LENGTH_SHORT).show() }
}

/** Paksa ambil link baru (semua jenis link): m3u8 -> force refresh token; mp4/ts/lainnya -> lupakan cache & pindai ulang halaman asal. */
private fun resumeFresh(ctx: Context, d: DlItem) {
    val page = d.page.takeIf { it.startsWith("http") } ?: d.referer?.takeIf { it.startsWith("http") }
    Toast.makeText(ctx, "Mengambil link baru…", Toast.LENGTH_SHORT).show()
    val h = android.os.Handler(android.os.Looper.getMainLooper())
    Thread {
        var msg = "Link baru tidak ditemukan, memakai link lama"
        try {
            val isM3u8 = d.kind == Kind.HLS || d.url.substringBefore('?').endsWith(".m3u8", true)
            if (isM3u8) {
                val f = Resolver.forceFreshHls(d.url, page)
                if (!f.url.isNullOrBlank()) { Repo.update(d.id) { it.copy(url = f.url!!, error = "") }; Repo.save(); msg = "Link baru didapat" }
            } else if (page != null) {
                Resolver.forget(d.url, page, d.referer)
                h.post { Resolver.submit(page, null, true, "Manual (link baru)") }
                msg = "Halaman dipindai ulang; pilih link baru dari hasil pindai"
            }
        } catch (e: Throwable) { msg = "Gagal ambil link baru: " + (e.message ?: e.javaClass.simpleName) }
        h.post {
            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
            val cur = Repo.get(d.id)
            if (cur != null && (cur.url != d.url || page == null || cur.kind == Kind.HLS || cur.url.substringBefore('?').endsWith(".m3u8", true)))
                DownloadService.cmd(ctx, "start", d.id)
        }
    }.start()
}

private fun accEnabled(ctx: Context): Boolean {
    // 1) Service sedang terhubung = pasti aktif (tidak bergantung pada string Settings)
    if (AlfyAccessibilityService.inst != null) return true
    // 2) Bandingkan komponen (package + class), bukan string mentah
    try {
        val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        val me = android.content.ComponentName(ctx.packageName, AlfyAccessibilityService::class.java.name)
        for (part in s.split(':')) {
            if (part.isBlank()) continue
            val cn = android.content.ComponentName.unflattenFromString(part.trim()) ?: continue
            if (cn.packageName == me.packageName && cn.className == me.className) return true
        }
    } catch (e: Throwable) { }
    // 3) Daftar resmi dari AccessibilityManager
    try {
        val am = ctx.getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
        val list = am.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        if (list.any { it.resolveInfo?.serviceInfo?.let { si -> si.packageName == ctx.packageName && si.name == AlfyAccessibilityService::class.java.name } == true }) return true
    } catch (e: Throwable) { }
    return false
}

@Composable
fun Home(tick: Int, go: (String) -> Unit) {
    val ctx = LocalContext.current
    val all by Repo.downloads.collectAsState()
    val detected by Repo.detected.collectAsState()
    val pagerState = rememberPagerState(pageCount = { 3 })
    val tabScope = rememberCoroutineScope()
    val tab = pagerState.currentPage
    var showPerm by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var showGuide by remember { mutableStateOf(false) }
    var showIcons by remember { mutableStateOf(false) }
    var showDev by remember { mutableStateOf(false) }
    var delMenu by remember { mutableStateOf(false) }
    var batch by remember { mutableStateOf<List<DlItem>?>(null) }
    if (showIcons) IconSettingsDialog { showIcons = false }
    var missing by remember { mutableStateOf(!Settings.canDrawOverlays(ctx) || !accEnabled(ctx)) }
    LaunchedEffect(tick) {
        while (true) {
            missing = !Settings.canDrawOverlays(ctx) || !accEnabled(ctx)
            kotlinx.coroutines.delay(700)
        }
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().background(LocalUiStyle.current.bar).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("AlfyDownloader+", fontSize = 20.sp, color = LocalUiStyle.current.onBar, modifier = Modifier.weight(1f))
                Box {
                    TextButton(onClick = { delMenu = true }) { Text("🗑", fontSize = 20.sp) }
                    DropdownMenu(expanded = delMenu, onDismissRequest = { delMenu = false }) {
                        DropdownMenuItem(text = { Text("[Hapus Semua Daftar]") }, onClick = { delMenu = false; if (all.isNotEmpty()) batch = all })
                        DropdownMenuItem(text = { Text("[Hapus yang Selesai Saja]") }, onClick = { delMenu = false; all.filter { it.status == Status.DONE }.let { if (it.isNotEmpty()) batch = it } })
                    }
                }
                TextButton(onClick = { showIcons = true }) { Text("🎨", fontSize = 20.sp) }
                TextButton(onClick = { ctx.startActivity(Intent(ctx, BrowserActivity::class.java)) }) { Text(Icons.get("main_web"), fontSize = 20.sp) }
                TextButton(onClick = { showGuide = true }) { Text(Icons.get("main_guide"), fontSize = 20.sp) }
                TextButton(onClick = { showPerm = true }) { Text(if (missing) Icons.get("main_warn") else Icons.get("main_set"), fontSize = 20.sp) }
            }
            TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
                val names = listOf("SEMUA (${all.size})", "MENGUNDUH (${all.count { it.status != Status.DONE }})",
                    "SELESAI (${all.count { it.status == Status.DONE }})")
                names.forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tabScope.launch { pagerState.animateScrollToPage(i) } }, text = { Text(t, fontSize = 11.sp, maxLines = 1) })
                }
            }
            HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
                val list = when (page) {
                    0 -> all
                    1 -> all.filter { it.status != Status.DONE }
                    else -> all.filter { it.status == Status.DONE }
                }
                LazyColumn(Modifier.fillMaxSize()) {
                    items(list, key = { it.id }) { d -> if (page == 0) SwipeDlRow(d) else DlRow(d); Spacer(Modifier.height(1.dp)) }
                }
            }
        }
        FloatingActionButton(onClick = { showAdd = true }, containerColor = Color(0xFF80CBC4),
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)) { Text("+", fontSize = 28.sp, color = Color.White) }
    }

    batch?.let { items ->
        AlertDialog(
            onDismissRequest = { batch = null },
            title = { Text("Hapus ${items.size} item") },
            text = { Text("Pilih cara menghapus.") },
            confirmButton = { TextButton(onClick = { batch = null; deleteItems(ctx, items, true) }) { Text("[Hapus File + Daftar]") } },
            dismissButton = {
                Row {
                    TextButton(onClick = { batch = null }) { Text("BATAL") }
                    TextButton(onClick = { batch = null; deleteItems(ctx, items, false) }) { Text("[Hapus Daftar Saja]") }
                }
            }
        )
    }
    if (showAdd) {
        var url by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Tambah tautan") },
            text = { OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("https://…") }) },
            confirmButton = {
                TextButton(onClick = {
                    Resolver.submit(url, null, true, "Manual (tambah tautan)"); showAdd = false
                    Toast.makeText(ctx, "Memindai tautan…", Toast.LENGTH_SHORT).show()
                }) { Text("PINDAI") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("BATAL") } }
        )
    }
    if (showGuide) {
        var st by remember { mutableStateOf(NetSniffer.status) }
        DisposableEffect(Unit) { VpnTool.startWatch(); onDispose { VpnTool.stopWatch() } }
        LaunchedEffect(Unit) { while (true) { st = NetSniffer.status + "\n" + VpnTool.status + "\n" + Resolver.diag + "\n" + ToolLog.text(); kotlinx.coroutines.delay(500) } }
        AlertDialog(
            onDismissRequest = { showGuide = false },
            title = { Text("Pemantau alamat jaringan") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Button(modifier = Modifier.fillMaxWidth(), onClick = {
                        NetSniffer.enable(ctx.packageName)
                        if (Settings.canDrawOverlays(ctx) && !FloatingService.running)
                            ContextCompat.startForegroundService(ctx, Intent(ctx, FloatingService::class.java))
                    }) { Text("AKTIFKAN PEMANTAU ALAMAT") }
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
                        try { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (e: Exception) { }
                    }) { Text("IZIN AKSES NOTIFIKASI (deteksi tanpa root)") }
                    Spacer(Modifier.height(6.dp))
                    var noVpn by remember { mutableStateOf(VpnTool.enabled()) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = noVpn, onCheckedChange = { noVpn = it; VpnTool.set(it) })
                        Text("Lepaskan Alfy dari VPN (pakai IP jaringan asli untuk memindai & mengunduh)", fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
                        ctx.startActivity(Intent(ctx, BlockHubActivity::class.java))
                    }) { Text("BLOKIR & FILTER (link, iklan, elemen, situs)") }
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
                        ctx.startActivity(Intent(ctx, BrowserActivity::class.java).putExtra("url", "https://accounts.google.com/ServiceLogin?service=youtube&continue=https://m.youtube.com/"))
                    }) { Text("LOGIN YOUTUBE (untuk cookies, pakai akun cadangan)") }
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { NetSniffer.installTcpdump() }) { Text("PASANG TCPDUMP OTOMATIS") }
                    Spacer(Modifier.height(6.dp))
                    var sniff by remember { mutableStateOf(Repo.prefs().getBoolean("sniffAll", false)) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = sniff, onCheckedChange = {
                            sniff = it; Repo.prefs().edit().putBoolean("sniffAll", it).apply(); NetSniffer.stop(); NetSniffer.start()
                        })
                        Text("Pantau SEMUA lalu lintas (logcat/tcpdump). Bisa memunculkan banyak link yang tidak kamu buka.", fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    var thumb by remember { mutableStateOf(Repo.prefs().getBoolean("autoThumb", true)) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = thumb, onCheckedChange = { thumb = it; Repo.prefs().edit().putBoolean("autoThumb", it).apply() })
                        Text("Scan otomatis thumbnail YouTube saat daftar/hasil pencarian dilihat (maks. 8 per 10 menit)", fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Status: $st" + (if (Engine.ready) "" else "\nMesin unduh: " + (Engine.error ?: "memuat…")), fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "PENJELASAN\n\n" +
                        "• AKTIFKAN PEMANTAU: meminta akses root (izinkan di Magisk/KernelSU), lalu otomatis memberi izin overlay, aksesibilitas, dan baca log, kemudian memantau alamat yang diakses semua aplikasi. Tekan lagi bila status menunjukkan masalah.\n\n" +
                        "ALAT PEMINDAI YOUTUBE (jalan bersamaan di latar belakang; hasilnya di panel menu mengambang)\n" +
                        "1. ytFast: bertanya ke API pemutar YouTube seolah-olah aplikasi iOS / headset VR.\n" +
                        "2. NewPipe: library aplikasi NewPipe, meniru pemutar web YouTube.\n" +
                        "3. yt-dlp: mencoba 6 klien YouTube (IPv4 dipaksa).\n" +
                        "4. yt-dlp+cookies: sama dengan yt-dlp tetapi membawa cookies login. INI YANG PALING MUNGKIN BERHASIL di IP VPN, karena YouTube tidak menanyakan 'bukan bot' pada akun yang sudah login.\n" +
                        "5. Piped/Invidious: daftar server publik diambil otomatis, banyak server dicoba sekaligus. Link diproksikan lewat server itu, jadi tidak terikat IP VPN-mu.\n" +
                        "6. HLS iOS/VR: daftar putar iOS lalu klien VR (mulai setelah 3 detik bila belum ada hasil).\n" +
                        "7. WebView: membuka pemutar YouTube asli secara tersembunyi lalu menangkap link googlevideo (mulai setelah 5 detik; memakai login yang sama).\n" +
                        "Baris log: ✓ berhasil, ✗ alasan gagal, ⏳ berjalan. Setiap link diberi label [alat] yang membuatnya. Bila semua gagal, tunggu 60 detik lalu otomatis dicoba sekali lagi.\n\n" +
                        "BILA SEMUA ALAT ✗ 'bot check' / LOGIN_REQUIRED (IP VPN ditandai YouTube)\n" +
                        "• Tekan LOGIN YOUTUBE, masuk dengan AKUN CADANGAN (bukan akun utama), selesaikan sampai halaman YouTube terbuka, lalu tutup. Cookies dipakai otomatis oleh alat 4 dan 7. Tetap nyalakan VPN seperti biasa; login cukup sekali, ulangi bila cookies kedaluwarsa.\n" +
                        "• Root: cookies Firefox dan browser Chromium (Chrome, Brave, Kiwi, Edge) yang sudah login YouTube juga dibaca otomatis bila tidak terenkripsi. Bila status menulis 'terenkripsi', pakai LOGIN YOUTUBE.\n" +
                        "• Jangan ganti server/kota VPN di tengah proses: link googlevideo terikat ke IP yang meminta (kecuali dari alat 5).\n" +
                        "• 'Lepaskan Alfy dari VPN' hanya untuk yang punya kuota di luar VPN; abaikan bila tidak.\n\n" +
                        "PENDETEKSI VIDEO (tahap 1)\n" +
                        "• Akses Notifikasi: tekan IZIN AKSES NOTIFIKASI lalu aktifkan AlfyDownloader+. Judul + channel video YouTube/ReVanced yang sedang diputar dibaca lewat MediaSession, tanpa root.\n" +
                        "• Aksesibilitas, media_session (root), logcat, clipboard, dan menu Share tetap berjalan.\n\n" +
                        "• PASANG TCPDUMP OTOMATIS: memasang tcpdump lewat Termux supaya alamat HTTP polos (http://…) terbaca langsung dari jaringan. Butuh Termux terpasang dan internet. Alternatif: modul Magisk 'tcpdump'.\n\n" +
                        "• Otomatis hanya untuk yang sedang kamu akses: alamat di kolom URL browser dan video YouTube yang sedang diputar (media session, root). Untuk Shorts/layar lain, tekan tombol 🔍 di menu mengambang: layar yang sedang terbuka dipindai saat itu juga (aksesibilitas HARUS aktif). 📋 memindai clipboard. Hasil bisa meleset bila ada video berjudul sama.\n\n" +
                        "• Alamat yang terbaca: URL dari log aplikasi (logcat), teks di layar (aksesibilitas), isi halaman web, dan paket HTTP polos. Hasilnya muncul sebagai angka merah di tombol mengambang.\n\n" +
                        "• Batasan: alamat HTTPS lengkap terenkripsi di jaringan sehingga tidak terlihat oleh tcpdump. Mencegat HTTPS penuh (sertifikat sendiri) belum ada di versi ini.\n\n" +
                        "• Agar tidak dimatikan sistem: Pengaturan > Aplikasi > AlfyDownloader+ > Baterai > Tanpa batasan.",
                        fontSize = 13.sp
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showGuide = false }) { Text("TUTUP") } }
        )
    }
    if (showDev) {
        var tick2 by remember { mutableStateOf(0) }
        var upd by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showDev = false },
            title = { Text("Developer / Advanced") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Button(enabled = !busy, onClick = {
                        busy = true; upd = "Memulai…"
                        val h = android.os.Handler(android.os.Looper.getMainLooper())
                        Thread {
                            val r = BinUpdater.updateYtDlp { m -> h.post { upd = m } }
                            h.post { upd = r; busy = false; Toast.makeText(ctx, r, Toast.LENGTH_LONG).show() }
                        }.start()
                    }) { Text("Update Binary yt-dlp") }
                    if (upd.isNotEmpty()) Text(upd, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Endpoint API (kosongkan = bawaan)", fontSize = 13.sp)
                    for (f in AppPreferences.endpointFields) {
                        var v by remember(tick2, f.key) { mutableStateOf(f.get()) }
                        OutlinedTextField(
                            value = v, onValueChange = { v = it; f.set(it) },
                            label = { Text(f.label, fontSize = 11.sp) },
                            singleLine = !f.multi, minLines = if (f.multi) 3 else 1,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                        )
                    }
                    TextButton(onClick = { AppPreferences.resetEndpoints(); tick2++ }) { Text("Reset semua endpoint ke bawaan") }
                }
            },
            confirmButton = { TextButton(onClick = { showDev = false }) { Text("TUTUP") } }
        )
    }
    if (showPerm) {
        val ov = Settings.canDrawOverlays(ctx)
        val ac = accEnabled(ctx)
        val st = ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        AlertDialog(
            onDismissRequest = { showPerm = false },
            title = { Text("Izin aplikasi") },
            text = {
                Column {
                    TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))) }) {
                        Text((if (ov) "✅ " else "❗ ") + "Tampil di atas aplikasi lain (menu mengambang)") }
                    TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) {
                        Text((if (ac) "✅ " else "❗ ") + "Aksesibilitas: AlfyDownloader+ (scan URL browser)") }
                    TextButton(onClick = {
                        ActivityCompat.requestPermissions(ctx as Activity, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
                    }) { Text((if (st) "✅ " else "❗ ") + "Penyimpanan") }
                    val bat = (ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
                    TextButton(onClick = {
                        try { ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))) } catch (e: Exception) { }
                    }) { Text((if (bat) "✅ " else "❗ ") + "Tanpa batasan baterai (agar tidak dimatikan sistem)") }
                    TextButton(onClick = { showPerm = false; showDev = true }) { Text("🛠 Developer / Advanced (Endpoint & Update yt-dlp)") }
                    TextButton(onClick = { NetSniffer.enable(ctx.packageName) }) {
                        Text((if (NetSniffer.status.contains("Root: aktif")) "✅ " else "❗ ") + "Akses root (ketuk untuk meminta ulang)") }
                    var hold by remember { mutableStateOf(Repo.prefs().getInt("holdMs", 2000).toFloat()) }
                    Text("Durasi tahan lalu geser panel melayang: " + "%.1f".format(hold / 1000f) + " detik", fontSize = 13.sp)
                    androidx.compose.material3.Slider(
                        value = hold,
                        onValueChange = { hold = (Math.round(it / 100f) * 100).toFloat() },
                        onValueChangeFinished = { Repo.prefs().edit().putInt("holdMs", hold.toInt()).apply() },
                        valueRange = 500f..4000f
                    )
                    Text("Warna tombol mengambang", fontSize = 13.sp)
                    for ((label, key, def) in listOf(Triple("Tombol", "bubbleIdx", 0), Triple("Panah", "arrowIdx", 8))) {
                        var sel by remember { mutableStateOf(Repo.prefs().getInt(key, def)) }
                        Text(label, fontSize = 12.sp)
                        for (row in 0..1) Row {
                            for (i in row * 5 until row * 5 + 5) {
                                val shape = androidx.compose.foundation.shape.CircleShape
                                Box(Modifier.padding(3.dp).size(30.dp)
                                    .background(if (i == 0) Color.Transparent else Color(Palette.colors[i]), shape)
                                    .then(if (i == 0) Modifier.background(androidx.compose.ui.graphics.Brush.sweepGradient(Palette.rainbow.map { Color(it) }), shape) else Modifier)
                                    .border(if (sel == i) 3.dp else 1.dp, if (sel == i) Color(0xFF00BFA5) else Color.Gray, shape)
                                    .clickable { sel = i; Repo.prefs().edit().putInt(key, i).apply() })
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPerm = false }) { Text("TUTUP") } }
        )
    }
}

private val TrashIcon: androidx.compose.ui.graphics.vector.ImageVector by lazy {
    androidx.compose.ui.graphics.vector.ImageVector.Builder(
        defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f
    ).addPath(
        pathData = androidx.compose.ui.graphics.vector.addPathNodes(
            "M6 19c0 1.1 .9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"),
        fill = androidx.compose.ui.graphics.SolidColor(Color.Black)
    ).build()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwipeDlRow(d: DlItem) {
    val ctx = LocalContext.current
    val state = rememberSwipeToDismissBoxState(positionalThreshold = { it * 0.1f }, confirmValueChange = { v ->
        if (v == SwipeToDismissBoxValue.EndToStart || v == SwipeToDismissBoxValue.StartToEnd) {
            if (d.status != Status.DONE) DownloadService.cmd(ctx, "cancel", d.id); Repo.remove(d.id); true   // hanya hapus dari daftar, file fisik aman
        } else false
    })
    val vc = androidx.compose.ui.platform.LocalViewConfiguration.current
    val sens = remember(vc) { object : androidx.compose.ui.platform.ViewConfiguration by vc { override val touchSlop: Float get() = vc.touchSlop * 0.3f } }
    androidx.compose.runtime.CompositionLocalProvider(androidx.compose.ui.platform.LocalViewConfiguration provides sens) {
        SwipeToDismissBox(
            state = state,
            enableDismissFromStartToEnd = true,
            enableDismissFromEndToStart = true,
            backgroundContent = {
                Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal = 24.dp),
                    contentAlignment = if (state.dismissDirection == SwipeToDismissBoxValue.StartToEnd) Alignment.CenterStart else Alignment.CenterEnd) {
                    Icon(TrashIcon, contentDescription = "Hapus", tint = Color.Red, modifier = Modifier.size(32.dp))
                }
            }
        ) { DlRow(d) }
    }
}

@Composable
fun DlRow(d: DlItem) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var menu by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf(false) }
    val stText = when (d.status) {
        Status.QUEUED -> "Antre"; Status.DOWNLOADING -> "Mengunduh"; Status.PAUSED -> "Dijeda"
        Status.DONE -> "Selesai"; Status.ERROR -> "Gagal"
    }
    Row(Modifier.fillMaxWidth().background(Color(0xFF689F98)).clickable { detail = true }.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(if (d.isAudio) "🎵" else "🎞️", fontSize = 26.sp)
        Box {
            Text("⋮", fontSize = 26.sp, color = Color.White, modifier = Modifier.clickable { menu = true }.padding(8.dp))
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                if (d.status == Status.DONE) {
                    DropdownMenuItem(text = { Text("Putar") }, onClick = { menu = false; playInternal(ctx, d) })
                    DropdownMenuItem(text = { Text("Buka dengan aplikasi lain") }, onClick = { menu = false; openFile(ctx, d) })
                } else if (d.status == Status.DOWNLOADING || d.status == Status.QUEUED) {
                    DropdownMenuItem(text = { Text("Jeda") }, onClick = { menu = false; DownloadService.cmd(ctx, "pause", d.id) })
                } else {
                    DropdownMenuItem(text = { Text("Lanjutkan / Ulangi") }, onClick = { menu = false; Toast.makeText(ctx, "Memulai unduhan...", Toast.LENGTH_SHORT).show(); DownloadService.cmd(ctx, "start", d.id) })
                }
                DropdownMenuItem(text = { Text("Lanjutkan dengan Link Baru") }, onClick = { menu = false; resumeFresh(ctx, d) })
                DropdownMenuItem(text = { Text("Buka URL di Peramban") }, onClick = { menu = false; openUrl(ctx, d) })
                DropdownMenuItem(text = { Text("Detail") }, onClick = { menu = false; detail = true })
                DropdownMenuItem(text = { Text("Hapus dari daftar") }, onClick = {
                    menu = false; DownloadService.cmd(ctx, "cancel", d.id); Repo.remove(d.id)
                })
                DropdownMenuItem(text = { Text("Hapus + file") }, onClick = {
                    menu = false; DownloadService.cmd(ctx, "cancel", d.id)
                    try { if (d.path.isNotEmpty()) File(d.path).delete(); File(d.dir, d.name + ".part").delete() } catch (e: Exception) { }
                    Repo.remove(d.id)
                })
            }
        }
        Spacer(Modifier.width(4.dp))
        Column(Modifier.weight(1f)) {
            Text(modifier = Modifier.clickable {
                when (d.status) {
                    Status.DONE -> playInternal(ctx, d)
                    Status.DOWNLOADING, Status.QUEUED -> { }
                    else -> { Toast.makeText(ctx, "Memulai unduhan...", Toast.LENGTH_SHORT).show(); DownloadService.cmd(ctx, "start", d.id) }
                }
            }, text = buildAnnotatedString {
                append(d.name + " (Lanjutkan: ")
                withStyle(SpanStyle(color = if (d.resumable) Color(0xFF006400) else Color.Red, fontWeight = FontWeight.Bold)) {
                    append(if (d.resumable) "Ya" else "Tidak")
                }
                append(")")
            }, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Row {
                Text("${d.progress}% | ${if (d.status == Status.DONE) fmtSize(d.total) else fmtSize(d.done) + "/" + fmtSize(d.total)}",
                    color = Color(0xFFE0F2F1), fontSize = 12.sp, modifier = Modifier.weight(1f))
                Text(stText + if (d.status == Status.DOWNLOADING && d.speed > 0) " ${fmtSize(d.speed)}/s" else "",
                    color = Color(0xFFE0F2F1), fontSize = 12.sp)
            }
            if (d.status == Status.DOWNLOADING || d.status == Status.PAUSED || d.status == Status.QUEUED)
                LinearProgressIndicator(progress = { d.progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Color.White)
            if (d.status == Status.DOWNLOADING) {
                val rem = if (d.total > d.done) d.total - d.done else 0L
                val eta = if (d.speed > 0 && rem > 0) (rem / d.speed).let { if (it >= 3600) "${it / 3600}j ${(it % 3600) / 60}m" else if (it >= 60) "${it / 60}m ${it % 60}d" else "${it}d" } else "--"
                Text("⚡ " + (if (d.speed > 0) fmtSize(d.speed) + "/s" else "menghitung…") + "  •  sisa " + eta + (if (d.total > 0) "  •  " + fmtSize(d.done) + " / " + fmtSize(d.total) else ""),
                    color = Color(0xFFB2DFDB), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (d.status == Status.ERROR) {
                val hint = ScanReport.dlHint(d)
                if (ScanReport.isRaw(d.error)) {
                    Text("Gagal (ffmpeg):\n" + ScanReport.rawTail(d.error, 3), color = Color(0xFFFFEBEE), fontSize = 11.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, maxLines = 5, overflow = TextOverflow.Ellipsis)
                    if (hint != null) Text(hint.text(), color = Color(0xFFFFF59D), fontSize = 11.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
                } else if (hint != null) Text(hint.text(), color = Color(0xFFFFF59D), fontSize = 12.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
                else Text("Gagal: " + ScanReport.honest(d.error), color = Color(0xFFFFEBEE), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            else if (!d.resumable && d.status == Status.PAUSED)
                Text("Server tidak mendukung lanjut; diulang dari awal", color = Color(0xFFFFEBEE), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            else if (d.error.isNotBlank()) Text(d.error, color = Color(0xFFFFEBEE), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
    if (detail) AlertDialog(
        onDismissRequest = { detail = false },
        title = { Text("Detail") },
        text = {
            val rawErr = d.status == Status.ERROR && ScanReport.isRaw(d.error)
            Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState())) {
                Text("Nama: ${d.name}\nStatus: $stText\nUkuran: ${fmtSize(d.total)}\nDapat dilanjutkan: ${if (d.resumable) "Ya" else "Tidak"}\n" +
                    "Folder: ${d.dir}\n" + (if (d.source.isNotBlank()) "Sumber: ${d.source}\n" else "") + "URL: ${d.url}\n" + (if (rawErr) "Gagal (log ffmpeg mentah):" else if (d.error.isNotBlank()) (if (d.status == Status.ERROR) "Gagal: " + ScanReport.honest(d.error) else "Catatan: ${d.error}") else ""), fontSize = 13.sp)
                if (rawErr) androidx.compose.foundation.text.selection.SelectionContainer {
                    Text(ScanReport.rawText(d.error), fontSize = 11.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                }
                ScanReport.dlHint(d)?.let { Text("\n" + it.text(), fontSize = 13.sp) }
            }
        },
        dismissButton = if (d.error.isNotBlank()) ({
            TextButton(onClick = {
                try {
                    val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("log", "${d.name}\n${d.url}\n" + ScanReport.honest(d.error) + (ScanReport.dlHint(d)?.let { "\n" + it.text() } ?: "")))
                } catch (e: Throwable) { }
            }) { Text("SALIN LOG") }
        }) else null,
        confirmButton = { TextButton(onClick = { detail = false }) { Text("TUTUP") } }
    )
}

private fun saveBubble(ctx: android.content.Context, bytes: ByteArray): String? {
    return try {
        val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var ss = 1; while (o.outWidth / ss > 600 && o.outHeight / ss > 600) ss *= 2
        val bmp = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, android.graphics.BitmapFactory.Options().apply { inSampleSize = ss }) ?: return "Format gambar tidak dikenali"
        val side = minOf(bmp.width, bmp.height)
        val sq = android.graphics.Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        val out = android.graphics.Bitmap.createScaledBitmap(sq, 256, 256, true)
        val f = File(ctx.filesDir, "bubble_" + System.currentTimeMillis() + ".png")
        f.outputStream().use { out.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
        Repo.prefs().getString("ic_bubbleImg", null)?.let { File(it).delete() }
        Repo.prefs().edit().putString("ic_bubbleImg", f.path).apply()
        null
    } catch (e: Throwable) { "Gagal: " + (e.message ?: e.javaClass.simpleName) }
}

@Composable
fun IconSettingsDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    var editKey by remember { mutableStateOf<String?>(null) }
    var showPath by remember { mutableStateOf(false) }
    fun report(err: String?) {
        Toast.makeText(ctx, err ?: "Gambar tombol mengambang diganti", Toast.LENGTH_LONG).show(); tick++
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) report(try { saveBubble(ctx, ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }) } catch (e: Throwable) { "Gagal membuka gambar: " + e.message })
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Ganti ikon") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                key(tick) {
                    Text("Tombol mengambang", fontSize = 14.sp)
                    Row {
                        OutlinedButton(onClick = { pick.launch("image/*") }) { Text("PILIH GAMBAR", fontSize = 11.sp) }
                        Spacer(Modifier.width(6.dp))
                        OutlinedButton(onClick = {
                            Repo.prefs().getString("ic_bubbleImg", null)?.let { File(it).delete() }
                            Repo.prefs().edit().remove("ic_bubbleImg").apply(); tick++
                        }) { Text("HAPUS GAMBAR", fontSize = 11.sp) }
                    }
                    OutlinedButton(onClick = { showPath = true }) { Text("PAKAI PATH FILE (ROOT, PAKSA)", fontSize = 11.sp) }
                    var ringOn by remember { mutableStateOf(Repo.prefs().getBoolean("ringOn", true)) }
                    var ringSpeed by remember { mutableStateOf(Repo.prefs().getFloat("ringSpeed", 0.5f)) }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Cincin warna-warni", fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Switch(checked = ringOn, onCheckedChange = { ringOn = it; Repo.prefs().edit().putBoolean("ringOn", it).apply() })
                    }
                    var scale by remember { mutableStateOf(Repo.prefs().getFloat("bubbleScale", 1f)) }
                    var fsize by remember { mutableStateOf(Repo.prefs().getFloat("flameSize", 1f)) }
                    var swirl by remember { mutableStateOf(Repo.prefs().getBoolean("flameSwirl", false)) }
                    var rb by remember { mutableStateOf(Repo.prefs().getBoolean("flameRainbow", false)) }
                    var fcol by remember { mutableStateOf(Repo.prefs().getInt("flameColor", 0xFF1E88FF.toInt())) }
                    var hex by remember { mutableStateOf("") }
                    Text("Besar api (kiri mentok = mati, kanan = membakar banget)", fontSize = 13.sp)
                    Slider(value = fsize, valueRange = 0f..3f, onValueChange = { fsize = it; Repo.prefs().edit().putFloat("flameSize", if (it < 0.05f) 0f else it).apply() })
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Api ikut berputar mengitari sisi", fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Switch(checked = swirl, onCheckedChange = { swirl = it; Repo.prefs().edit().putBoolean("flameSwirl", it).apply() })
                    }
                    Text("Warna api", fontSize = 13.sp)
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        listOf(0xFF1E88FF, 0xFF00E5FF, 0xFFFF5722, 0xFFFFC107, 0xFFF44336, 0xFF00E676, 0xFFD500F9, 0xFFFF4081, 0xFFFFFFFF).forEach { cc ->
                            val ci = cc.toInt()
                            Box(Modifier.padding(end = 8.dp).size(34.dp).background(Color(ci), CircleShape)
                                .border(if (!rb && fcol == ci) 3.dp else 1.dp, Color.White, CircleShape)
                                .clickable { fcol = ci; rb = false; Repo.prefs().edit().putInt("flameColor", ci).putBoolean("flameRainbow", false).apply() })
                        }
                        Box(Modifier.size(34.dp).background(Color(0xFF424242), CircleShape).border(if (rb) 3.dp else 1.dp, Color.White, CircleShape)
                            .clickable { rb = true; Repo.prefs().edit().putBoolean("flameRainbow", true).apply() }, contentAlignment = Alignment.Center) { Text("🌈", fontSize = 16.sp) }
                    }
                    OutlinedTextField(value = hex, singleLine = true, label = { Text("Warna lain: #RRGGBB", fontSize = 11.sp) }, onValueChange = {
                        hex = it
                        try {
                            val ci = android.graphics.Color.parseColor(if (it.startsWith("#")) it else "#$it")
                            fcol = ci; rb = false; Repo.prefs().edit().putInt("flameColor", ci).putBoolean("flameRainbow", false).apply()
                        } catch (e: Exception) { }
                    })
                    var sparkOn by remember { mutableStateOf(Repo.prefs().getBoolean("sparkOn", true)) }
                    var sparkAmt by remember { mutableStateOf(Repo.prefs().getFloat("sparkAmount", 1f)) }
                    var sparkFollow by remember { mutableStateOf(Repo.prefs().getBoolean("sparkFollow", true)) }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Percikan api", fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Switch(checked = sparkOn, onCheckedChange = { sparkOn = it; Repo.prefs().edit().putBoolean("sparkOn", it).apply() })
                    }
                    Text("Jumlah percikan (geser kiri = sedikit/mati, kanan = hujan api)", fontSize = 13.sp)
                    Slider(value = sparkAmt, valueRange = 0f..3f, enabled = sparkOn, onValueChange = { sparkAmt = it; Repo.prefs().edit().putFloat("sparkAmount", if (it < 0.05f) 0f else it).apply() })
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Warna percikan ikut warna api (mati = oranye asli)", fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Switch(checked = sparkFollow, enabled = sparkOn, onCheckedChange = { sparkFollow = it; Repo.prefs().edit().putBoolean("sparkFollow", it).apply() })
                    }
                    var showLogOn by remember { mutableStateOf(Repo.prefs().getBoolean("showPanelLog", true)) }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Tampilkan Log di Panel Melayang", fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Switch(checked = showLogOn, onCheckedChange = { showLogOn = it; Repo.prefs().edit().putBoolean("showPanelLog", it).apply() })
                    }
                    var pinchOn by remember { mutableStateOf(Repo.prefs().getBoolean("pinchOn", true)) }
                    var pressSec by remember { mutableStateOf(Repo.prefs().getFloat("longPressSec", 1.5f).coerceIn(1f, 5f)) }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Ubah ukuran tombol dengan 2 jari (renggangkan = besar, cubit = kecil)", fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Switch(checked = pinchOn, onCheckedChange = { pinchOn = it; Repo.prefs().edit().putBoolean("pinchOn", it).apply() })
                    }
                    Text("Lama tekan tombol untuk memunculkan popup: ${String.format("%.1f", pressSec)} detik (1–5 detik)", fontSize = 13.sp)
                    Slider(value = pressSec, valueRange = 1f..5f, steps = 7, onValueChange = { pressSec = it; Repo.prefs().edit().putFloat("longPressSec", it).apply() })
                    Text("Ukuran tombol mengambang (kecil ↔ besar)", fontSize = 13.sp)
                    Slider(value = scale, valueRange = 0.5f..3f, onValueChange = { scale = it; Repo.prefs().edit().putFloat("bubbleScale", it).apply() })
                    Text("Kecepatan putar & percikan (kiri mentok = diam, kanan = super cepat 20 putaran/detik)", fontSize = 13.sp)
                    Slider(value = ringSpeed, onValueChange = { ringSpeed = it; Repo.prefs().edit().putFloat("ringSpeed", if (it < 0.03f) 0f else it).apply() })
                    Spacer(Modifier.height(8.dp))
                    Text("Ketuk baris untuk mengganti ikon (emoji atau teks apa saja). Ikon browser berlaku setelah browser dibuka ulang.", fontSize = 11.sp)
                    Icons.defs.forEach { (k, label, _) ->
                        Row(Modifier.fillMaxWidth().clickable { editKey = k }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(Icons.get(k), fontSize = 22.sp, modifier = Modifier.width(48.dp))
                            Text(label, fontSize = 13.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("TUTUP") } },
        dismissButton = { TextButton(onClick = { Icons.resetAll(); Repo.prefs().edit().remove("bubbleScale").remove("flameOn").remove("flameSize").remove("flameSwirl").remove("flameRainbow").remove("flameColor").remove("ringSpeed").remove("sparkOn").remove("sparkAmount").remove("sparkFollow").remove("pinchOn").remove("longPressSec").apply(); tick++ }) { Text("RESET SEMUA") } }
    )
    if (showPath) {
        var path by remember { mutableStateOf("/sdcard/Download/") }
        AlertDialog(
            onDismissRequest = { showPath = false },
            title = { Text("Path gambar (root)") },
            text = { OutlinedTextField(value = path, onValueChange = { path = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = {
                showPath = false
                val tmp = File(ctx.cacheDir, "bubble_src")
                Thread {
                    val q = path.trim().replace("'", "")
                    RootShell.run("cat '$q' > '${tmp.path}'", "chmod 666 '${tmp.path}'")
                    val err = if (tmp.length() > 0) saveBubble(ctx, tmp.readBytes()) else "File tidak terbaca / root tidak diizinkan"
                    tmp.delete()
                    android.os.Handler(android.os.Looper.getMainLooper()).post { report(err) }
                }.start()
            }) { Text("PAKAI") } },
            dismissButton = { TextButton(onClick = { showPath = false }) { Text("BATAL") } }
        )
    }
    editKey?.let { k ->
        var v by remember(k) { mutableStateOf(Icons.get(k)) }
        AlertDialog(
            onDismissRequest = { editKey = null },
            title = { Text(Icons.defs.first { it.first == k }.second) },
            text = { OutlinedTextField(value = v, onValueChange = { v = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { Icons.set(k, v); editKey = null; tick++ }) { Text("SIMPAN") } },
            dismissButton = { TextButton(onClick = { Icons.reset(k); editKey = null; tick++ }) { Text("RESET") } }
        )
    }
}
