package com.alfy.downloader.extras

import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.dnsoverhttps.DnsOverHttps
import java.net.InetAddress
import java.util.concurrent.TimeUnit

/** Klien OkHttp untuk mengambil halaman/API saat memindai link. Belum dipanggil kode lama. */
object AlfyHttp {
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    /** Klien dengan DNS-over-HTTPS (Cloudflare). */
    val dohClient: OkHttpClient by lazy {
        val doh = DnsOverHttps.Builder()
            .client(client)
            .url("https://cloudflare-dns.com/dns-query".toHttpUrl())
            .bootstrapDnsHosts(InetAddress.getByName("1.1.1.1"), InetAddress.getByName("1.0.0.1"))
            .build()
        client.newBuilder().dns(doh).build()
    }

    /** GET sederhana; null bila gagal. Panggil dari thread latar. */
    fun get(url: String, headers: Map<String, String> = emptyMap(), c: OkHttpClient = client): String? {
        return try {
            val rb = Request.Builder().url(url)
            for ((k, v) in headers) rb.header(k, v)
            c.newCall(rb.build()).execute().use { r -> if (r.isSuccessful) r.body?.string() else null }
        } catch (e: Throwable) { null }
    }
}
