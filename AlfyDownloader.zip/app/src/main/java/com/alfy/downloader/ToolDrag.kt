package com.alfy.downloader

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.LinearLayout
import android.widget.ScrollView
import kotlin.math.abs

/** Drag & drop urutan tool: tekan lama 0,5 detik pada [v] lalu geser. Tiap anak [box] harus ber-tag nama tool (String). Urutan disimpan ke AppPreferences.toolOrder. */
object ToolDrag {
    @SuppressLint("ClickableViewAccessibility")
    fun attach(v: View, row: View, box: LinearLayout, onDone: () -> Unit) {
        val h = Handler(Looper.getMainLooper())
        val slop = ViewConfiguration.get(v.context).scaledTouchSlop
        var dragging = false; var cancelling = false
        var dx = 0f; var dy = 0f
        v.isClickable = true
        val start = Runnable {
            dragging = true
            var p = v.parent; while (p != null) { p.requestDisallowInterceptTouchEvent(true); p = p.parent }
            row.alpha = 0.55f
            try { v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS) } catch (e: Throwable) { }
            val c = MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), MotionEvent.ACTION_CANCEL, dx, dy, 0)
            cancelling = true; try { v.dispatchTouchEvent(c) } catch (e: Throwable) { }; cancelling = false; c.recycle()
        }
        fun scrollOf(): ScrollView? { var p = box.parent; while (p != null) { if (p is ScrollView) return p; p = p.parent }; return null }
        var settling = false
        fun move(rawY: Float) {
            val cur = box.indexOfChild(row)
            var target = cur
            val loc = IntArray(2)
            if (!settling && cur >= 0) {
                // tukar index hanya saat jari melewati titik tengah tetangga (anti loncat/bolak-balik)
                if (cur > 0) { val c = box.getChildAt(cur - 1); c.getLocationOnScreen(loc); if (rawY < loc[1] + c.height / 2f) target = cur - 1 }
                if (target == cur && cur < box.childCount - 1) { val c = box.getChildAt(cur + 1); c.getLocationOnScreen(loc); if (rawY > loc[1] + c.height / 2f) target = cur + 1 }
            }
            if (target != cur && target in 0 until box.childCount) {
                settling = true   // tunggu layout selesai sebelum swap berikutnya (posisi layar basi = loncat)
                box.removeView(row); box.addView(row, target)
                box.viewTreeObserver.addOnPreDrawListener(object : android.view.ViewTreeObserver.OnPreDrawListener {
                    override fun onPreDraw(): Boolean { settling = false; if (box.viewTreeObserver.isAlive) box.viewTreeObserver.removeOnPreDrawListener(this); return true }
                })
            }
            val sc = scrollOf()
            if (sc != null) {
                sc.getLocationOnScreen(loc)
                val edge = (60 * v.resources.displayMetrics.density).toInt()
                if (rawY < loc[1] + edge) sc.scrollBy(0, -25) else if (rawY > loc[1] + sc.height - edge) sc.scrollBy(0, 25)
            }
        }
        v.setOnTouchListener { _, e ->
            if (cancelling) return@setOnTouchListener false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dragging = false; dx = e.x; dy = e.y; h.postDelayed(start, 500); false }
                MotionEvent.ACTION_MOVE -> {
                    if (!dragging) { if (abs(e.x - dx) > slop || abs(e.y - dy) > slop) h.removeCallbacks(start); false }
                    else { move(e.rawY); true }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    h.removeCallbacks(start)
                    if (dragging) {
                        dragging = false; row.alpha = 1f
                        val order = (0 until box.childCount).mapNotNull { box.getChildAt(it).tag as? String }
                        if (order.isNotEmpty()) AppPreferences.toolOrder = order
                        h.post { onDone() }
                        true
                    } else false
                }
                else -> dragging
            }
        }
    }
}
