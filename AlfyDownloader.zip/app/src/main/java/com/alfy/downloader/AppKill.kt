package com.alfy.downloader

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import kotlin.system.exitProcess

/** v1.148: "Matikan" = proses aplikasi benar-benar mati; semua tools OFF = sisa proses/RAM dibebaskan. */
object AppKill {
    private fun stopScans() {
        try { Chain.cancelAll() } catch (e: Throwable) { }
        try { ScanLimit.cancelAll() } catch (e: Throwable) { }
    }

    /** Matikan proses lain milik aplikasi ini (UID sama) selain proses utama. Proses WebView terisolasi dimatikan sistem saat WebView di-destroy. */
    private fun killSiblings(ctx: Context) {
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            for (p in am.runningAppProcesses.orEmpty()) {
                if (p.pid != Process.myPid() && p.processName.startsWith(ctx.packageName)) { try { Process.killProcess(p.pid) } catch (e: Throwable) { } }
            }
        } catch (e: Throwable) { }
    }

    /** Semua tools dimatikan: batalkan scan, bebaskan memori, matikan proses sisa (unduhan aktif tidak disentuh). */
    fun trim() {
        stopScans()
        try { Resolver.scope.coroutineContext[kotlinx.coroutines.Job]?.children?.forEach { it.cancel() } } catch (e: Throwable) { }
        try { System.gc(); Runtime.getRuntime().gc() } catch (e: Throwable) { }
        try { killSiblings(Repo.app) } catch (e: Throwable) { }
    }

    /** Matikan total: jeda unduhan aktif (bisa dilanjutkan), hentikan semua layanan, lepas Aksesibilitas/Notifikasi, lalu bunuh semua proses. */
    fun shutdown(ctx0: Context) {
        val ctx = ctx0.applicationContext
        stopScans()
        try { NetSniffer.stop() } catch (e: Throwable) { }   // hentikan logcat/tcpdump root & cegah FloatingService dihidupkan ulang
        try {
            Repo.downloads.value.filter { it.status == Status.DOWNLOADING || it.status == Status.QUEUED }.forEach { d ->
                Repo.update(d.id) { it.copy(status = Status.PAUSED, speed = 0) }
            }
            Repo.save()
        } catch (e: Throwable) { }
        try { ctx.stopService(Intent(ctx, DownloadService::class.java)) } catch (e: Throwable) { }
        // Layanan terikat sistem akan dihidupkan ulang Android bila hanya di-kill: lepas dulu.
        try { AlfyAccessibilityService.inst?.disableSelf() } catch (e: Throwable) { }
        try { if (Build.VERSION.SDK_INT >= 24) AlfyNotifService.inst?.requestUnbind() } catch (e: Throwable) { }
        try { ctx.stopService(Intent(ctx, FloatingService::class.java)) } catch (e: Throwable) { }
        Thread {
            try { Thread.sleep(500) } catch (e: Throwable) { }
            try { (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).appTasks.forEach { it.finishAndRemoveTask() } } catch (e: Throwable) { }
            killSiblings(ctx)
            if (AppPreferences.isRooted) { try { val pr = ProcessBuilder("su", "-c", "pkill -f 'logcat -b all'; pkill tcpdump").start(); Thread.sleep(700); pr.destroy() } catch (e: Throwable) { } }
            try { Thread.sleep(150) } catch (e: Throwable) { }
            Process.killProcess(Process.myPid())
            exitProcess(0)
        }.start()
    }
}
