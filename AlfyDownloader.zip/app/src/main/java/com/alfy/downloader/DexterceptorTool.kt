package com.alfy.downloader

import java.util.concurrent.ConcurrentHashMap

/**
 * Tool "Dexterceptor": menerima URL media yang disadap modul LSPosed (HookEntry.hookDex) dari okhttp3.Response
 * aplikasi target (Threads, Likee, Melolo, dll) lewat logcat root, lalu memasukkannya ke daftar download.
 * Format baris: AlfyDex|url|referer|paket|content-type
 */
object DexterceptorTool {
    @Volatile var hits = 0
    @Volatile var last = ""
    @Volatile private var lastErr = ""
    private val seen = ConcurrentHashMap.newKeySet<String>()

    fun status(): String = when {
        hits > 0 -> "✓ Aktif • $hits link dari OkHttp • $last"
        !AppPreferences.isRooted -> "✗ butuh root (baca logcat)"
        lastErr.isNotEmpty() -> "✗ $lastErr"
        !HookStatus.dexActive() -> "✗ modul LSPosed belum aktif (aktifkan modul, centang app target, mulai ulang app)"
        else -> "✓ Siap • menunggu app target memutar media"
    }

    fun onLine(line: String) {
        try {
            if (!Tool.on("Dexterceptor")) return
            val p = line.split('|')
            val u = p.getOrNull(1)?.trim().orEmpty()
            if (!u.startsWith("http")) { lastErr = "baris hook tidak valid"; return }
            val pkg = p.getOrNull(3).orEmpty()
            if (pkg.isNotEmpty() && !Resolver.pkgActive(pkg)) return   // app latar belakang diabaikan
            if (Block.isBlocked(u) || !seen.add(u.substringBefore('?'))) return
            val ref = p.getOrNull(2)?.takeIf { it.startsWith("http") }
            hits++; lastErr = ""
            last = u.substringAfter("://").substringBefore('/').take(28)
            ToolLog.side("Dexterceptor", "✓ $hits link OkHttp")
            Resolver.submitMedia(u, ref, "Dexterceptor")
        } catch (e: Throwable) { lastErr = "error: " + (e.message ?: e.javaClass.simpleName).take(40) }
    }
}
