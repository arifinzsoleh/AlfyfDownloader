package com.alfy.downloader.hook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * v1.29: modul LSPosed "Hook pemutar". Aktifkan di LSPosed, pilih aplikasi (TikTok, Instagram, Facebook, X, dll.), lalu mulai ulang aplikasinya.
 * Memasang pengait pada pemutar/jaringan (MediaPlayer, ExoPlayer/Media3, OkHttp, TTVideoEngine, Uri.parse, URL) dan menulis link media
 * ke logcat dengan format "AlfyHook|url|ref|paket"; pemantau Logcat root di AlfyDownloader membacanya.
 */
public class HookEntry implements IXposedHookLoadPackage {
    private static final String SELF = "com.alfy.downloader";
    private static final Pattern GOOD = Pattern.compile(
        "(?i)\\.(?:mp4|m3u8|mpd|webm|m4a|mp3|flv|aac|mov)(?:[?#&]|$)|mime_type=(?:video|audio)|mime=(?:video|audio)|/video/tos/|bytevc|/aweme/v\\d+/play|videoplayback");
    private static final Pattern BAD = Pattern.compile("(?i)doubleclick|googlesyndication|googleads|imasdk|adservice|pubads|/vast|\\.(?:png|jpe?g|gif|webp|js|css|ts|m4s)(?:[?#]|$)");
    private static final Pattern VID = Pattern.compile("(?:[?&]v=|youtu\\.be/|/shorts/|/live/|videoId[\"=:\\s]{1,4}\"?)([\\w-]{11})(?![\\w-])");
    private static final Pattern FBV = Pattern.compile(
        "(?i)facebook\\.com/(?:watch/?\\?(?:[^#\\s\"]*&)?v=|reel/|[\\w.]+/videos/(?:[\\w.-]+/)?|video\\.php\\?(?:[^#\\s\"]*&)?v=)(\\d{6,20})|fb\\.watch/[\\w-]+|(?:video_id|videoId|story_fbid)[\\\"=:\\s]{1,4}\\\"?(\\d{8,20})");
    private static volatile String lastVid = "";
    private static volatile String lastFb = "";
    private static final Set<String> SENT = Collections.synchronizedSet(new HashSet<String>());

    /** v1.97: ingat halaman/ID video Facebook (stream fbcdn dari pemutar = video-only/mute; yt-dlp yang mengambil video+suara). */
    static void noteFb(String u) {
        try {
            if (u == null || u.length() > 2000) return;
            if (!u.contains("facebook") && !u.contains("fb.watch") && !u.contains("video_id") && !u.contains("videoId") && !u.contains("story_fbid")) return;
            java.util.regex.Matcher m = FBV.matcher(u);
            if (!m.find()) return;
            if (m.group(0).toLowerCase().contains("fb.watch/")) { lastFb = "https://" + m.group(0); return; }
            String id = m.group(1) != null ? m.group(1) : m.group(2);
            if (id == null) return;
            lastFb = m.group(0).toLowerCase().contains("/reel/") ? "https://www.facebook.com/reel/" + id : "https://www.facebook.com/watch/?v=" + id;
        } catch (Throwable ignored) { }
    }

    static void noteVid(String u) {
        noteFb(u);
        try {
            if (u == null || u.length() > 2000 || (!u.contains("youtu") && !u.contains("videoId"))) return;
            if (u.contains("googlevideo.com")) return;
            java.util.regex.Matcher m = VID.matcher(u);
            if (m.find()) lastVid = m.group(1);
        } catch (Throwable ignored) { }
    }

    static void report(String u, String pkg) {
        try {
            noteVid(u);
            if (u == null || u.length() < 12 || u.length() > 1800 || !u.startsWith("http")) return;
            if (!GOOD.matcher(u).find() || BAD.matcher(u).find()) return;
            int q = u.indexOf('?');
            String key = q > 0 ? u.substring(0, q) : u;
            String vid = "";
            if (u.contains("googlevideo.com") && u.contains("videoplayback")) {
                vid = lastVid;
                if (vid.length() == 11) key = "gv|" + vid;
            }
            String fb = "";
            if (u.contains("fbcdn.net") || u.contains("fbcdn.com") || u.contains("facebook.com")) {
                fb = lastFb;
                if (fb.length() > 0) key = "fb|" + fb;
            }
            if (SENT.size() > 800) SENT.clear();
            if (!SENT.add(key)) return;
            android.util.Log.i("AlfyHook", "AlfyHook|" + u + "||" + pkg + "|" + vid + "|" + fb);
        } catch (Throwable ignored) { }
    }

    static void scan(Object[] args, String pkg) {
        if (args == null) return;
        for (Object a : args) {
            if (a == null) continue;
            if (a instanceof String) { noteVid((String) a); report((String) a, pkg); }
            else if (a instanceof android.net.Uri || a instanceof java.net.URL || a.getClass().getName().endsWith("HttpUrl")) { noteVid(a.toString()); report(a.toString(), pkg); }
        }
    }


    // ===== Dexterceptor: sadap okhttp3.Response (di memori, sebelum diolah aplikasi) =====
    private static final Set<String> SENT_DEX = Collections.synchronizedSet(new HashSet<String>());
    private static final ThreadLocal<Boolean> IN_DEX = new ThreadLocal<Boolean>();
    private static final Pattern URLS = Pattern.compile("https?://[^\"'\\s<>\\\\]+");

    private static Object call(Object o, String name, Object... a) throws Exception {
        for (java.lang.reflect.Method m : o.getClass().getMethods()) {
            if (m.getName().equals(name) && m.getParameterTypes().length == a.length) { m.setAccessible(true); return m.invoke(o, a); }
        }
        throw new NoSuchMethodException(name);
    }

    static void reportDex(String u, String ref, String ct, String pkg, boolean force) {
        try {
            if (u == null || u.length() < 12 || u.length() > 1800 || !u.startsWith("http")) return;
            if (BAD.matcher(u).find() || (!force && !GOOD.matcher(u).find())) return;
            int q = u.indexOf('?');
            String key = q > 0 ? u.substring(0, q) : u;
            if (SENT_DEX.size() > 800) SENT_DEX.clear();
            if (!SENT_DEX.add(key)) return;
            android.util.Log.i("AlfyHook", "AlfyDex|" + u + "|" + (ref == null ? "" : ref) + "|" + pkg + "|" + (ct == null ? "" : ct));
        } catch (Throwable ignored) { }
    }

    static void dexResponse(Object resp, String pkg) {
        if (resp == null || IN_DEX.get() != null) return;
        IN_DEX.set(Boolean.TRUE);
        try {
            Object req = call(resp, "request");
            String url = String.valueOf(call(req, "url"));
            Object cto = call(resp, "header", "Content-Type");
            String ct = cto == null ? "" : String.valueOf(cto).toLowerCase();
            boolean media = ct.startsWith("video/") || ct.startsWith("audio/") || ct.contains("mpegurl") || ct.contains("dash+xml");
            if (media) { reportDex(url, null, ct, pkg, true); return; }
            reportDex(url, null, ct, pkg, false);
            if (ct.contains("json") || ct.contains("javascript") || ct.contains("text/plain")) {
                Object body = call(resp, "peekBody", Long.valueOf(262144L));
                String t = String.valueOf(call(body, "string")).replace("\\/", "/").replace("\\u0026", "&");
                java.util.regex.Matcher m = URLS.matcher(t);
                int n = 0;
                while (m.find() && n < 12) {
                    String x = m.group();
                    if (GOOD.matcher(x).find() && !BAD.matcher(x).find()) { reportDex(x, url, "json", pkg, false); n++; }
                }
            }
        } catch (Throwable ignored) { } finally { IN_DEX.remove(); }
    }

    private static void hookDex(ClassLoader cl, final String pkg) {
        XC_MethodHook after = new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) { dexResponse(param.getResult(), pkg); }
        };
        try { all(XposedHelpers.findClassIfExists("okhttp3.Response$Builder", cl), "build", after); } catch (Throwable ignored) { }
        try { all(XposedHelpers.findClassIfExists("okhttp3.internal.http.RealInterceptorChain", cl), "proceed", after); } catch (Throwable ignored) { }
    }

    private static XC_MethodHook cb(final String pkg) {
        return new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam param) { scan(param.args, pkg); }
        };
    }

    private static void all(Class<?> c, String m, XC_MethodHook h) {
        try { if (c != null) XposedBridge.hookAllMethods(c, m, h); } catch (Throwable ignored) { }
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) throws Throwable {
        if (lp == null) return;
        if (SELF.equals(lp.packageName)) {   // tandai modul aktif di proses AlfyDownloader (dibaca HookStatus)
            try {
                Class<?> hs = Class.forName("com.alfy.downloader.HookStatus", true, lp.classLoader);
                hs.getField("hooked").setBoolean(null, true);
            } catch (Throwable ignored) { }
            return;
        }
        if ("android".equals(lp.packageName)) return;
        final String pkg = lp.packageName;
        ClassLoader cl = lp.classLoader;
        XC_MethodHook h = cb(pkg);
        // hasil Uri.parse dibaca setelah dipanggil (argumen string), umum dipakai semua pemutar
        try { XposedBridge.hookAllMethods(android.net.Uri.class, "parse", h); } catch (Throwable ignored) { }
        try { XposedBridge.hookAllConstructors(java.net.URL.class, h); } catch (Throwable ignored) { }
        all(android.media.MediaPlayer.class, "setDataSource", h);
        // ExoPlayer lama & Media3
        for (String n : new String[]{"com.google.android.exoplayer2.MediaItem$Builder", "androidx.media3.common.MediaItem$Builder"}) {
            try { all(XposedHelpers.findClassIfExists(n, cl), "setUri", h); } catch (Throwable ignored) { }
        }
        for (String n : new String[]{"com.google.android.exoplayer2.MediaItem", "androidx.media3.common.MediaItem"}) {
            try { all(XposedHelpers.findClassIfExists(n, cl), "fromUri", h); } catch (Throwable ignored) { }
        }
        // OkHttp (bila tidak diacak oleh aplikasi)
        try { all(XposedHelpers.findClassIfExists("okhttp3.Request$Builder", cl), "url", h); } catch (Throwable ignored) { }
        hookDex(cl, pkg);   // Dexterceptor (OkHttp Response)
        // ByteDance (TikTok)
        try {
            Class<?> tt = XposedHelpers.findClassIfExists("com.ss.ttvideoengine.TTVideoEngine", cl);
            all(tt, "setDirectURL", h);
            all(tt, "setDirectUrlUseDataLoader", h);
            all(tt, "setLocalURL", h);
        } catch (Throwable ignored) { }
    }
}
