package com.alfy.downloader

import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import com.jeffmony.downloader.VideoDownloadManager
import com.jeffmony.downloader.VideoDownloadConfig
import com.jeffmony.downloader.model.VideoTaskItem
import com.jeffmony.downloader.listener.DownloadListener

class DownloadService : Service() {
    companion object {
        private val jobs = ConcurrentHashMap<String, Job>()
        /** Smart Queue: unduhan serentak (minimal 2, bawaan 3); sisanya antre FIFO berstatus QUEUED. */
        private const val MAX_PARALLEL = 3
        /** Auto-Retry: maksimal 3x lanjut otomatis sebelum menyerah. */
        private const val MAX_RETRY = 1
        private val sem = Semaphore(MAX_PARALLEL.coerceAtLeast(2))
        /** Chunk yang sudah selesai per unduhan (kunci "id|nama") agar retry fetch() melanjutkan, bukan mengulang dari 0. */
        private val chunkDone = ConcurrentHashMap<String, MutableSet<Long>>()
        private fun fmtEta(sec: Long): String = when {
            sec < 0 -> "--"
            sec < 60 -> "Tersisa $sec detik"
            sec < 3600 -> "Tersisa ${sec / 60} menit ${sec % 60} detik"
            else -> "Tersisa ${sec / 3600} jam ${(sec % 3600) / 60} menit"
        }
        fun cmd(c: Context, action: String, id: String) {
            val i = Intent(c, DownloadService::class.java).setAction(action).putExtra("id", id)
            ContextCompat.startForegroundService(c, i)
        }
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        scope.launch {
            while (true) {
                delay(1000)
                if (jobs.isEmpty()) continue
                val act = Repo.downloads.value.filter { it.status == Status.DOWNLOADING || it.status == Status.QUEUED }
                if (act.isEmpty()) continue
                postNotif(this@DownloadService, 2, progNotif(act))
            }
        }
    }

    private fun actPi(action: String, id: String, rc: Int): android.app.PendingIntent =
        android.app.PendingIntent.getService(this, rc, Intent(this, DownloadService::class.java).setAction(action).putExtra("id", id),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)

    private fun addAct(b: android.app.Notification.Builder, label: String, action: String, id: String) {
        val pi = actPi(action, id, (action + id).hashCode())
        if (Build.VERSION.SDK_INT >= 23) b.addAction(android.app.Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_manage), label, pi).build())
        else @Suppress("DEPRECATION") b.addAction(android.R.drawable.ic_menu_manage, label, pi)
    }

    private fun builder(chId: String, title: String, text: String, ongoing: Boolean, icon: Int): android.app.Notification.Builder {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(android.app.NotificationManager::class.java)
            nm.createNotificationChannel(android.app.NotificationChannel("alfy", "AlfyDownloader+", android.app.NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(android.app.NotificationChannel("alfy_alert", "Unduhan selesai/gagal", android.app.NotificationManager.IMPORTANCE_HIGH))
        }
        val b = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this, chId) else android.app.Notification.Builder(this)
        val pi = android.app.PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
        b.setContentTitle(title).setContentText(text).setStyle(android.app.Notification.BigTextStyle().bigText(text)).setContentIntent(pi)
            .setSmallIcon(icon).setOngoing(ongoing).setOnlyAlertOnce(true).setAutoCancel(!ongoing)
        return b
    }

    /** Notifikasi progres: persen, kecepatan, ETA + tombol Jeda / Batal. */
    private fun progNotif(act: List<DlItem>): android.app.Notification {
        val first = act.first()
        val sp = act.sumOf { it.speed }
        val pr = if (act.size == 1) first.progress else act.map { it.progress }.average().toInt()
        val remain = act.sumOf { maxOf(0L, it.total - it.done) }
        val eta = if (sp > 0 && remain > 0) fmtEta(remain / sp) else "--"
        val head = if (act.size > 1) "${act.size} unduhan" else first.name
        val txt = "$head\n$pr% • ${fmtSize(sp)}/s • $eta"
        val b = builder("alfy", "Mengunduh… $pr%", txt, true, android.R.drawable.stat_sys_download)
        b.setProgress(100, pr, false)
        addAct(b, "Jeda", "pause", first.id)
        addAct(b, "Batal", "cancel", first.id)
        return b.build()
    }

    private fun pausedNotif(id: String, name: String) {
        val b = builder("alfy", "Unduhan dijeda ⏸", name, false, android.R.drawable.stat_sys_download_done)
        b.setAutoCancel(false)
        addAct(b, "Lanjutkan", "start", id)
        addAct(b, "Batal", "cancel", id)
        postNotif(this, 3000 + (id.hashCode() and 0xFFFF), b.build())
    }

    private fun clearPaused(id: String) {
        try { getSystemService(android.app.NotificationManager::class.java).cancel(3000 + (id.hashCode() and 0xFFFF)) } catch (e: Throwable) { }
    }

    /** Daftarkan file ke MediaStore agar pemutar musik/notifikasi media memuat cover (album art). */
    private fun scanMedia(f: File) {
        try { android.media.MediaScannerConnection.scanFile(applicationContext, arrayOf(f.path), null, null) } catch (e: Throwable) { }
    }

    private fun notifyDone(name: String, size: Long) {
        val b = builder("alfy_alert", "Unduhan selesai ✓", "$name • ${fmtSize(size)}", false, android.R.drawable.stat_sys_download_done)
        if (Build.VERSION.SDK_INT < 26) b.setPriority(android.app.Notification.PRIORITY_HIGH).setDefaults(android.app.Notification.DEFAULT_ALL)
        try {
            val d = Repo.downloads.value.firstOrNull { it.name == name && it.status == Status.DONE }
            if (d != null && d.path.isNotEmpty()) {
                val ext = d.path.substringAfterLast('.', "").lowercase()
                val mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
                val open = Intent(Intent.ACTION_VIEW).setDataAndType(android.net.Uri.fromFile(File(d.path)), mime).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                val pi = android.app.PendingIntent.getActivity(this, d.id.hashCode(), open, android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
                if (Build.VERSION.SDK_INT >= 23) b.addAction(android.app.Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_view), "Buka", pi).build())
                else @Suppress("DEPRECATION") b.addAction(android.R.drawable.ic_menu_view, "Buka", pi)
                b.setContentIntent(pi)
            }
        } catch (e: Throwable) { }
        postNotif(this, 1000 + (name.hashCode() and 0xFFFF), b.build())
    }

    private fun notifyFail(name: String, err: String) {
        postNotif(this, 1000 + (name.hashCode() and 0xFFFF),
            makeNotif(this, "$name • $err", "Unduhan gagal ✗", -1, false, true, android.R.drawable.stat_notify_error))
    }

    override fun onStartCommand(i: Intent?, f: Int, sid: Int): Int {
        val id = i?.getStringExtra("id")
        val it0 = if (id != null && i?.action == "start") Repo.get(id) else null
        if (it0 != null) clearPaused(id!!)
        if (id != null && i?.action == "cancel") clearPaused(id)
        startForeground(2, if (it0 != null) progNotif(listOf(it0.copy(progress = 0, speed = 0, done = 0))) else makeNotif(this, "Menyiapkan unduhan…", "Mengunduh…"))
        if (id != null) when (i?.action) {
            "start" -> begin(id)
            "pause" -> pause(id, false)
            "cancel" -> { pause(id, true); Repo.remove(id) }
        }
        checkStop()
        return START_NOT_STICKY
    }

    private fun checkStop() {
        if (jobs.isEmpty()) { stopForeground(true); stopSelf() }
    }

    private fun begin(id: String) {
        if (jobs.containsKey(id)) return
        Repo.update(id) { it.copy(status = Status.QUEUED, error = "") }
        val j = scope.launch(start = CoroutineStart.LAZY) { runItem(id) }
        jobs[id] = j
        j.invokeOnCompletion { jobs.remove(id); Repo.save(); checkStop() }
        j.start()
    }

    private fun pause(id: String, cancel: Boolean) {
        if (!cancel) {
            Repo.update(id) { it.copy(status = Status.PAUSED, speed = 0) }
            Repo.get(id)?.let { pausedNotif(id, it.name) }
        }
        jobs[id]?.cancel()
        try { YoutubeDL.getInstance().destroyProcessById(id) } catch (e: Exception) { }
        try { hlsCancels[id]?.invoke() } catch (e: Throwable) { }
        Repo.save()
    }

    private fun onWifi(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        @Suppress("DEPRECATION")
        return cm.activeNetworkInfo?.type == ConnectivityManager.TYPE_WIFI
    }

    /** Smart Queue: tiap percobaan memegang 1 permit (maks MAX_PARALLEL serentak); saat jeda backoff permit dilepas agar antrean lain jalan. */
    private suspend fun runItem(id: String) {
        var retries = 0
        try {
            while (true) {
                val item = Repo.get(id) ?: return
                if (item.wifiOnly && !onWifi()) {
                    Repo.update(id) { it.copy(status = Status.PAUSED, error = "Menunggu WiFi") }; return
                }
                var failure: Exception? = null
                val hlsBypass = isHlsItem(item)   // HLS: lewati antrean (tanpa permit)
                if (!hlsBypass) sem.acquire()
                try {
                    if (Repo.get(id)?.status == Status.PAUSED) return
                    Repo.update(id) { it.copy(status = Status.DOWNLOADING) }
                    try { attempt(id, item) } catch (e: CancellationException) { throw e } catch (e: Exception) { failure = e }
                } finally { if (!hlsBypass) sem.release() }
                val e = failure ?: return
                val cur = Repo.get(id)
                if (cur == null || cur.status == Status.PAUSED) return
                val em = e.message ?: e.javaClass.simpleName
                if (item.retry && retries < MAX_RETRY && retryable(em)) {
                    retries++
                    Repo.update(id) { it.copy(status = Status.QUEUED, speed = 0, error = "Terputus, otomatis lanjut ($retries/$MAX_RETRY)…") }
                    waitNet(45_000)
                    delay(listOf(2500L, 6000L, 12000L)[retries - 1])
                    continue
                }
                val why = if (ScanReport.isRaw(em)) em else ScanReport.honest(em)   // v1.63: stderr ffmpeg mentah tidak diringkas
                Repo.update(id) { it.copy(status = Status.ERROR, error = why, speed = 0, progress = 0) }
                notifyFail(item.name, if (ScanReport.isRaw(why)) ScanReport.rawTail(why, 1) else why)
                return
            }
        } finally { chunkDone.keys.removeAll { it.startsWith("$id|") } }
    }

    /** Link kedaluwarsa/hilang (404/410) tidak dicoba ulang; selain itu (koneksi putus, timeout, 5xx, 403 token) dicoba lanjut. */
    private fun retryable(msg: String): Boolean = !(msg.startsWith("HTTP 404") || msg.startsWith("HTTP 410"))

    /** Tunggu jaringan kembali (maks ms) sebelum lanjut; berhenti cepat bila dibatalkan/dijeda. */
    private suspend fun waitNet(ms: Long) {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        var w = 0L
        while (w < ms) {
            @Suppress("DEPRECATION")
            if (cm.activeNetworkInfo?.isConnected == true) return
            delay(1500); w += 1500
        }
    }

    private suspend fun attempt(id: String, item: DlItem) {
        if (isHlsItem(item)) { ytdl(item); return }   // v1.139: m3u8 langsung Force Refresh + FFmpeg (tanpa lewat yt-dlp halaman / antrean)
        val pg = if (!AppPreferences.isRooted && item.page.isNotBlank() && item.kind != Kind.YTDLP) item.page else ""
        if (pg.isNotEmpty()) {
            // v1.63: non-root IG/YouTube -> yt-dlp (bv*+ba/b + merge mp4 + ffmpeg) jadi eksekutor utama
            val yi = item.copy(url = pg, kind = Kind.YTDLP, formatSel = null, referer = null)
            try { ytdl(yi); return } catch (e: CancellationException) { throw e } catch (e: Exception) {
                val cur = Repo.get(id)
                if (cur == null || cur.status == Status.PAUSED) throw e
                Repo.update(id) { it.copy(error = "", progress = 0) }
            }
            if (item.kind == Kind.DIRECT && !item.url.substringBefore('?').endsWith(".m3u8", true)) direct(item) else ytdl(item)
            completeStreams(item, pg)
            return
        }
        if (item.kind == Kind.DIRECT && !item.url.substringBefore('?').endsWith(".m3u8", true)) direct(item) else ytdl(item)
    }

    private class Spec(val ua: String?, val mergeUrl: String?, val mergeUa: String?)
    private fun spec(s: String?): Spec {
        var ua: String? = null; var m: String? = null; var mu: String? = null
        s?.lines()?.forEach { l ->
            when {
                l.startsWith("UA:") -> ua = l.substring(3)
                l.startsWith("MERGE:") -> m = l.substring(6)
                l.startsWith("AUA:") -> mu = l.substring(4)
            }
        }
        return Spec(ua, m, mu)
    }

    /** Unduh cepat: 4 koneksi paralel, potongan 4MB (menghindari throttle googlevideo). */
    private suspend fun fetch(url: String, ua: String?, ref: String?, dest: File, itemId: String, base: Long, grand: Long): Long {
        fun conn(range: String): HttpURLConnection {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 30000; c.readTimeout = 30000
            c.setRequestProperty("User-Agent", ua ?: Resolver.UA)
            ref?.let { c.setRequestProperty("Referer", it) }
            // v1.30: cookie WebView untuk host ini (CDN bertanda tangan sering menuntutnya)
            try { val ck = android.webkit.CookieManager.getInstance().getCookie(url); if (!ck.isNullOrBlank()) c.setRequestProperty("Cookie", ck) } catch (e: Throwable) { }
            c.setRequestProperty("Range", range)
            return c
        }
        val probe = conn("bytes=0-0")
        val code = probe.responseCode
        if (code !in 200..299) {
            probe.disconnect()
            // v1.30: link CDN kedaluwarsa/ditolak -> pindai ulang halaman asal agar link baru muncul di daftar
            if ((code == 401 || code == 403 || code == 404 || code == 410) && ref != null && ref.startsWith("http")) {
                try { Resolver.seen.remove(ref); Resolver.submit(ref, null, true, "Segarkan link") } catch (e: Throwable) { }
                throw IOException("HTTP $code (link kedaluwarsa, halaman dipindai ulang - pilih link baru di daftar)")
            }
            throw IOException("HTTP $code (link ditolak server)")
        }
        val cr = probe.getHeaderField("Content-Range")
        probe.disconnect()
        val size = cr?.substringAfterLast('/')?.toLongOrNull() ?: -1L
        if (size <= 0) throw IOException("ukuran file tidak diketahui")
        val ck = "$itemId|${dest.name}"
        val doneSet = chunkDone.getOrPut(ck) { java.util.concurrent.ConcurrentHashMap.newKeySet<Long>() }
        if (!dest.exists() || dest.length() != size) { doneSet.clear(); java.io.RandomAccessFile(dest, "rw").use { it.setLength(size) } }
        val next = java.util.concurrent.atomic.AtomicLong(0)
        val got = java.util.concurrent.atomic.AtomicLong(0)
        val chunk = 4L * 1024 * 1024
        coroutineScope {
            val rep = launch {
                var lastB = 0L; var lastT = System.currentTimeMillis(); var ema = 0L
                while (true) {
                    delay(300)
                    val now = System.currentTimeMillis()
                    val g = got.get()
                    val inst = (g - lastB) * 1000 / maxOf(1L, now - lastT)
                    ema = if (ema == 0L) inst else (inst * 6 + ema * 4) / 10
                    val sp = ema
                    lastB = g; lastT = now
                    val tot = if (grand > 0) grand else size
                    val dn = base + g
                    Repo.update(itemId) { it.copy(done = dn, total = tot, speed = sp, progress = (dn * 100 / tot).toInt().coerceIn(0, 100)) }
                }
            }
            (1..4).map {
                async(Dispatchers.IO) {
                    java.io.RandomAccessFile(dest, "rw").use { raf ->
                        val buf = ByteArray(65536)
                        while (true) {
                            val s = next.getAndAdd(chunk)
                            if (s >= size) break
                            val e = minOf(s + chunk - 1, size - 1)
                            if (doneSet.contains(s)) { got.addAndGet(e - s + 1); continue }   // sudah selesai pada percobaan sebelumnya (Resume)
                            var tries = 0
                            while (true) {
                                var cb = 0L
                                try {
                                    val c = conn("bytes=$s-$e")
                                    val cd = c.responseCode
                                    if (cd !in 200..299) { c.disconnect(); throw IOException("HTTP $cd") }
                                    raf.seek(s)
                                    c.inputStream.use { ins ->
                                        while (true) {
                                            val n = ins.read(buf)
                                            if (n < 0) break
                                            raf.write(buf, 0, n)
                                            got.addAndGet(n.toLong()); cb += n
                                            currentCoroutineContext().ensureActive()
                                        }
                                    }
                                    c.disconnect()
                                    doneSet.add(s)
                                    break
                                } catch (ex: IOException) {
                                    got.addAndGet(-cb)
                                    if (++tries >= 3) throw ex
                                }
                            }
                        }
                    }
                }
            }.awaitAll()
            rep.cancel()
        }
        return size
    }

    private fun mux(video: File, audio: File, out: File) {
        val vx = android.media.MediaExtractor(); vx.setDataSource(video.path)
        val ax = android.media.MediaExtractor(); ax.setDataSource(audio.path)
        fun pick(e: android.media.MediaExtractor, p: String): Int {
            for (i in 0 until e.trackCount) if (e.getTrackFormat(i).getString(android.media.MediaFormat.KEY_MIME)?.startsWith(p) == true) return i
            return -1
        }
        val vi = pick(vx, "video/"); val ai = pick(ax, "audio/")
        if (vi < 0 || ai < 0) throw IOException("track video/audio tidak ditemukan")
        vx.selectTrack(vi); ax.selectTrack(ai)
        val mx = android.media.MediaMuxer(out.path, android.media.MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val vt = mx.addTrack(vx.getTrackFormat(vi)); val at = mx.addTrack(ax.getTrackFormat(ai))
        mx.start()
        val buf = java.nio.ByteBuffer.allocate(4 * 1024 * 1024)
        val info = android.media.MediaCodec.BufferInfo()
        for ((ex, tr) in listOf(Pair(vx, vt), Pair(ax, at))) {
            while (true) {
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                val key = if (ex.sampleFlags and android.media.MediaExtractor.SAMPLE_FLAG_SYNC != 0) android.media.MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                info.set(0, n, ex.sampleTime, key)
                mx.writeSampleData(tr, buf, info)
                ex.advance()
            }
        }
        mx.stop(); mx.release(); vx.release(); ax.release()
    }

    private suspend fun fastDirect(item: DlItem, sp: Spec) {
        val dir = File(item.dir).apply { mkdirs() }
        val v = File(dir, item.name + ".v.part")
        val vSize = fetch(item.url, sp.ua, item.referer, v, item.id, 0L, if (sp.mergeUrl != null) item.total else 0L)
        var f: File
        var viaFf = false
        if (sp.mergeUrl != null) {
            val a = File(dir, item.name + ".a.part")
            fetch(sp.mergeUrl, sp.mergeUa, null, a, item.id, vSize, item.total)
            Repo.update(item.id) { it.copy(progress = 100, speed = 0, error = "Menggabungkan video + suara…") }
            f = uniqueFile(dir, item.name)
            try {
                if (processWithFFmpeg(v.path, a.path, f, toast = false) != null) viaFf = true
                else try { mux(v, a, f) } catch (e: Throwable) { f.delete(); toastMergeFail(); throw IOException("Gagal menggabungkan Audio/Video, file mungkin korup") }
            } finally { v.delete(); a.delete() }
        } else {
            f = uniqueFile(dir, item.name)
            v.renameTo(f)
        }
        if (!viaFf) f = fixFrag(f, item)
        if (item.isAudio) f = finishAudio(f, item)
        Repo.update(item.id) {
            it.copy(status = Status.DONE, progress = 100, path = f.path, name = f.name,
                total = f.length(), done = f.length(), speed = 0, error = "")
        }
        Repo.save()
        scanMedia(f); notifyDone(f.name, f.length())
    }

    private suspend fun direct(item: DlItem) {
        val sp = spec(item.formatSel)
        if (sp.mergeUrl != null || item.url.contains("googlevideo.com")) { fastDirect(item, sp); return }
        val dir = File(item.dir).apply { mkdirs() }
        val part = File(dir, item.name + ".part")
        var existing = if (part.exists()) part.length() else 0L
        val c = URL(item.url).openConnection() as HttpURLConnection
        c.connectTimeout = 30000; c.readTimeout = 30000
        c.setRequestProperty("User-Agent", Resolver.UA)
        item.referer?.let { c.setRequestProperty("Referer", it) }
        if (existing > 0) c.setRequestProperty("Range", "bytes=$existing-")
        val code = c.responseCode
        if (code !in 200..299) {
            c.disconnect()
            if (code == 416) part.delete()
            throw IOException("HTTP $code")
        }
        // Server tanpa Range (200): jangan mulai dari 0 - sambung ulang & buang byte yang sudah dimiliki (hemat file, progres tidak reset).
        val skipMode = existing > 0 && code == 200 && c.contentLengthLong > existing && (item.total <= 0L || c.contentLengthLong == item.total)
        val append = existing > 0 && (code == 206 || skipMode)
        if (!append) existing = 0
        val len = c.contentLengthLong
        val total = if (len > 0) (if (skipMode) len else len + existing) else 0L
        val acc = code == 206 || (c.getHeaderField("Accept-Ranges")?.contains("bytes", true) == true)
        Repo.update(item.id) { it.copy(total = total, resumable = acc || skipMode || total > 0, error = if (skipMode) "Server tanpa Range: melewati ${fmtSize(existing)} yang sudah diunduh…" else "") }
        var done = existing
        var toSkip = if (skipMode) existing else 0L
        var net = 0L
        var ema = 0L
        var lastT = System.currentTimeMillis()
        var lastB = 0L
        c.inputStream.use { ins ->
            FileOutputStream(part, append).use { out ->
                val buf = ByteArray(65536)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    net += n
                    var off = 0
                    if (toSkip > 0) { val k = minOf(n.toLong(), toSkip).toInt(); toSkip -= k; off = k }
                    if (n > off) { out.write(buf, off, n - off); done += (n - off) }
                    currentCoroutineContext().ensureActive()
                    val now = System.currentTimeMillis()
                    if (now - lastT >= 300) {
                        val inst = (net - lastB) * 1000 / (now - lastT)
                        ema = if (ema == 0L) inst else (inst * 6 + ema * 4) / 10
                        val sp = ema
                        lastT = now; lastB = net
                        val d = done
                        Repo.update(item.id) {
                            it.copy(done = d, speed = sp, progress = if (total > 0) (d * 100 / total).toInt() else 0, error = if (toSkip > 0) "Melewati ${fmtSize(toSkip)} lagi (server tanpa Range)…" else "")
                        }
                    }
                }
            }
        }
        c.disconnect()
        val f = uniqueFile(dir, item.name)
        part.renameTo(f)
        val fin = if (item.isAudio) finishAudio(f, item) else fixFrag(f, item)
        Repo.update(item.id) {
            it.copy(status = Status.DONE, progress = 100, path = fin.path, name = fin.name,
                total = fin.length(), done = fin.length(), speed = 0, error = "")
        }
        Repo.save()
        scanMedia(fin); notifyDone(fin.name, fin.length())
    }

    /** v1.97: MP4 fragmented (moof/DASH, mis. video.twimg.com) sering macet/korup saat diputar -> remux ffmpeg (-c copy) ke MP4 utuh. Gagal = file asli dibiarkan. */
    private fun isFragMp4(f: File): Boolean = try {
        java.io.RandomAccessFile(f, "r").use { r ->
            var pos = 0L; var n = 0; val h = ByteArray(8); var frag = false
            while (n++ < 200 && pos + 8 <= r.length()) {
                r.seek(pos); r.readFully(h)
                var sz = ((h[0].toLong() and 0xff) shl 24) or ((h[1].toLong() and 0xff) shl 16) or ((h[2].toLong() and 0xff) shl 8) or (h[3].toLong() and 0xff)
                val t = String(h, 4, 4, Charsets.ISO_8859_1)
                if (t == "moof" || t == "sidx" || t == "styp") { frag = true; break }
                if (sz == 1L) { val b = ByteArray(8); r.readFully(b); sz = 0; for (x in b) sz = (sz shl 8) or (x.toLong() and 0xff) }
                if (sz < 8) break
                pos += sz
            }
            frag
        }
    } catch (e: Throwable) { false }

    /** v1.108: SEMUA hasil unduhan video (tool apa pun) lewat FFmpeg terpusat (remux -c copy) agar index/suara tidak korup. Gagal = file asli dibiarkan + Toast. */
    private fun fixFrag(f: File, item: DlItem): File {
        if (item.isAudio || item.audioExt.isNotEmpty()) return f
        if (f.extension.lowercase() !in VIDEO_EXT) return f
        Repo.update(item.id) { it.copy(progress = 100, speed = 0, error = "Memproses FFmpeg (remux)…") }
        return processWithFFmpeg(f.path) ?: f
    }

    private val VIDEO_EXT = setOf("mp4", "m4v", "mov", "mkv", "webm", "ts", "m2ts", "mts", "flv", "3gp", "")

    private fun toastMergeFail() {
        Handler(Looper.getMainLooper()).post {
            try { Toast.makeText(Repo.app, "Gagal menggabungkan Audio/Video, file mungkin korup", Toast.LENGTH_LONG).show() } catch (e: Throwable) { }
        }
    }

    /**
     * v1.108: PUSAT FFmpeg. video/audio boleh path file atau URL (URL http + [headers] untuk HLS/DASH).
     * audio != null -> merge (video 0:v:0 + audio 1:a:0); audio == null -> remux satu file (index diperbaiki).
     * Parameter: -c copy -bsf:a aac_adtstoasc (fallback tanpa bsf). Hasil ke [out]; bila null, menggantikan file asli (ekstensi non-mp4 -> .mp4).
     * Mengembalikan file hasil, atau null bila gagal (file asli tidak disentuh; Toast error bila [toast]).
     */
    fun processWithFFmpeg(video: String, audio: String? = null, out: File? = null, headers: String? = null, toast: Boolean = true): File? {
        var tmp: File? = null
        var inCopy: File? = null
        try {
            val bin = pickFfmpeg() ?: throw IOException("binary ffmpeg tidak ditemukan")
            val src = if (video.startsWith("http", true)) null else File(video)
            if (src != null && (!src.exists() || (src.length() < 1024 && !(src.name.endsWith(".txt", true) || src.name.endsWith(".m3u8", true))))) throw IOException("file sumber kosong/hilang")
            // input di storage publik -> salin ke cache dulu agar binary ffmpeg pasti bisa membacanya
            val vid = if (src != null && !src.path.startsWith(Repo.app.cacheDir.path) && !src.path.startsWith(Repo.app.filesDir.path)) {
                ffWork("in_${System.nanoTime()}_" + src.name).also { src.copyTo(it, overwrite = true); inCopy = it }.path
            } else video
            val target = out ?: src ?: throw IOException("output tidak ditentukan")
            val dir = target.parentFile ?: throw IOException("folder output tidak valid")
            val t = ffWork("out_${System.nanoTime()}.mp4"); t.delete(); tmp = t
            fun inp(x: String): List<String> =
                if (x.startsWith("http", true))
                    (if (headers.isNullOrBlank()) emptyList() else listOf("-headers", headers)) +
                        listOf("-allowed_extensions", "ALL", "-protocol_whitelist", "file,http,https,tcp,tls,crypto", "-i", x)
                else if (x.endsWith(".m3u8", true)) listOf("-allowed_extensions", "ALL", "-protocol_whitelist", "file,crypto,data", "-i", x)   // m3u8 lokal (kunci/segmen dari cache)
                else if (x.endsWith(".txt", true)) listOf("-f", "concat", "-safe", "0", "-i", x)   // v1.151: daftar segmen .ts lokal (concat demuxer)
                else listOf("-i", x)
            val maps = if (audio != null) listOf("-map", "0:v:0", "-map", "1:a:0") else listOf("-map", "0:v?", "-map", "0:a?")
            var ok = false
            var last = ""
            for (bsf in listOf(true, false)) {
                t.delete()
                val args = listOf("-y", "-nostdin", "-hide_banner") + inp(vid) + (if (audio != null) inp(audio) else emptyList()) + maps +
                    listOf("-c", "copy") + (if (bsf) listOf("-bsf:a", "aac_adtstoasc") else emptyList()) + listOf("-movflags", "+faststart", t.path)
                val r = runFfmpeg(bin, args)
                if (r.first == 0 && t.exists() && t.length() > 1024) { ok = true; break }
                last = r.second.takeLast(300)
            }
            if (!ok) throw IOException("ffmpeg gagal: $last")
            var dest = out ?: if (target.extension.lowercase() in listOf("mp4", "m4v", "mov")) target else File(dir, target.nameWithoutExtension + ".mp4")
            if (out == null && src != null && dest.path != src.path && dest.exists()) dest = uniqueFile(dir, dest.name)
            val moved = moveToFinal(t, dest) ?: throw IOException("gagal memindahkan hasil ke folder tujuan")
            if (out == null && src != null && dest.path != src.path) src.delete()
            return moved
        } catch (e: Throwable) {
            try { tmp?.delete() } catch (x: Throwable) { }
            android.util.Log.e("AlfyFFmpeg", "processWithFFmpeg gagal", e)
            if (toast) toastMergeFail()
            return null
        } finally {
            try { inCopy?.delete() } catch (x: Throwable) { }
        }
    }

    /** v1.10: file valid MP4 punya "ftyp" di byte 4-8; hasil HLS (MPEG-TS) tidak bisa diputar sebelum dikonversi. */
    private fun isMp4(f: File): Boolean = try {
        f.inputStream().use { s -> val b = ByteArray(12); val n = s.read(b); n >= 12 && String(b, 4, 4, Charsets.ISO_8859_1) in listOf("ftyp", "moov", "mdat", "free", "wide") }
    } catch (e: Exception) { true }

    /** Cari og:image / twitter:image dari halaman sumber (untuk situs non-YouTube). */
    private fun ogImage(page: String): String? = try {
        val c = URL(page).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 10000
        c.setRequestProperty("User-Agent", Resolver.UA)
        val html = c.inputStream.use { ins -> String(ins.readBytes().let { if (it.size > 400_000) it.copyOf(400_000) else it }, Charsets.UTF_8) }
        c.disconnect()
        val r1 = Regex("<meta[^>]+(?:property|name)=[\"'](?:og:image(?::secure_url)?|twitter:image)[\"'][^>]*content=[\"']([^\"']+)", RegexOption.IGNORE_CASE)
        val r2 = Regex("<meta[^>]+content=[\"']([^\"']+)[\"'][^>]*(?:property|name)=[\"'](?:og:image|twitter:image)[\"']", RegexOption.IGNORE_CASE)
        val u = (r1.find(html) ?: r2.find(html))?.groupValues?.get(1)?.replace("&amp;", "&")
        if (u != null && u.startsWith("//")) "https:$u" else if (u != null && u.startsWith("http")) u else null
    } catch (e: Throwable) { null }

    private fun findFfmpeg(): File? {
        val roots = listOfNotNull(Repo.app.noBackupFilesDir, Repo.app.filesDir, File(Repo.app.applicationInfo.nativeLibraryDir))
        for (r in roots) {
            val hit = r.walkTopDown().maxDepth(8).firstOrNull { it.isFile && (it.name == "libffmpeg.so" || it.name == "ffmpeg") && it.length() > 100_000 }
            if (hit != null) { try { hit.setExecutable(true) } catch (e: Exception) { }; return hit }
        }
        return null
    }

    // v1.35: helper ffmpeg khusus cover (findFfmpeg lama tidak diubah, dipakai remuxMp4)
    private fun ffmpegEnv(pb: ProcessBuilder, bin: File) {
        val extra = File(Repo.app.noBackupFilesDir, "youtubedl-android/packages/ffmpeg/usr/lib")
        val libs = listOfNotNull(bin.parentFile, bin.parentFile?.parentFile?.let { File(it, "lib") }, extra).filter { it.isDirectory }.joinToString(":") { it.path }
        pb.environment()["LD_LIBRARY_PATH"] = libs + ":" + (System.getenv("LD_LIBRARY_PATH") ?: "")
    }

    /** Folder kerja FFmpeg yang pasti bisa ditulis (cache app). */
    private fun ffWork(name: String): File { val d = File(Repo.app.cacheDir, "ffwork"); d.mkdirs(); return File(d, name) }

    /** Pindahkan hasil FFmpeg dari cache ke folder final (rename, lalu salin bila beda volume). null = gagal. */
    private fun moveToFinal(tmp: File, dest: File): File? = try {
        dest.parentFile?.mkdirs()
        val part = File(dest.parentFile, dest.name + ".part")
        part.delete()
        tmp.copyTo(part, overwrite = true)
        dest.delete()
        if (part.renameTo(dest)) { tmp.delete(); dest } else { part.delete(); null }
    } catch (e: Throwable) { android.util.Log.e("AlfyFFmpeg", "moveToFinal gagal", e); null }

    private fun runFfmpeg(bin: File, args: List<String>): Pair<Int, String> {
        val pb = ProcessBuilder(listOf(bin.path) + args)
        pb.redirectErrorStream(true)
        ffmpegEnv(pb, bin)
        var p: Process? = null
        try {
            p = pb.start()
            val out = p.inputStream.use { it.readBytes() }.toString(Charsets.UTF_8)
            val code = p.waitFor()
            if (code != 0) android.util.Log.w("AlfyFFmpeg", "exit=$code stderr: ${out.takeLast(400)}")
            return Pair(code, out)
        } finally {
            try { p?.inputStream?.close() } catch (e: Exception) { }
            try { p?.outputStream?.close() } catch (e: Exception) { }
            try { p?.errorStream?.close() } catch (e: Exception) { }
            try { p?.destroy() } catch (e: Exception) { }
            p = null
        }
    }

    /** Pilih binary ffmpeg yang benar-benar bisa jalan (libffmpeg.so di nativeLibraryDir dulu, lalu hasil findFfmpeg). */
    /** Ekstrak assets/ffmpeg -> filesDir/ffmpeg (bila belum ada) lalu chmod 755. */
    private fun extractAssetFfmpeg(): File? = try {
        val out = File(Repo.app.filesDir, "ffmpeg")
        if (!out.exists() || out.length() < 100_000) {
            Repo.app.assets.open("ffmpeg").use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        }
        try { Runtime.getRuntime().exec(arrayOf("chmod", "755", out.absolutePath)).waitFor() } catch (e: Throwable) { }
        out.setExecutable(true, false)
        if (out.exists()) out else null
    } catch (e: Throwable) { null }

    private fun pickFfmpeg(): File? {
        // v1.132: mesin FFmpeg resmi youtubedl-android (com.yausername.ffmpeg.FFmpeg); tanpa pencarian biner manual
        try { com.yausername.ffmpeg.FFmpeg.getInstance().init(Repo.app) } catch (e: Throwable) { android.util.Log.w("AlfyFFmpeg", "FFmpeg.init gagal", e) }
        val c = File(Repo.app.noBackupFilesDir, "youtubedl-android/packages/ffmpeg/usr/lib/libffmpeg.so")
        val n = File(Repo.app.applicationInfo.nativeLibraryDir, "libffmpeg.so")
        val bin = if (c.exists()) c else if (n.exists()) n else null
        if (bin == null) { android.util.Log.e("AlfyFFmpeg", "FFmpeg library belum siap"); return null }
        try { bin.setExecutable(true) } catch (e: Exception) { }
        return bin
    }

    /** v1.34: pasang thumbnail video YouTube sebagai album art (cover) pada file audio lewat ffmpeg bawaan. v1.35: log jelas, webm/opus YouTube -> m4a, webp -> jpg. Gagal = file asli dibiarkan (unduhan tidak gagal). */
    private fun looksMp3(f: File): Boolean = try {
        f.inputStream().use { val b = ByteArray(3); if (it.read(b) < 3) false else (b[0] == 'I'.code.toByte() && b[1] == 'D'.code.toByte() && b[2] == '3'.code.toByte()) || ((b[0].toInt() and 0xFF) == 0xFF && (b[1].toInt() and 0xE0) == 0xE0) }
    } catch (e: Throwable) { false }

    /** Audio hasil pencarian musik (toMp3): konversi ke .mp3 lewat ffmpeg, lalu pasang cover. Gagal = file asli dibiarkan. */
    private fun finishAudio(src: File, item: DlItem): File = embedCover(if (item.toMp3) convertMp3(src, item) else src, item)

    private fun convertMp3(src: File, item: DlItem): File {
        try {
            val dir = src.parentFile ?: return src
            val dest = File(dir, src.nameWithoutExtension + ".mp3")
            if (looksMp3(src)) { if (src.path == dest.path) return src; dest.delete(); return if (src.renameTo(dest)) dest else src }
            val bin = pickFfmpeg() ?: return src
            Repo.update(item.id) { it.copy(progress = 100, speed = 0, error = "Mengonversi ke MP3…") }
            val tmp = File(dir, "." + src.nameWithoutExtension + ".conv.mp3")
            tmp.delete()
            var r = runFfmpeg(bin, listOf("-y", "-i", src.path, "-vn", "-map_metadata", "0", "-c:a", "libmp3lame", "-q:a", "2", "-id3v2_version", "3", tmp.path))
            if (r.first != 0 || tmp.length() < 1024) { tmp.delete(); r = runFfmpeg(bin, listOf("-y", "-i", src.path, "-vn", "-c:a", "mp3", "-q:a", "2", tmp.path)) }
            if (r.first != 0 || tmp.length() < 1024) { tmp.delete(); android.util.Log.e("AlfyMp3", "ffmpeg gagal ke mp3: ${r.second.takeLast(200)}"); return src }
            src.delete(); dest.delete()
            val res = if (tmp.renameTo(dest)) dest else tmp
            try { scanMedia(res) } catch (e: Throwable) { }
            return res
        } catch (e: Throwable) { android.util.Log.e("AlfyMp3", "convertMp3 error", e); return src }
    }

    private fun embedCover(src: File, item: DlItem): File {
        val tag = "AlfyCover"
        try {
            val ext = src.extension.lowercase()
            val vid = YtCover.idOf(item.thumb.ifEmpty { null }, item.url, item.referer)
            val needM4a = vid != null && (ext == "webm" || ext == "opus" || ext == "ogg" || ext == "weba")
            if (ext != "m4a" && ext != "mp3" && ext != "mp4" && ext != "flac" && !needM4a) {
                android.util.Log.i(tag, "format .$ext tidak didukung untuk cover (${src.name})"); return src
            }
            android.util.Log.i(tag, "mulai: file=${src.name} ext=$ext idVideo=$vid")
            val bin = pickFfmpeg() ?: return src
            Repo.update(item.id) { it.copy(progress = 100, speed = 0, error = "Memasang cover…") }
            val img = File(src.parentFile, "." + src.nameWithoutExtension + ".cover.jpg")
            val urls = ArrayList<String>()
            // YouTube: gambar sesuai ID video didahulukan, fallback resolusi turun
            if (vid != null) for (q in listOf("maxresdefault", "sddefault", "hqdefault", "mqdefault")) urls.add("https://i.ytimg.com/vi/$vid/$q.jpg")
            if (item.img.startsWith("http")) urls.add(item.img)
            var ok = false
            var og = false
            var i = 0
            while (!ok) {
                if (i >= urls.size) {
                    if (og) break
                    og = true
                    val ref = item.referer
                    if (vid == null && ref != null && ref.startsWith("http") && !ref.contains("googlevideo")) { val u = ogImage(ref); if (u != null) urls.add(u) }
                    if (i >= urls.size) break
                }
                val u = urls[i++]
                try {
                    val c = URL(u).openConnection() as HttpURLConnection
                    c.connectTimeout = 8000; c.readTimeout = 10000
                    c.setRequestProperty("User-Agent", Resolver.UA)
                    item.referer?.let { c.setRequestProperty("Referer", it) }
                    val rc = c.responseCode
                    if (rc == 200) {
                        c.inputStream.use { ins -> FileOutputStream(img).use { o -> ins.copyTo(o) } }
                        val hd = ByteArray(12)
                        try { img.inputStream().use { it.read(hd) } } catch (e: Exception) { }
                        val isJpg = hd[0] == 0xFF.toByte() && hd[1] == 0xD8.toByte()
                        val isPng = hd[0] == 0x89.toByte() && hd[1] == 'P'.code.toByte()
                        val isWebp = hd[0] == 'R'.code.toByte() && hd[1] == 'I'.code.toByte() && hd[8] == 'W'.code.toByte() && hd[9] == 'E'.code.toByte()
                        if (img.length() > 2048 && isWebp) {
                            val jp = File(img.parentFile, img.name + ".jpg")
                            val r = runFfmpeg(bin, listOf("-y", "-i", img.path, "-frames:v", "1", "-q:v", "2", jp.path))
                            if (r.first == 0 && jp.length() > 2048) { img.delete(); jp.renameTo(img); ok = true }
                            else { jp.delete(); android.util.Log.w(tag, "konversi webp->jpg gagal: ${r.second.takeLast(200)}") }
                        } else if (img.length() > 2048 && (isJpg || isPng)) ok = true
                        else android.util.Log.w(tag, "gambar tidak valid dari $u (ukuran=${img.length()})")
                    } else android.util.Log.w(tag, "HTTP $rc untuk $u -> coba fallback berikutnya")
                    c.disconnect()
                } catch (e: Exception) { android.util.Log.w(tag, "gagal ambil $u: ${e.javaClass.simpleName} ${e.message}") }
            }
            if (!ok) { img.delete(); android.util.Log.w(tag, "tidak ada gambar yang bisa diambil, audio tanpa cover (${src.name})"); return src }
            val tmpExt = if (needM4a) "m4a" else ext
            val tmp = File(src.parentFile, "." + src.nameWithoutExtension + ".cov." + tmpExt)
            tmp.delete()
            val cmd = ArrayList<String>(listOf("-y", "-i", src.path, "-i", img.path, "-map", "0:a", "-map", "1:v"))
            if (needM4a) cmd.addAll(listOf("-c:a", "aac", "-b:a", "192k", "-c:v", "copy")) else cmd.addAll(listOf("-c", "copy"))
            cmd.addAll(listOf("-disposition:v:0", "attached_pic"))
            if (ext == "mp3") cmd.addAll(listOf("-id3v2_version", "3", "-metadata:s:v", "title=Album cover", "-metadata:s:v", "comment=Cover (front)"))
            cmd.add(tmp.path)
            val r = runFfmpeg(bin, cmd)
            img.delete()
            val minOk = if (needM4a) 1024L else src.length() / 2
            if (r.first != 0 || !tmp.exists() || tmp.length() < minOk) {
                android.util.Log.e(tag, "ffmpeg gagal pasang cover (kode ${r.first}): ${r.second.takeLast(300)}")
                tmp.delete(); return src
            }
            val dest = if (needM4a) File(src.parentFile, src.nameWithoutExtension + ".m4a") else File(src.path)
            if (needM4a && dest.exists()) { android.util.Log.w(tag, "${dest.name} sudah ada, cover tidak dipasang"); tmp.delete(); return src }
            val res = if (src.delete() && tmp.renameTo(dest)) dest else if (dest.exists()) dest else tmp
            android.util.Log.i(tag, "cover terpasang: ${res.name}")
            try { scanMedia(res) } catch (e: Throwable) { }
            return res
        } catch (e: Throwable) { android.util.Log.e("AlfyCover", "embedCover error (unduhan tetap disimpan)", e); return src }
    }

    /** Konversi (tanpa encode ulang) MPEG-TS/HLS -> MP4 dengan ffmpeg bawaan. Gagal = file asli dibiarkan. */
    private fun remuxMp4(src: File, base: String): File {
        try {
            val bin = pickFfmpeg() ?: return src
            val tmp = ffWork("remux_${System.nanoTime()}.mp4")
            tmp.delete()
            val pb = ProcessBuilder(bin.path, "-y", "-i", src.path, "-c", "copy", "-bsf:a", "aac_adtstoasc", "-movflags", "+faststart", tmp.path)
            pb.redirectErrorStream(true)
            val libs = listOfNotNull(bin.parentFile, bin.parentFile?.parentFile?.let { File(it, "lib") }).filter { it.isDirectory }.joinToString(":") { it.path }
            pb.environment()["LD_LIBRARY_PATH"] = libs + ":" + (System.getenv("LD_LIBRARY_PATH") ?: "")
            val p = pb.start()
            val errTxt = p.inputStream.readBytes().toString(Charsets.UTF_8)
            val code = p.waitFor()
            if (code != 0) android.util.Log.w("AlfyFFmpeg", "remux exit=$code stderr: ${errTxt.takeLast(400)}")
            if (code != 0 || !tmp.exists() || tmp.length() < 1024) { tmp.delete(); return src }
            val dest = File(src.parentFile, "$base.mp4")
            val moved = moveToFinal(tmp, dest) ?: run { tmp.delete(); return src }
            if (dest.path != src.path) src.delete()
            return moved
        } catch (e: Throwable) { return src }
    }

    // HLS .m3u8 -> VideoDownloader (cadangan FFmpeg).
    private val hlsCancels = ConcurrentHashMap<String, () -> Unit>()
    private val preHls = ConcurrentHashMap<String, Pair<Long, Resolver.HlsFresh>>()
    private val preMutex = kotlinx.coroutines.sync.Mutex()
    private fun hlsPage(item: DlItem): String? = item.page.takeIf { it.startsWith("http") } ?: item.referer
    private fun isHlsItem(item: DlItem): Boolean {
        val m3u8Path = item.url.substringBefore('?').endsWith(".m3u8", true)
        val pgSite = Regex("youtu|instagram\\.com|facebook\\.com|fb\\.watch", RegexOption.IGNORE_CASE).containsMatchIn(item.page)
        val pgActive = !AppPreferences.isRooted && item.page.isNotBlank() && item.kind != Kind.YTDLP && !(m3u8Path && !pgSite)
        return !pgActive && !item.url.contains("youtu") && (item.kind == Kind.HLS || item.url.substringBefore('?').endsWith(".m3u8", true))
    }
    private val HLS_UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36"
    private val hlsErrTl = ThreadLocal<String>()
    private var hlsErr: String
        get() = hlsErrTl.get() ?: ""
        set(v) { hlsErrTl.set(v) }   // unduhan HLS serentak tidak saling menimpa pesan error

    /** Link .m3u8 baru: WebView tersembunyi, sesi dihapus (cookie+cache+history), JS & DOM storage aktif, onPageFinished + 2 dtk -> paksa Play, sadap request .m3u8. */
    private fun forceFreshHls(item: DlItem): Resolver.HlsFresh {
        val page = hlsPage(item)?.takeIf { it.startsWith("http") } ?: return Resolver.HlsFresh(null, HLS_UA, "WebView: tidak ada halaman embed -> pakai link lama")
        val found = java.util.concurrent.CopyOnWriteArrayList<String>()
        val h = Handler(Looper.getMainLooper())
        var wv: android.webkit.WebView? = null
        val playJs = "var v = document.querySelectorAll('video'); if(v.length>0){v[0].play(); v[0].click();}" +
            "var b = document.querySelectorAll('.play-button, .vjs-big-play-button, button[aria-label=\"Play\"], [class*=\"play\"]'); if(b.length>0){b[0].click();}"
        h.post {
            try {
                val cm = android.webkit.CookieManager.getInstance()
                cm.removeAllCookies(null); cm.flush()
                val w = android.webkit.WebView(Repo.app)
                wv = w
                w.clearCache(true); w.clearHistory()
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.mediaPlaybackRequiresUserGesture = false
                w.settings.userAgentString = HLS_UA
                w.webViewClient = object : android.webkit.WebViewClient() {
                    override fun shouldInterceptRequest(view: android.webkit.WebView, request: android.webkit.WebResourceRequest): android.webkit.WebResourceResponse? {
                        val u = request.url.toString()
                        if (u.startsWith("http") && u.substringBefore('?').endsWith(".m3u8", true)) found.add(u)
                        return null
                    }
                    override fun onPageFinished(view: android.webkit.WebView, url: String) {
                        view.postDelayed({ try { view.evaluateJavascript(playJs, null) } catch (e: Throwable) { } }, 2000)
                    }
                }
                w.loadUrl(page, mapOf("Referer" to (item.referer?.takeIf { it.startsWith("http") } ?: page)))
            } catch (e: Throwable) { }
        }
        var waited = 0
        var firstAt = -1
        while (waited < 25_000) {
            if (found.isNotEmpty() && firstAt < 0) firstAt = waited
            if (firstAt >= 0 && waited - firstAt >= 1500) break
            try { Thread.sleep(250) } catch (e: InterruptedException) { break }
            waited += 250
        }
        h.post { WvClean.kill(wv); wv = null }
        val url = found.firstOrNull()
        return if (url != null) Resolver.HlsFresh(url, HLS_UA, "WebView bersih + paksa play, m3u8 baru" + if (url == item.url) " (sama dgn lama)" else "", page, null)
        else Resolver.HlsFresh(null, HLS_UA, "WebView: m3u8 baru TIDAK ditemukan -> pakai link lama", page, null)
    }

    /** HLS: VideoDownloader (JeffMony) mengunduh+menggabung; gagal merge -> FFmpeg concat .ts lokal. */
    private fun hlsMedia3(item: DlItem, dir: File, base: String): File? {
        hlsErr = ""
        preHls.remove(item.id)
        val fresh = try { forceFreshHls(item) } catch (e: Throwable) { Resolver.HlsFresh(null, null, "refresh error: " + e.javaClass.simpleName) }
        val srcUrl = fresh.url ?: item.url
        if (srcUrl != item.url) Repo.update(item.id) { it.copy(url = srcUrl) }
        val ua = fresh.ua?.takeIf { it.isNotBlank() } ?: HLS_UA
        val log = StringBuilder("[refresh] ").append(fresh.how).append('\n')
        log.append("[url] ").append(srcUrl.take(160)).append('\n')
        val pairs = LinkedHashMap<String, String>()
        fun originOf(ref: String) = try { val u = URL(ref); "${u.protocol}://${u.host}" } catch (e: Throwable) { ref.trimEnd('/') }
        fresh.ref?.takeIf { it.startsWith("http") }?.let { pairs[it] = originOf(it) }
        item.referer?.takeIf { it.startsWith("http") }?.let { pairs[it] = "https://vldey.mom" }
        val refs = LinkedHashSet<String>()
        Resolver.vidlyxRef(srcUrl, item.referer)?.let { refs.add(it) }
        if (srcUrl.contains("vldey", true) || item.referer?.contains("vldey", true) == true) refs.add("https://vldey.mom/")
        refs.add("https://vldey.mom/"); refs.add(Resolver.jwRef(srcUrl)); refs.add("https://vidlyx.lol/")
        for (r in refs) if (!pairs.containsKey(r)) pairs[r] = originOf(r)
        try { File(Repo.app.cacheDir, "hlsdl").listFiles()?.forEach { if (it.name != item.id && System.currentTimeMillis() - it.lastModified() > 3L * 86400_000L) it.deleteRecursively() } } catch (e: Throwable) { }
        val finalOut = File(dir, "$base.mp4")
        val out = ffWork("hls_${item.id}.mp4")
        try { dir.listFiles { x -> x.name.startsWith("$base.") && x.name != finalOut.name && (x.name.endsWith(".ts") || x.name.endsWith(".part") || x.name.endsWith(".ytdl") || x.name.endsWith(".m3u8") || x.name.endsWith(".fix.mp4") || x.name.endsWith(".tmp")) }?.forEach { it.delete() } } catch (e: Throwable) { }
        var n = 0
        // Percobaan #1 = persis seperti preview ExoPlayer: UA asli item + hanya Referer (tanpa Origin/Cookie).
        val attempts = ArrayList<Triple<String, String?, Boolean>>()
        (item.referer?.takeIf { it.startsWith("http") } ?: fresh.ref?.takeIf { it.startsWith("http") })?.let { attempts.add(Triple(it, null, true)) }
        if (attempts.isEmpty()) pairs.entries.firstOrNull()?.let { attempts.add(Triple(it.key, it.value, false)) }   // v1.64: hanya 1x percobaan
        for ((ref, origin, plain) in attempts.take(1)) {
            n++
            out.delete()
            val props = HashMap<String, String>()
            props["Referer"] = ref
            props["Origin"] = origin ?: originOf(ref)
            if (!plain) props["Accept"] = "*/*"
            val uaTry = if (plain) (uaOf(item.formatSel)?.takeIf { it.isNotBlank() } ?: Resolver.UA) else ua
            log.append("[#$n] ").append(if (plain) "preview-mode " else "").append("Referer=").append(ref).append(" Origin=").append(props["Origin"] ?: "-").append(" Cookie=kosong\n")
            val cacheDir = File(Repo.app.cacheDir, "hlsdl/${item.id}")
            try {
                cacheDir.mkdirs()   // TIDAK dihapus: segmen yang sudah terunduh dipakai lagi (lanjut / coba header lain / ulang merge)
                val err = try { hlsDownloadMerge(item, srcUrl, uaTry, props, cacheDir, out) } catch (e: Throwable) { "MERGE: exception $e".take(300) }
                val cur = Repo.get(item.id)
                if (cur == null) { out.delete(); try { cacheDir.deleteRecursively() } catch (e: Throwable) { }; throw IOException("dijeda") }
                if (cur.status == Status.PAUSED) { out.delete(); throw IOException("dijeda") }
                if (err == null && out.exists() && out.length() > 1024) {
                    val mv = moveToFinal(out, finalOut)
                    if (mv != null) { try { cacheDir.deleteRecursively() } catch (e: Throwable) { }; return mv }
                    log.append("[move] gagal memindahkan ke ").append(finalOut.parent).append('\n')
                } else log.append("[#$n] ").append(err ?: "output kosong").append('\n')
            } catch (e: IOException) { if (e.message == "dijeda") throw e; log.append("[exec] ").append(e.toString().take(300)).append('\n') }
            catch (e: Throwable) { log.append("[exec] ").append(e.toString().take(300)).append('\n') }
        }
        out.delete()
        hlsErr = log.toString().trimEnd().takeLast(4000)
        return null
    }

    // ===== VideoDownloader (JeffMony): unduh .m3u8 (termasuk EXT-X-MAP) utuh -> MP4 =====
    private class VdState { @Volatile var done = false; @Volatile var err: String? = null; @Volatile var path: String? = null; @Volatile var pct = 0f; @Volatile var speed = 0f; @Volatile var dl = 0L; @Volatile var tot = 0L; @Volatile var tick = System.currentTimeMillis() }
    private val vdStates = ConcurrentHashMap<String, VdState>()
    private val vdInit = java.util.concurrent.atomic.AtomicBoolean(false)
    private fun vdEnsure() {
        if (vdInit.getAndSet(true)) return
        val config: VideoDownloadConfig = VideoDownloadManager.Build(this).setCacheRoot(cacheDir.absolutePath).setShouldM3U8Merged(true).buildConfig()
        VideoDownloadManager.getInstance().initConfig(config)
        VideoDownloadManager.getInstance().setGlobalDownloadListener(object : DownloadListener() {
            override fun onDownloadDefault(item: VideoTaskItem) { }
            override fun onDownloadPending(item: VideoTaskItem) { }
            override fun onDownloadPrepare(item: VideoTaskItem) { }
            override fun onDownloadStart(item: VideoTaskItem) { }
            override fun onDownloadProgress(item: VideoTaskItem) {
                val s = vdStates[item.url] ?: return
                val now = System.currentTimeMillis()
                val downloadedSize = item.downloadSize
                val totalSize = item.totalSize
                if (downloadedSize > s.dl) { s.tick = now }
                s.dl = downloadedSize; s.tot = totalSize
                s.pct = item.percent
            }
            override fun onDownloadSpeed(item: VideoTaskItem) { vdStates[item.url]?.let { it.speed = item.speed } }
            override fun onDownloadPause(item: VideoTaskItem) { }
            override fun onDownloadError(item: VideoTaskItem) { vdStates[item.url]?.let { it.err = "VideoDownloader error ${item.errorCode}"; it.done = true } }
            override fun onDownloadSuccess(item: VideoTaskItem) { vdStates[item.url]?.let { it.path = item.filePath; it.done = true } }
        })
    }

    /** HLS: VideoDownloader (JeffMony) mengunduh + menggabung jadi MP4 utuh. null = sukses, selain itu pesan error (pemanggil lalu memakai FFmpeg sebagai cadangan). */
    private fun hlsDownloadMerge(item: DlItem, srcUrl: String, ua: String, props: Map<String, String>, cacheDir: File, out: File): String? {
        val t0 = System.currentTimeMillis()
        val st = VdState()
        val err = hlsVdRun(item, srcUrl, st, out) ?: return null
        if (err == "dijeda" || Repo.get(item.id)?.status == Status.PAUSED) return err
        return hlsConcatTs(item, t0, st, out, err)   // FFmpeg hanya bila segmen .ts sudah lengkap (merge JeffMony gagal)
    }

    /** Merge gagal tapi semua .ts sudah terunduh -> FFmpeg concat (-f concat -c copy). Unduhan gagal total -> TANPA FFmpeg, langsung gagal. */
    private fun hlsConcatTs(item: DlItem, t0: Long, st: VdState, out: File, err: String): String? {
        try {
            val d = cacheDir.walkTopDown().maxDepth(5).filter { it.isFile && it.name.endsWith(".ts", true) && it.lastModified() >= t0 - 2000 }
                .groupBy { it.parentFile }.maxByOrNull { it.value.size }?.key
                ?: return "$err | unduhan gagal (tidak ada .ts), FFmpeg tidak dipanggil"
            val m3 = File(d, "local.m3u8").takeIf { it.isFile }
            val names = m3?.readLines()?.map { it.trim() }?.filter { it.isNotEmpty() && !it.startsWith("#") }?.map { it.substringBefore('?').substringAfterLast('/') }.orEmpty()
            val segs: List<File> = if (names.isNotEmpty()) names.map { File(d, it) }.filter { it.isFile && it.length() > 0 }
                else d.listFiles { x -> x.isFile && x.name.endsWith(".ts", true) && x.length() > 0 }?.sortedBy { it.nameWithoutExtension.toLongOrNull() ?: Long.MAX_VALUE }.orEmpty()
            val complete = segs.isNotEmpty() && (if (names.isNotEmpty()) segs.size == names.size else st.pct >= 99.5f)
            if (!complete) return "$err | unduhan .ts tidak lengkap, FFmpeg tidak dipanggil"
            val list = ffWork("concat_${item.id}.txt")
            list.writeText(segs.joinToString("\n") { "file '" + it.absolutePath.replace("'", "'\\''") + "'" } + "\n")
            Repo.update(item.id) { it.copy(speed = 0, error = "Menggabungkan segmen .ts (FFmpeg)…") }
            out.delete()
            val ff = try { processWithFFmpeg(list.path, null, out, null, false) } catch (e: Throwable) { null }
            list.delete()
            if (ff != null && out.exists() && out.length() > 1024) { try { d.deleteRecursively() } catch (e: Throwable) { }; return null }
            return "$err | FFmpeg concat gagal"
        } catch (e: Throwable) { return "$err | concat exception ${e.javaClass.simpleName}" }
    }

    private fun hlsVdRun(item: DlItem, srcUrl: String, st: VdState, out: File): String? {
        val cancelled = java.util.concurrent.atomic.AtomicBoolean(false)
        try { vdEnsure() } catch (e: Throwable) { return "VideoDownloader init: $e".take(200) }
        vdStates[srcUrl] = st
        hlsCancels[item.id] = { cancelled.set(true) }
        try {
            val taskItem = VideoTaskItem(srcUrl)
            VideoDownloadManager.getInstance().startDownload(taskItem)
            while (!st.done) {
                if (cancelled.get()) return "dijeda"
                if (System.currentTimeMillis() - st.tick > 180_000L) { return "VideoDownloader macet (tanpa progres 3 menit)" }
                val pr = st.pct.toInt().coerceIn(0, 99)
                Repo.update(item.id) { it.copy(progress = maxOf(it.progress.coerceAtMost(99), pr), done = st.dl, speed = st.speed.toLong(), total = if (st.tot > 0) st.tot else it.total) }
                Thread.sleep(250)
            }
            st.err?.let { return it }
            val fp: File = st.path?.let { File(it) } ?: return "VideoDownloader: hasil MP4 tidak ditemukan"
            if (!fp.exists() || fp.length() < 1024 || fp.name.endsWith(".m3u8", true)) return "VideoDownloader: hasil MP4 tidak ditemukan"
            out.delete()
            fp.copyTo(out, overwrite = true)
            return if (out.exists() && out.length() > 1024) null else "VideoDownloader: salin hasil gagal"
        } finally {
            hlsCancels.remove(item.id)
            vdStates.remove(srcUrl)
        }
    }

    /** v1.63: hasil NewPipe/ytFast hanya video / hanya suara -> unduh ulang lengkap lewat yt-dlp (ffmpeg menggabungkan). Gagal = file asli dipertahankan. */
    private fun hasVA(f: File): Boolean = try {
        val e = android.media.MediaExtractor()
        try {
            e.setDataSource(f.path)
            var v = false; var a = false
            for (i in 0 until e.trackCount) { val m = e.getTrackFormat(i).getString(android.media.MediaFormat.KEY_MIME) ?: ""; if (m.startsWith("video/")) v = true; if (m.startsWith("audio/")) a = true }
            v && a
        } finally { e.release() }
    } catch (e: Throwable) { true }

    private fun completeStreams(item: DlItem, page: String) {
        if (item.isAudio || item.audioExt.isNotEmpty()) return
        val cur = Repo.get(item.id) ?: return
        val f = File(cur.path)
        if (cur.path.isBlank() || !f.exists() || hasVA(f)) return
        val bak = File(f.parentFile, f.name + ".bak")
        if (!f.renameTo(bak)) return
        try {
            ytdl(item.copy(url = page, kind = Kind.YTDLP, formatSel = null, referer = null))
            bak.delete()
        } catch (e: CancellationException) { bak.delete(); throw e } catch (e: Exception) {
            bak.renameTo(f)
            Repo.update(item.id) { it.copy(status = Status.DONE, path = f.path, name = f.name, total = f.length(), done = f.length(), speed = 0, error = "") }
        }
    }

    private fun ytdl(item: DlItem) {
        val dir = File(item.dir).apply { mkdirs() }
        val base = item.name.substringBeforeLast('.').replace("%", "")
        val isYt = item.url.contains("youtu") && !item.url.contains("googlevideo")
        val isFb = Regex("facebook\\.com/|fb\\.watch/|fb\\.com/", RegexOption.IGNORE_CASE).containsMatchIn(item.url) && !item.url.contains("fbcdn", true)
        val isHls = item.kind == Kind.HLS || item.url.substringBefore('?').endsWith(".m3u8", true)
        if (isHls && !isYt) {
            Repo.update(item.id) { it.copy(resumable = true, error = "") }   // v1.147: HLS lanjut per segmen (cache dipertahankan)
            val hf0 = hlsMedia3(item, dir, base)
            val hf = if (hf0 != null && item.audioExt == "mp3") convertMp3(hf0, item) else hf0
            if (hf != null) {
                Repo.update(item.id) { it.copy(status = Status.DONE, progress = 100, path = hf.path, name = hf.name, total = hf.length(), done = hf.length(), speed = 0, error = "") }
                Repo.save(); scanMedia(hf); notifyDone(hf.name, hf.length()); return
            }
            throw IOException(ScanReport.RAW + "HLS gagal (VideoDownloader+FFmpeg)\n" + hlsErr.ifBlank { "tidak ada output" })
        }
        Engine.await()
        val clients: List<String?> = if (isYt) (listOfNotNull(Resolver.ytArgs) + Resolver.YT_CLIENTS).distinct() else listOf(null)
        var lastE: Exception? = null
        var okRun = false
        Repo.update(item.id) { it.copy(resumable = true) }
        for (c in clients) {
            val req = YoutubeDLRequest(item.url)
            req.addOption("--no-playlist")
            req.addOption("--no-mtime")
            req.addOption("--concurrent-fragments", "4")
            req.addOption("-o", "${dir.path}/$base.%(ext)s")
            req.addOption("--user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
            req.addOption("--socket-timeout", "30")
            (Resolver.vidlyxRef(item.url, item.referer) ?: item.referer)?.let { req.addOption("--referer", it) }
            if (isHls) {
                req.addOption("--hls-prefer-native")
                req.addOption("--merge-output-format", "mp4")
                req.addOption("--remux-video", "mp4")
            }
            if (c != null) req.addOption("--extractor-args", c)
            val nrSite = !AppPreferences.isRooted && !isHls && (isYt || item.url.contains("instagram.com", true))
            if (nrSite) Resolver.nrCookieFile(item.url)?.let { req.addOption("--cookies", it) }
            if (item.audioExt.isNotEmpty()) {
                req.addOption("-x"); req.addOption("--audio-format", item.audioExt)
                req.addOption("-f", "bestaudio/best")
            } else if (isFb && !item.isAudio && item.formatSel == null) {
                req.addOption("-f", "bv*+ba/b")
                req.addOption("--merge-output-format", "mp4")
            } else if ((nrSite || (!AppPreferences.isRooted && item.kind == Kind.YTDLP && item.page.isNotBlank())) && !item.isAudio) {
                req.addOption("-f", "bv*+ba/b")
                req.addOption("--merge-output-format", "mp4")
            } else
            req.addOption("-f", item.formatSel ?: (if (item.isAudio) (if (isYt) "bestaudio[ext=m4a]/bestaudio/best" else "bestaudio/best") else "best"))
            try {
                YoutubeDL.getInstance().execute(req, item.id) { p, _, line ->
                    val sp = parseSpeed(line ?: "")
                    Repo.update(item.id) { it.copy(progress = p.toInt().coerceIn(0, 100), speed = if (sp > 0) sp else it.speed) }
                }
                okRun = true
                Resolver.ytArgs = c
                break
            } catch (e: Exception) {
                val cur = Repo.get(item.id)
                if (cur == null || cur.status == Status.PAUSED) throw e
                lastE = e
                Repo.update(item.id) { it.copy(error = "Mencoba cara lain…") }
            }
        }
        if (!okRun) throw lastE ?: IOException("Unduhan gagal")
        var f = dir.listFiles { x -> x.name.startsWith("$base.") && !x.name.endsWith(".part") && !x.name.endsWith(".ytdl") }
            ?.maxByOrNull { it.lastModified() } ?: throw IOException("File hasil tidak ditemukan")
        if (!item.isAudio) f = fixFrag(f, item)
        if (item.isAudio) f = finishAudio(f, item)
        Repo.update(item.id) {
            it.copy(status = Status.DONE, progress = 100, path = f.path, name = f.name,
                total = f.length(), done = f.length(), speed = 0, error = "")
        }
        Repo.save()
        scanMedia(f); notifyDone(f.name, f.length())
    }
}

/** Ambil ID video YouTube (11 karakter) dari ID langsung atau dari tautan watch/youtu.be/shorts/embed/live. */
object YtCover {
    private val RE = Regex("(?:youtu\\.be/|youtube(?:-nocookie)?\\.com/(?:watch/?\\?(?:[^#]*&)?v=|shorts/|embed/|live/|v/)|ytimg\\.com/vi(?:_webp)?/)([\\w-]{11})")
    private val ID = Regex("^[\\w-]{11}$")
    fun idOf(vararg s: String?): String? {
        for (x in s) {
            if (x.isNullOrEmpty()) continue
            if (ID.matches(x)) return x
            RE.find(x)?.let { return it.groupValues[1] }
        }
        return null
    }
}
