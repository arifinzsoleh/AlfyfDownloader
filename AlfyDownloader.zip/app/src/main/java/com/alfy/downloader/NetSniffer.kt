package com.alfy.downloader

import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * v1.8: izin root diminta SATU KALI di awal aplikasi (su -c id). Setelah diizinkan di Magisk (pilih "Selamanya"),
 * semua alat berbasis root (logcat, tcpdump, media_session, clipboard, pengaturan izin) memakai izin yang sama
 * dan baru dijalankan SESUDAH izin keluar, jadi tidak ada permintaan ganda.
 */
object RootGate {
    /** 0 = belum diminta, 1 = menunggu jawaban, 2 = diizinkan, 3 = ditolak/tidak ada root */
    @Volatile var state = 0
    @Volatile var status = "Root: belum diminta"
    private val lock = Any()
    val granted: Boolean get() = state == 2

    /** Blok sampai ada jawaban. force = tanya ulang (tombol pengguna / pemantau otomatis). */
    fun ensure(force: Boolean = false): Boolean = synchronized(lock) {
        if (state == 2) return@synchronized true
        if (state == 3 && !force) return@synchronized false
        state = 1; status = "Root: meminta izin (cek jendela Magisk/KernelSU)…"
        val ok = try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor(); out.contains("uid=0")
        } catch (e: Exception) { false }
        markGranted(ok)
        ok
    }

    @Volatile private var watching = false

    /**
     * v1.9: bila izin belum diberikan (jendela Magisk terlewat / baru diizinkan lewat tab Superuser), cek ulang otomatis
     * di latar belakang. Begitu root aktif, semua pemantau dinyalakan sendiri (tanpa paksa-berhenti / restart aplikasi).
     */
    @Synchronized fun watch() {
        if (watching || state == 2) return
        watching = true
        Thread {
            var n = 0
            try {
                while (state != 2 && Scan.enabled()) {
                    if (ensure(true)) { NetSniffer.enable(Repo.app.packageName, false); break }
                    n++
                    try { Thread.sleep(if (n < 20) 3000L else 30000L) } catch (e: Exception) { }
                }
            } finally { watching = false }
        }.apply { isDaemon = true }.start()
    }

    fun markGranted(ok: Boolean) {
        state = if (ok) 2 else 3
        status = if (ok) "Root: ✓ diizinkan 1x (berlaku untuk semua alat)" else "Root: ✗ ditolak / tidak ada"
    }
}

/** Sniffer lalu lintas jaringan (butuh root): logcat semua aplikasi + tcpdump (jika tersedia). */
object NetSniffer {
    @Volatile private var running = false
    @Volatile var status = "Sniffer: memulai…"
    // v1.8: status & penghitung per alat root, tampil di panel mengambang
    @Volatile var logStat = "• menunggu izin root"
    @Volatile var dumpStat = "• menunggu izin root"
    @Volatile var mediaStat = "• menunggu izin root"
    @Volatile var clipStat = "• menunggu izin root"
    @Volatile var logLines = 0L
    @Volatile var logHits = 0
    @Volatile var hookHits = 0
    @Volatile var dumpHits = 0
    @Volatile var lastHit = ""
    private val procs = HashMap<String, MutableList<Process>>()
    private val gen = java.util.concurrent.ConcurrentHashMap<String, Int>()
    private var genCtr = 0
    @Volatile private var rootOk = false
    @Volatile private var rooting = false
    private val tags = listOf("log", "media", "clip")
    private fun want(t: String): Boolean = Scan.enabled() && when (t) {
        "log" -> Tool.on("Logcat root") || Tool.on("Hook pemutar") || Tool.on("Dexterceptor")
        "dump" -> Tool.on("tcpdump")
        "media" -> Tool.on("Media session")
        else -> Tool.on("Clipboard root")
    }
    private fun alive(t: String, g: Int) = running && gen[t] == g
    private fun off(t: String) {
        gen[t] = 0
        synchronized(this) { procs.remove(t)?.forEach { try { it.destroy() } catch (e: Exception) { } } }
        when (t) { "log" -> logStat = "– dimatikan"; "dump" -> dumpStat = "– dimatikan"; "media" -> mediaStat = "– dimatikan"; else -> clipStat = "– dimatikan" }
    }
    private val urlRe = Regex("https?://[^\\s\"'<>\\\\)]+")

    /** Tombol AKTIFKAN: minta root, beri izin, nyalakan (ulang) pemantau. */
    fun enable(pkg: String, restart: Boolean = true) { Thread { enableSync(pkg, restart) }.start() }

    /** v1.9: versi sinkron (dipakai MainActivity: root diminta PERTAMA sebelum izin lain). */
    fun enableSync(pkg: String, restart: Boolean = true): Boolean {
        run {
            status = "Meminta akses root…"
            val ok = try {
                val me = "$pkg/$pkg.AlfyAccessibilityService"
                val d = "\$"
                val cmd = "appops set $pkg SYSTEM_ALERT_WINDOW allow; pm grant $pkg android.permission.READ_LOGS; pm grant $pkg android.permission.POST_NOTIFICATIONS; pm grant $pkg android.permission.READ_EXTERNAL_STORAGE; pm grant $pkg android.permission.WRITE_EXTERNAL_STORAGE; dumpsys deviceidle whitelist +$pkg; " +
                    "cmd notification allow_listener $pkg/$pkg.AlfyNotifService 2>/dev/null; " +
                    "cur=${d}(settings get secure enabled_accessibility_services); " +
                    "case \"${d}cur\" in *$me*) ;; *) settings put secure enabled_accessibility_services \"${d}{cur#null}:$me\" ;; esac; " +
                    "settings put secure accessibility_enabled 1; id"
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                val out = p.inputStream.bufferedReader().readText()
                p.waitFor(); out.contains("uid=0")
            } catch (e: Exception) { false }
            RootGate.markGranted(ok)
            if (!ok) { status = "Root DITOLAK/tidak ada. Izinkan di Magisk (cek otomatis tiap beberapa detik)."; RootGate.watch(); return false }
            if (restart) stop()   // restart=false: jangan matikan pemantau yang sedang menunggu izin (hindari ganda)
            start()
        }
        return true
    }

    /** Coba pasang tcpdump lewat Termux (jika Termux terpasang). */
    fun installTcpdump() {
        Thread {
            val tp = "/data/data/com.termux/files/usr"
            status = "Memasang tcpdump via Termux… (butuh internet)"
            try {
                val cmd = "[ -x $tp/bin/pkg ] || exit 7; export PREFIX=$tp HOME=$tp/../home PATH=$tp/bin LD_LIBRARY_PATH=$tp/lib; " +
                    "yes | $tp/bin/pkg install -y tcpdump 2>&1 | tail -3; [ -x $tp/bin/tcpdump ]"
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                p.inputStream.readBytes(); val code = p.waitFor()
                status = if (code == 0) "tcpdump terpasang ✓" else if (code == 7) "Termux belum terpasang. Pasang Termux dulu (F-Droid)." else "Pasang tcpdump gagal. Buka Termux lalu ketik: pkg install tcpdump"
                if (code == 0) { stop(); start() }
            } catch (e: Exception) { status = "Pasang tcpdump gagal: ${e.message}" }
        }.start()
    }

    @Synchronized fun start() {
        if (!running) { running = true; status = "Memulai pemantau…" }
        sync()
    }

    /** Samakan thread/proses root dengan Scan + tool aktif. Yang OFF dihentikan total (proses su dibunuh, loop keluar). */
    @Synchronized fun sync() {
        if (!running) return
        for (t in tags) if (!want(t) && (gen[t] ?: 0) != 0) off(t)
        val wanted = tags.filter { want(it) }
        if (wanted.isEmpty()) { status = "Pemantau: OFF (scan/tool dimatikan)"; return }
        if (!rootOk) {
            if (rooting) return
            rooting = true
            Thread {
                val ok = RootGate.ensure()
                rooting = false
                if (!ok) {
                    status = "Root DITOLAK/tidak ada. Izinkan di Magisk lalu tekan tombol Akses root di 📖."
                    logStat = "✗ root ditolak"; dumpStat = "✗ root ditolak"; mediaStat = "✗ root ditolak"; clipStat = "✗ root ditolak"
                    running = false
                    return@Thread
                }
                rootOk = true
                sync()
            }.apply { isDaemon = true }.start()
            return
        }
        for (t in wanted) if ((gen[t] ?: 0) == 0) {
            val g = ++genCtr
            gen[t] = g
            Thread { when (t) { "log" -> logcat(g); "dump" -> dump(g); "media" -> media(g); else -> clip(g) } }.apply { isDaemon = true }.start()
        }
    }

    @Synchronized fun stop() {
        running = false; rootOk = false
        gen.clear()
        procs.values.forEach { l -> l.forEach { try { it.destroy() } catch (e: Exception) { } } }
        procs.clear()
    }

    /** v1.110: ProcessBuilder (stderr dipisah & dikuras agar proses tidak macet/mati) + stderr diteruskan ke [onErr]. */
    private fun su(cmd: String, t: String, g: Int, onErr: ((String) -> Unit)? = null): Process? = try {
        ProcessBuilder("su", "-c", cmd).redirectErrorStream(false).start().also { p ->
            Thread {
                try { p.errorStream.bufferedReader().forEachLine { l -> if (l.isNotBlank()) onErr?.invoke(l.trim()) } } catch (e: Exception) { }
            }.apply { isDaemon = true }.start()
            synchronized(this) { if (alive(t, g)) procs.getOrPut(t) { mutableListOf() }.add(p) else p.destroy() }
        }
    } catch (e: Exception) { onErr?.invoke(e.message ?: "gagal menjalankan su"); null }

    /** Android 12 membunuh proses anak aplikasi yang tidak terikat Foreground Service: pastikan service jalan. */
    private fun ensureFgService() {
        if (FloatingService.inst != null) return
        try { androidx.core.content.ContextCompat.startForegroundService(Repo.app, android.content.Intent(Repo.app, FloatingService::class.java)) } catch (e: Throwable) { }
    }

    // v1.8: alamat/ID tweet di log aplikasi X -> fxtwitter langsung (cepat), tidak menunggu video mulai diputar
    private val tweetRe = Regex("(?:(?:x|twitter)\\.com/(?:[\\w.]+/)*status(?:es)?/|twitter://status\\?id=|x://status\\?id=)(\\d{8,25})")

    private fun feed(line: String, src: String = "Logcat root") {
        if (!Scan.enabled()) return   // v1.11: scan otomatis dimatikan lewat ⚙
        if (line.startsWith("AlfyDex|")) { DexterceptorTool.onLine(line); return }
        if (line.startsWith("AlfyHook|")) {   // v1.29: link dari modul LSPosed "Hook pemutar"
            if (!Tool.on("Hook pemutar")) return
            val parts = line.split('|')
            val hu = parts.getOrNull(1) ?: return
            if (!hu.startsWith("http")) return
            if (!Resolver.pkgActive(parts.getOrNull(3) ?: "")) return   // v1.61: hook dari aplikasi latar diabaikan
            hookHits++
            // v1.97: YouTube & Facebook: stream dari pemutar = video-only (mute). JANGAN dijadikan link unduhan;
            // serahkan ID/halaman asli ke yt-dlp (video+audio digabung ffmpeg) di latar belakang.
            val hp = (parts.getOrNull(3) ?: "").substringBefore(':')
            if (hu.contains("googlevideo.com") || hp.contains("youtube", true)) {
                val vid = parts.getOrNull(4)?.trim().orEmpty().takeIf { it.length == 11 }
                    ?: Resolver.ytRe.find(Resolver.lastPage)?.groupValues?.get(1)
                if (vid != null) Resolver.submit("https://www.youtube.com/watch?v=$vid", null, true, "Hook pemutar")
                return
            }
            if (hp.startsWith("com.facebook") || hu.contains("fbcdn.net") || hu.contains("fbcdn.com")) {
                val fbPage = parts.getOrNull(5)?.trim().orEmpty().takeIf { it.startsWith("http") }
                    ?: Resolver.lastPage.takeIf { Regex("facebook\\.com/|fb\\.watch/", RegexOption.IGNORE_CASE).containsMatchIn(it) }
                if (fbPage != null) Resolver.submit(fbPage, null, true, "Hook pemutar")
                return
            }
            Resolver.submitMedia(hu, parts.getOrNull(2)?.takeIf { it.startsWith("http") }, "Hook pemutar")
            return
        }
        if (!Tool.on(src)) return     // v1.12: tool "Logcat root" / "tcpdump" dimatikan lewat ⚙
        if (src != "tcpdump" && line.contains("status")) tweetRe.findAll(line).forEach { Resolver.submitTweet(it.groupValues[1]) }
        if (!line.contains("http")) return
        val all = Repo.prefs().getBoolean("sniffAll", false) || Scan.aggr()   // v1.11: mode agresif = semua URL
        urlRe.findAll(line).forEach {
            val u = it.value.trimEnd('.', ',', ';').replace("\\u0026", "&")
            if (src == "tcpdump" && !Resolver.hostInScope(u)) return@forEach   // v1.61: tcpdump tidak bisa dikaitkan ke aplikasi -> hanya situs aktif
            // mode normal: hanya link media asli (googlevideo/videoplayback, mp4, m3u8, mp3, ...)
            if (all || Resolver.isMedia(u)) {
                logHits++; lastHit = u.substringAfter("://").substringBefore('?').takeLast(40)
                // v1.8: media X/Twitter masuk daftar LANGSUNG (tanpa HEAD/uji) supaya tidak lambat
                if (u.contains("twimg.com") && Resolver.isMedia(u)) Resolver.submitFast(u) else Resolver.submit(u, null, false, src)
            }
        }
    }

    private val ltRe = Regex("^\\d\\d-\\d\\d\\s+\\d\\d:\\d\\d:\\d\\d\\.\\d+\\s+(\\d+)\\s+\\d+\\s+[VDIWEF]\\s+")
    private val pidCache = java.util.concurrent.ConcurrentHashMap<Int, String>()
    private fun pkgOfPid(pid: Int): String {
        pidCache[pid]?.let { return it }
        if (pidCache.size > 600) pidCache.clear()
        val n = runSu("cat /proc/$pid/cmdline 2>/dev/null").substringBefore('\u0000').trim()
        pidCache[pid] = n
        return n
    }
    @Volatile private var rootFgAt = 0L
    /** Tanpa aksesibilitas: aplikasi di depan dibaca lewat root agar scope tetap benar. */
    private fun syncRootScope() {
        if (AlfyAccessibilityService.inst != null) return
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - rootFgAt < 1500) return
        rootFgAt = now
        val o = runSu("dumpsys window 2>/dev/null | grep -E 'mCurrentFocus' | head -1")
        val p = Regex("u\\d+\\s+([\\w.]+)/").find(o)?.groupValues?.get(1) ?: return
        if (p != Resolver.activePkg && !p.contains("systemui") && p != Repo.app.packageName) Resolver.beginScope(p)
    }

    /** URL yang dicatat pemutar media/aplikasi di logcat. */
    private fun logcat(g: Int) {
        val p = su("pm grant com.alfy.downloader android.permission.READ_LOGS; logcat -b all -v threadtime -T 1 *:V", "log", g)
        if (p == null) { status = "Root: tidak tersedia"; logStat = "✗ root tidak tersedia"; return }
        status = "Root: aktif • pemantau link aktif"
        logStat = "✓ aktif"
        try {
            BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8), 65536).use { r ->
                while (alive("log", g)) {
                    val raw = r.readLine() ?: break; logLines++
                    // v1.61: logcat HANYA dari proses aplikasi yang sedang aktif (latar belakang diabaikan)
                    val m = ltRe.find(raw) ?: continue
                    val rest = raw.substring(m.range.last + 1)
                    val body = rest.substringAfter(": ", rest)
                    if (body.startsWith("AlfyHook|") || body.startsWith("AlfyDex|")) { feed(body); continue }   // dicek lewat kolom paket
                    if (!body.contains("http") && !body.contains("status")) continue
                    syncRootScope()
                    if (!Resolver.pkgActive(pkgOfPid(m.groupValues[1].toIntOrNull() ?: continue))) continue
                    feed(body)
                }
            }
        } catch (e: Exception) { }
        if (alive("log", g)) logStat = "✗ berhenti (logcat putus)"
    }

    /** Paket HTTP polos (port 80 / 8080) via tcpdump bila ada di HP. v1.110: jalan terikat Foreground Service, stderr ditangkap, restart otomatis bila mati. */
    private fun dump(g: Int) {
        ensureFgService()
        dumpStat = "⏳ mencari tcpdump…"
        val which = su("which tcpdump; ls /system/xbin/tcpdump /system/bin/tcpdump /data/local/tmp/tcpdump /data/adb/modules/*/system/*bin/tcpdump /data/data/com.termux/files/usr/bin/tcpdump 2>/dev/null", "dump", g)
            ?: return
        val bin = try {
            which.inputStream.bufferedReader().readLines().firstOrNull { it.contains("tcpdump") }?.trim()
        } catch (e: Exception) { null }
        if (bin == null) { dumpStat = "✗ tidak ada di HP (📖 → pasang tcpdump)"; return }
        var fails = 0
        while (alive("dump", g)) {
            ensureFgService()
            val err = StringBuilder()
            val onErr: (String) -> Unit = { l -> synchronized(err) { if (err.length < 300) err.append(l.take(100)).append(' ') } }
            dumpStat = "✓ aktif • HTTP polos"
            val p = su("LD_LIBRARY_PATH=/data/data/com.termux/files/usr/lib:\$LD_LIBRARY_PATH exec $bin -i any -l -A -s 1500 'tcp and (port 80 or port 8080)'", "dump", g, onErr)
            if (p == null) { dumpStat = "✗ berhenti (su gagal)"; return }
            val t0 = android.os.SystemClock.elapsedRealtime()
            var path: String? = null
            try {
                BufferedReader(InputStreamReader(p.inputStream)).use { r ->
                    while (alive("dump", g)) {
                        val l = r.readLine() ?: break
                        Regex("(?:GET|HEAD) (\\S+) HTTP").find(l)?.let { path = it.groupValues[1] }
                        Regex("Host: (\\S+)").find(l)?.let { m ->
                            val pa = path
                            if (pa != null && Tool.on("tcpdump") && Scan.enabled()) {
                                dumpHits++
                                Resolver.submit(if (pa.startsWith("http")) pa else "http://${m.groupValues[1]}$pa", null, false, "tcpdump")
                                path = null
                            }
                        }
                        feed(l, "tcpdump")
                    }
                }
            } catch (e: Exception) { }
            if (!alive("dump", g)) return
            val code = try { p.waitFor(1, java.util.concurrent.TimeUnit.SECONDS); if (p.isAlive) -1 else p.exitValue() } catch (e: Exception) { -1 }
            try { p.destroy() } catch (e: Exception) { }
            if (android.os.SystemClock.elapsedRealtime() - t0 > 60_000L) fails = 0 else fails++
            val why = synchronized(err) { err.toString().trim() }.ifEmpty { "tanpa pesan error" }
            Repo.prefs().edit().putString("tcpdumpLastErr", "kode=$code $why").apply()
            if (fails > 8) { dumpStat = "✗ berhenti (kode $code: ${why.take(80)})"; return }
            dumpStat = "✗ berhenti (kode $code: ${why.take(60)}) • mulai ulang #$fails…"
            try { Thread.sleep(minOf(2000L * fails, 15000L)) } catch (e: Exception) { return }
        }
    }

    /** Deteksi aplikasi YouTube: baca judul video yang sedang diputar (media session) lalu cari URL-nya.
     *  v1.7: aplikasi LAIN (browser, X, dll) yang mulai memutar media memicu AutoScan (semua alat jalan sendiri di belakang). */
    private fun media(g: Int) {
        val p = su("while true; do dumpsys media_session 2>/dev/null | grep -E 'package=|metadata:|state=PlaybackState'; echo ---; sleep 1; done", "media", g)
        if (p == null) { mediaStat = "✗ root tidak tersedia"; return }
        mediaStat = "✓ aktif • belum ada media diputar"
        var pkg = ""
        var last = ""
        val playing = HashSet<String>()
        var seenNow = HashSet<String>()
        try {
            BufferedReader(InputStreamReader(p.inputStream)).use { r ->
                while (alive("media", g)) {
                    val l = (r.readLine() ?: break).trim()
                    if (l.startsWith("package=")) pkg = l.substringAfter("package=").trim()
                    else if (l == "---") {
                        pkg = ""
                        playing.retainAll(seenNow)
                        seenNow = HashSet()
                    }
                    else if (l.startsWith("state=PlaybackState") && pkg.isNotEmpty()) {
                        val st = Regex("state=(\\d+)").find(l)?.groupValues?.get(1)?.toIntOrNull() ?: -1
                        if (st == 3) {
                            seenNow.add(pkg)
                            if (playing.add(pkg)) { mediaStat = "✓ aktif • memutar: " + pkg.substringAfterLast('.'); if (Tool.on("Media session") && Resolver.pkgActive(pkg)) AutoScan.onPlay(pkg) }
                        }
                    }
                    else if (l.startsWith("metadata:") && pkg.contains("youtube", true) && Resolver.pkgActive(pkg)) {
                        val d = l.substringAfter("description=", "").trim()
                            .removeSuffix(", null").removeSuffix(", null").trim()
                        if (d.length > 3 && d != last && d != "null" && Tool.on("Media session")) {
                            last = d
                            Resolver.searchYoutube(d)
                        }
                    }
                }
            }
        } catch (e: Exception) { }
    }

    // ---------- Clipboard via root (tanpa mencuri fokus layar, jadi tidak mengganggu saat mengetik) ----------
    @Volatile var clipRoot = false
    @Volatile private var clipCmd: String? = null
    @Volatile private var lastClip = ""
    private val clipUrlRe = Regex("https?://[^\\s\\u0000-\\u001F\\\"<>]+")

    private fun clipVariants(): List<String> {
        val sdk = android.os.Build.VERSION.SDK_INT
        val args = listOf("s16 %s i32 0", "s16 %s s16 null i32 0", "s16 %s s16 null i32 0 i32 0")
        val order = when { sdk <= 30 -> listOf(0, 1, 2); sdk <= 34 -> listOf(1, 2, 0); else -> listOf(2, 1, 0) }
        val out = ArrayList<String>()
        for (i in order) for (pkg in listOf("android", "root", "com.android.shell")) out.add("service call clipboard 3 " + args[i].format(pkg))
        for (i in order) out.add("su 2000 -c 'service call clipboard 3 " + args[i].format("com.android.shell") + "'")
        return out
    }

    private fun parseParcel(out: String): Pair<Boolean, String>? {
        val i = out.indexOf("Parcel(")
        if (i < 0) return null
        val body = out.substring(i + 7).replace(Regex("'[^']*'"), " ").replace(Regex("0x[0-9a-fA-F]+:"), " ")
        val words = Regex("\\b[0-9a-fA-F]{8}\\b").findAll(body).map { it.value }.toList()
        if (words.isEmpty()) return null
        val bytes = ByteArray(words.size * 4)
        words.forEachIndexed { k, w ->
            val v = w.toLong(16)
            for (b in 0..3) bytes[k * 4 + b] = ((v shr (8 * b)) and 0xFF).toByte()
        }
        return Pair(words[0] == "00000000", String(bytes, Charsets.UTF_16LE))
    }

    private fun runSu(cmd: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        val o = p.inputStream.bufferedReader().readText(); p.waitFor(); o
    } catch (e: Exception) { "" }

    private fun urlsIn(t: String): List<String> =
        clipUrlRe.findAll(t).map { it.value.trimEnd('.', ',', ';', ')') }.filter { it.length > 10 }.distinct().toList()

    /** Baca clipboard sekali (dipanggil saat ada tanda tautan disalin). */
    fun readClipRootOnce() {
        if (!Scan.enabled() || !Tool.on("Clipboard root")) return
        Thread {
            val c = clipCmd ?: return@Thread
            val r = parseParcel(runSu(c)) ?: return@Thread
            lastClip = r.second
            if (Tool.on("Clipboard root")) urlsIn(r.second).forEach { Resolver.rescan(it, null, "Clipboard root") }
        }.start()
    }

    private fun clip(g: Int) {
        while (alive("clip", g)) {
            var c = clipCmd
            if (c == null) {
                clipStat = "⏳ mencari cara baca clipboard…"
                for (v in clipVariants()) { val r = parseParcel(runSu(v)); if (r != null && r.first) { c = v; break } }
                if (c == null) { clipRoot = false; clipStat = "✗ HP ini tidak mendukung (akan dicoba lagi)"; try { Thread.sleep(20000) } catch (e: Exception) { }; continue }
                clipCmd = c; clipRoot = true; clipStat = "✓ aktif"
            }
            val p = su("while true; do $c; echo ---; sleep 1; done", "clip", g) ?: return
            var first = true
            try {
                BufferedReader(InputStreamReader(p.inputStream)).use { r ->
                    val sb = StringBuilder()
                    while (alive("clip", g)) {
                        val l = r.readLine() ?: break
                        if (l.trim() == "---") {
                            val res = parseParcel(sb.toString()); sb.setLength(0)
                            if (res != null) {
                                val t = res.second
                                if (first) { first = false; lastClip = t }
                                else if (t != lastClip) { lastClip = t; if (Tool.on("Clipboard root")) urlsIn(t).forEach { Resolver.rescan(it, null, "Clipboard root") } }
                            }
                        } else sb.append(l).append('\n')
                    }
                }
            } catch (e: Exception) { }
            if (!alive("clip", g)) return
            try { Thread.sleep(3000) } catch (e: Exception) { }
        }
    }
}
