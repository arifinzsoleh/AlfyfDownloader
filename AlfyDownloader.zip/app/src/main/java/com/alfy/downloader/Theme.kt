package com.alfy.downloader

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale

/** Warna bar atas & drawer + warna teks/ikon yang kontras, mengikuti Gaya UI. */
data class UiStyle(val bar: Color, val onBar: Color, val drawer: Color, val onDrawer: Color)
val LocalUiStyle = compositionLocalOf { UiStyle(Color(0xFF2C2C2C), Color.White, Color(0xFF303030), Color.White) }

@Composable
fun AlfyTheme(wallpaperBg: Boolean = true, content: @Composable () -> Unit) {
    val tick = Wallpaper.colorTick.value
    val transparent = remember(tick) { Wallpaper.isTransparent() }
    val bg = remember(tick) { Color(Wallpaper.uiColor()) }
    val sf = remember(tick) { Color(Wallpaper.uiColor2()) }
    val st = remember(tick) {
        UiStyle(Color(Wallpaper.barColor()), Color(Wallpaper.onColor(Wallpaper.barColor())), sf, Color(Wallpaper.onColor(Wallpaper.uiColor2())))
    }
    val img = remember(tick) { if (transparent && wallpaperBg) Wallpaper.bgDrawable() else null }
    val onBg = if (transparent) Color.White else Color(Wallpaper.onColor(Wallpaper.uiColor()))
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF80CBC4),
            background = if (transparent) (if (wallpaperBg) Color.Transparent else sf) else bg, surface = sf,
            onBackground = onBg, onSurface = st.onDrawer
        )
    ) {
        CompositionLocalProvider(LocalUiStyle provides st) {
            Box(Modifier.fillMaxSize().then(if (transparent && wallpaperBg && img == null) Modifier.background(bg) else Modifier)) {
                val b = img
                if (b != null) {
                    val bmp = (b as android.graphics.drawable.BitmapDrawable).bitmap
                    Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                }
                content()
            }
        }
    }
}
