package de.robv.android.xposed;

/** Stub kompilasi: kelas aslinya disediakan LSPosed saat modul dimuat. */
public interface IXposedHookLoadPackage {
    void handleLoadPackage(de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam lpparam) throws Throwable;
}
