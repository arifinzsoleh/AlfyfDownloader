package de.robv.android.xposed;

/** Stub kompilasi. */
public final class XposedHelpers {
    public static Class<?> findClassIfExists(String className, ClassLoader classLoader) {
        throw new UnsupportedOperationException("stub");
    }
}
