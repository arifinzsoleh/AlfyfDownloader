plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.alfy.downloader"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.alfy.downloader"
        minSdk = 24
        targetSdk = 28   // 28: agar binary ffmpeg/yt-dlp bisa dieksekusi & akses folder penyimpanan bebas
        versionCode = 155
        versionName = "1.62"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    signingConfigs {
        getByName("debug") {   // kunci tetap: APK baru bisa menimpa versi lama tanpa hapus data/login
            storeFile = file("alfy-debug.keystore"); storePassword = "android"; keyAlias = "androiddebugkey"; keyPassword = "android"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    packaging {
        jniLibs {
            useLegacyPackaging = true
            pickFirsts += setOf("**/libc++_shared.so", "**/libcrypto*.so", "**/libssl*.so", "lib/x86/libc++_shared.so", "lib/x86_64/libc++_shared.so", "lib/armeabi-v7a/libc++_shared.so", "lib/arm64-v8a/libc++_shared.so")
        }
        resources { excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/INDEX.LIST", "META-INF/*.kotlin_module") }
    }
    lint { abortOnError = false; checkReleaseBuilds = false }
}
// Stub API Xposed: hanya untuk kompilasi (compileOnly). Tidak masuk APK supaya tidak bentrok dengan API asli LSPosed.
val xposedStubCompile by tasks.registering(JavaCompile::class) {
    source = fileTree("xposed-stub/src") { include("**/*.java") }
    classpath = files()
    destinationDirectory.set(layout.buildDirectory.dir("xposed-stub/classes"))
    options.release.set(17)
}
val xposedStubJar by tasks.registering(Jar::class) {
    from(xposedStubCompile.map { it.destinationDirectory })
    archiveFileName.set("xposed-api-stub.jar")
    destinationDirectory.set(layout.buildDirectory.dir("xposed-stub"))
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.palette:palette-ktx:1.0.0")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("io.github.junkfood02.youtubedl-android:library:0.18.1")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-datasource:1.3.1")
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.26.5")
    // ===== TAMBAHAN AlfyExtras: hanya alat pendukung scan link video =====
    implementation("com.github.topjohnwu.libsu:core:6.0.0")                  // shell root persisten (pemantau logcat/media_session/clipboard)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")                     // HTTP untuk ambil halaman/API
    implementation("com.squareup.okhttp3:okhttp-dnsoverhttps:4.12.0")       // DNS-over-HTTPS (DNS VPN sering bermasalah)
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3") // baca JSON API (fxtwitter, Piped, dll)
    implementation("org.jsoup:jsoup:1.18.3")                                 // cari <video>/<source>/og:video di HTML
    implementation("androidx.media3:media3-exoplayer-dash:1.3.1")           // uji/putar link .mpd yang terdeteksi
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.webkit:webkit:1.11.0")                          // suntik skrip pemantau pemutar sebelum halaman jalan (document-start)
    compileOnly(files(xposedStubJar))   // API Xposed disediakan LSPosed saat runtime; JANGAN dibundel ke APK
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs_nio:2.1.3")
}
